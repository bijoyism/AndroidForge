# File Navigator Lite 0.2.1 — CI stabilization

A lightweight Android file manager with rule-based automatic organization, a Material 3 theme system, storage analysis and ZIP tools.

- Kotlin, Jetpack Compose, Material 3, MVVM, DataStore, WorkManager and Storage Access Framework.
- Minimum Android version: Android 10 (API 29).
- Designed for lower-end ARM phones; no analytics, cloud sync or network permission is required.
- Package: `com.bijoyism.filenavigator`.

## Included features

### Material 3 Expressive interface
- System, light and dark modes.
- Wallpaper dynamic colours on Android 12+, plus Ocean Blue, Sage Green, Violet, Sunset and AMOLED black palettes.
- Rounded Material surfaces, content-size animations and animated screen transitions.

### Automatic organizer
- User-defined rules match by extension, MIME type, keywords and file size.
- WorkManager periodic checks from 15 minutes to 24 hours.
- Background moves execute without per-file prompts after the user enables automation, grants folder access and configures rules.
- Dry-run previews, conflict policies, operation history and undo for supported moves.
- Android may defer periodic work because of Doze, battery optimization or force-stop. The chosen interval is not an exact timer.

### Storage and ZIP tools
- Read-only scan of up to 10,000 files across authorized folders.
- Category totals, largest-file list and exact duplicate groups using file size plus SHA-256.
- Duplicate detection never deletes files automatically.
- Create ZIP archives from folders and extract ZIP files to a selected destination.
- ZIP extraction rejects absolute paths and `..` traversal entries, and stops rather than overwriting a file with the same name.

### File operations and previews
- Browse, search, sort, grid/list views, multi-select, copy, move, rename, delete and create folders.
- Open compatible files through Android's installed apps; preview support depends on installed handlers.
- ZIP creation/extraction are available in Tools. Other archive formats such as RAR/7z are not extracted by this version.

### Backup and privacy
- Export/import JSON backups of rules, settings and operation history.
- File contents and Android folder grants are not included in backups. After reinstall or moving to another device, grant folders again.
- Restore validates the backup format and leaves automatic organization disabled until the user reviews and re-enables it.
- All app metadata stays on-device. Storage analysis reads file bytes only to calculate duplicate hashes; it does not upload them.

## Build APK without a PC

1. Upload the contents of this folder to your GitHub repository (the GitHub web UI or Termux + GitHub CLI works).
2. Open **Actions → Build APK** and run the workflow.
3. The workflow formats Kotlin, checks formatting, runs unit tests and Android lint, then builds the debug APK.
4. Download the `FileNavigatorLite-debug` artifact and extract `app-debug.apk`.

No Gradle wrapper is included; CI installs Gradle 8.9. This CI-stabilization build removes the external Spotless/ktlint download from the critical build path because the previous workflow failed while resolving formatter dependencies. It still runs unit tests, Android lint and the debug APK build. The workflow has not been run from this packaged source in this environment, so the APK is not yet verified. Kotlin formatting can be reintroduced after CI is stable.

## Suggested device acceptance checks

1. Install on Android 10/API 29 and confirm the app opens and theme settings persist.
2. Grant a test folder and create a rule with a test file; verify dry-run preview before enabling automatic moves.
3. Confirm the 15-minute minimum schedule is shown and that WorkManager may defer execution.
4. Scan a folder containing known duplicates and confirm matching hashes group only identical content.
5. Create and extract a ZIP using test files, including an archive with `../` paths; confirm unsafe entries are rejected.
6. Export a backup, change settings, restore it, and verify auto-organization remains disabled.
7. Test file operations and undo using disposable files before trusting the app with important data.

See `docs/` for device notes, permissions, privacy and limitations.
