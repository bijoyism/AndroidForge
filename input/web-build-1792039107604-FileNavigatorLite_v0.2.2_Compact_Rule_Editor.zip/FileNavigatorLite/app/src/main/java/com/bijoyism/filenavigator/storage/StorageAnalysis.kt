package com.bijoyism.filenavigator.storage

import android.net.Uri
import com.bijoyism.filenavigator.domain.FileEntry
import java.security.MessageDigest

/** Read-only storage report. Duplicate candidates are grouped by exact size and SHA-256. */
data class DuplicateGroup(val hash: String, val size: Long, val files: List<FileEntry>)

data class StorageReport(
    val scannedFiles: Int,
    val totalBytes: Long,
    val categoryBytes: Map<String, Long>,
    val largestFiles: List<FileEntry>,
    val duplicateGroups: List<DuplicateGroup>,
    val skippedFiles: Int
)

class StorageAnalyzer(private val storage: SafStorage) {
    fun analyze(roots: List<String>): StorageReport {
        val files = mutableListOf<FileEntry>()
        var skipped = 0
        val visited = HashSet<String>()
        val pending = ArrayDeque<String>()
        roots.forEach(pending::addLast)
        while (pending.isNotEmpty() && visited.size < MAX_FILES) {
            val folder = pending.removeFirst()
            if (!visited.add(folder)) continue
            val children = runCatching { storage.list(folder) }.getOrElse {
                skipped++
                emptyList()
            }
            children.forEach { entry ->
                if (visited.size >= MAX_FILES) return@forEach
                if (entry.isDirectory) pending.addLast(entry.uri) else if (files.size < MAX_FILES) files.add(entry)
            }
        }
        val categories = files.groupBy(::category).mapValues { (_, entries) -> entries.sumOf { it.size.coerceAtLeast(0) } }
        val duplicateCandidates = files.filter { it.size > 0 }.groupBy { it.size }.values.filter { it.size > 1 }.flatten()
        val hashes = duplicateCandidates.mapNotNull { entry ->
            val hash = runCatching { storage.sha256(entry.uri) }.getOrNull()
            if (hash == null) skipped++
            hash?.let { Triple(entry, it, entry.size) }
        }
        val duplicates = hashes.groupBy { it.third to it.second }.values
            .filter { it.size > 1 }
            .map { group -> DuplicateGroup(group.first().second, group.first().third, group.map { it.first }) }
            .sortedByDescending { it.size }
        return StorageReport(
            scannedFiles = files.size,
            totalBytes = files.sumOf { it.size.coerceAtLeast(0) },
            categoryBytes = categories,
            largestFiles = files.sortedByDescending { it.size }.take(20),
            duplicateGroups = duplicates,
            skippedFiles = skipped
        )
    }

    private fun category(file: FileEntry): String {
        val mime = file.mimeType.orEmpty()
        return when {
            mime.startsWith("image/") -> "Images"
            mime.startsWith("video/") -> "Videos"
            mime.startsWith("audio/") -> "Audio"
            mime == "application/pdf" || mime.startsWith("text/") -> "Documents"
            file.name.substringAfterLast('.', "").lowercase() in setOf("zip", "rar", "7z", "gz", "tar") -> "Archives"
            else -> "Other"
        }
    }

    companion object {
        private const val MAX_FILES = 10_000
    }
}
