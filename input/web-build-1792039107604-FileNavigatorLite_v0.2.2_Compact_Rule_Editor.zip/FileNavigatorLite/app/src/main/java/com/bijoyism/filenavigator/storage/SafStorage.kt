package com.bijoyism.filenavigator.storage

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import com.bijoyism.filenavigator.domain.FileEntry
import com.bijoyism.filenavigator.domain.StorageException
import com.bijoyism.filenavigator.domain.StorageGateway

/**
 * Storage Access Framework implementation (works on API 29). Every folder is identified by a URI string that is
 * either a tree URI chosen by the user or a document URI inside such a tree.
 */
class SafStorage(context: Context) : StorageGateway {
    private val resolver = context.contentResolver

    fun sha256(fileUri: String): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        resolver.openInputStream(Uri.parse(fileUri))?.use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        } ?: throw StorageException("Could not read file for duplicate check")
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun createZip(folderUri: String, outputFolderUri: String, archiveName: String): String =
        guard("Could not create ZIP archive") {
            val parent = docUri(outputFolderUri)
            val archive = DocumentsContract.createDocument(
                resolver,
                parent,
                "application/zip",
                archiveName.removeSuffix(".zip") + ".zip"
            ) ?: throw StorageException("The destination provider refused to create the ZIP file")
            try {
                val stream = resolver.openOutputStream(archive, "w")
                    ?: throw StorageException("Could not open ZIP output stream")
                java.util.zip.ZipOutputStream(stream.buffered()).use { zip ->
                    appendFolderToZip(folderUri, "", zip, 0)
                }
                archive.toString()
            } catch (error: Exception) {
                runCatching { DocumentsContract.deleteDocument(resolver, archive) }
                throw error
            }
        }

    private fun appendFolderToZip(folderUri: String, prefix: String, zip: java.util.zip.ZipOutputStream, depth: Int) {
        if (depth > 20) throw StorageException("Folder nesting is too deep to archive safely")
        list(folderUri).forEach { entry ->
            val path = if (prefix.isEmpty()) entry.name else "$prefix/${entry.name}"
            if (entry.isDirectory) {
                zip.putNextEntry(java.util.zip.ZipEntry("$path/"))
                zip.closeEntry()
                appendFolderToZip(entry.uri, path, zip, depth + 1)
            } else {
                zip.putNextEntry(java.util.zip.ZipEntry(path))
                resolver.openInputStream(Uri.parse(entry.uri))?.use { it.copyTo(zip) }
                    ?: throw StorageException("Could not read ${entry.name}")
                zip.closeEntry()
            }
        }
    }

    fun extractZip(zipUri: String, outputFolderUri: String): Int = guard("Could not extract ZIP archive") {
        var extracted = 0
        val root = docUri(outputFolderUri)
        val input = resolver.openInputStream(Uri.parse(zipUri)) ?: throw StorageException("Could not read ZIP archive")
        java.util.zip.ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val item = zip.nextEntry ?: break
                val safePath = item.name.replace('\\', '/').split('/')
                if (item.name.startsWith("/") || safePath.any { it == ".." } || item.name.contains('\u0000')) {
                    throw StorageException("Unsafe path in ZIP archive")
                }
                var parent = root
                val parts = safePath.filter { it.isNotBlank() }
                if (parts.isEmpty()) continue
                parts.dropLast(1).forEach { segment ->
                    val found = list(parent.toString()).firstOrNull { it.isDirectory && it.name == segment }
                    parent = if (found != null) docUri(found.uri) else {
                        DocumentsContract.createDocument(resolver, parent, Document.MIME_TYPE_DIR, segment)
                            ?: throw StorageException("Could not create folder $segment")
                    }
                }
                if (item.isDirectory) {
                    if (list(parent.toString()).none { it.isDirectory && it.name == parts.last() }) {
                        DocumentsContract.createDocument(resolver, parent, Document.MIME_TYPE_DIR, parts.last())
                    }
                } else {
                    val targetName = parts.last()
                    if (list(parent.toString()).any { it.name == targetName }) {
                        throw StorageException("Extraction stopped: $targetName already exists")
                    }
                    val target = DocumentsContract.createDocument(resolver, parent, "application/octet-stream", targetName)
                        ?: throw StorageException("Could not create $targetName")
                    resolver.openOutputStream(target, "w")?.use { zip.copyTo(it) }
                        ?: throw StorageException("Could not write $targetName")
                    extracted++
                }
                zip.closeEntry()
            }
        }
        extracted
    }

    fun grantedRoots(): List<String> = resolver.persistedUriPermissions
        .filter { it.isReadPermission && it.isWritePermission && DocumentsContract.isTreeUri(it.uri) }
        .map { it.uri.toString() }
        .sorted()

    fun grant(uri: Uri) {
        runCatching { resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
    }

    fun revoke(uri: String) {
        runCatching { resolver.releasePersistableUriPermission(Uri.parse(uri), Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
    }

    override fun hasAccess(folderUri: String): Boolean {
        val uri = Uri.parse(folderUri)
        val granted = resolver.persistedUriPermissions.any { it.isReadPermission && it.isWritePermission && sameTree(it.uri, uri) }
        return granted && documentExists(docUri(folderUri))
    }

    override fun sameFolder(a: String, b: String): Boolean = try {
        val first = docUri(a)
        val second = docUri(b)
        first.authority == second.authority && DocumentsContract.getDocumentId(first) == DocumentsContract.getDocumentId(second)
    } catch (e: IllegalArgumentException) {
        false
    }

    override fun list(folderUri: String): List<FileEntry> = guard("Cannot read folder") {
        val folder = docUri(folderUri)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(folder, DocumentsContract.getDocumentId(folder))
        val out = ArrayList<FileEntry>()
        val cursor = resolver.query(children, PROJECTION, null, null, null) ?: throw StorageException("The folder could not be read")
        cursor.use { while (it.moveToNext()) out.add(it.toEntry(folder)) }
        out
    }

    override fun copy(fileUri: String, destFolderUri: String, name: String): String = guard("Copy failed") {
        copyDocument(docUri(fileUri), docUri(destFolderUri), name).toString()
    }

    override fun move(fileUri: String, srcFolderUri: String, destFolderUri: String, name: String): String = guard("Move failed") {
        val source = docUri(fileUri)
        val sourceParent = docUri(srcFolderUri)
        val destParent = docUri(destFolderUri)
        // A provider-side move is atomic and fast, but only usable when the name is unchanged.
        val direct = if (queryString(source, Document.COLUMN_DISPLAY_NAME) == name) {
            runCatching { DocumentsContract.moveDocument(resolver, source, sourceParent, destParent) }.getOrNull()
        } else {
            null
        }
        if (direct != null) {
            direct.toString()
        } else {
            val copied = copyDocument(source, destParent, name)
            val removed = runCatching { DocumentsContract.deleteDocument(resolver, source) }.getOrDefault(false)
            if (!removed) {
                runCatching { DocumentsContract.deleteDocument(resolver, copied) }
                throw StorageException("Could not remove the original after copying, so nothing was changed")
            }
            copied.toString()
        }
    }

    override fun delete(uri: String) = guard("Delete failed") {
        if (!DocumentsContract.deleteDocument(resolver, docUri(uri))) throw StorageException("The provider refused to delete this item")
    }

    override fun rename(uri: String, newName: String): String = guard("Rename failed") {
        DocumentsContract.renameDocument(resolver, docUri(uri), newName)?.toString() ?: throw StorageException("The provider refused to rename this item")
    }

    override fun createFolder(parentUri: String, name: String): String = guard("Could not create folder") {
        DocumentsContract.createDocument(resolver, docUri(parentUri), Document.MIME_TYPE_DIR, name)?.toString() ?: throw StorageException("The provider refused to create the folder")
    }

    override fun label(folderUri: String): String {
        val id = runCatching { DocumentsContract.getDocumentId(docUri(folderUri)) }.getOrDefault(folderUri)
        val path = id.substringAfter(':', id)
        return if (path.isEmpty()) "Storage root" else path
    }

    private fun copyDocument(source: Uri, destParent: Uri, name: String): Uri {
        val mime = queryString(source, Document.COLUMN_MIME_TYPE) ?: "application/octet-stream"
        if (mime == Document.MIME_TYPE_DIR) {
            val newDir = DocumentsContract.createDocument(resolver, destParent, Document.MIME_TYPE_DIR, name) ?: throw StorageException("Could not create folder $name")
            try {
                list(source.toString()).forEach { copyDocument(Uri.parse(it.uri), newDir, it.name) }
            } catch (e: Exception) {
                runCatching { DocumentsContract.deleteDocument(resolver, newDir) }
                throw e
            }
            return newDir
        }
        val expected = queryLong(source, Document.COLUMN_SIZE)
        val target = DocumentsContract.createDocument(resolver, destParent, mime, name) ?: throw StorageException("Could not create $name")
        try {
            val input = resolver.openInputStream(source) ?: throw StorageException("Cannot read $name")
            val output = resolver.openOutputStream(target, "w") ?: throw StorageException("Cannot write $name")
            val copied = input.use { i -> output.use { o -> i.copyTo(o) } }
            val written = queryLong(target, Document.COLUMN_SIZE)
            if (expected >= 0 && (copied != expected || (written >= 0 && written != expected))) {
                throw StorageException("Integrity check failed for $name")
            }
            return target
        } catch (e: Exception) {
            runCatching { DocumentsContract.deleteDocument(resolver, target) }
            throw e
        }
    }

    private inline fun <T> guard(message: String, block: () -> T): T = try {
        block()
    } catch (e: StorageException) {
        throw e
    } catch (e: SecurityException) {
        throw StorageException("Access to this folder was revoked. Grant it again.", e)
    } catch (e: Exception) {
        throw StorageException("$message: ${e.message}", e)
    }

    private fun docUri(value: String): Uri {
        val uri = Uri.parse(value)
        return if (uri.pathSegments.contains("document")) uri else DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri))
    }

    private fun sameTree(a: Uri, b: Uri): Boolean = try {
        a.authority == b.authority && DocumentsContract.getTreeDocumentId(a) == DocumentsContract.getTreeDocumentId(b)
    } catch (e: IllegalArgumentException) {
        false
    }

    private fun documentExists(uri: Uri): Boolean = try {
        resolver.query(uri, arrayOf(Document.COLUMN_DOCUMENT_ID), null, null, null)?.use { it.moveToFirst() } ?: false
    } catch (e: Exception) {
        false
    }

    private fun queryString(uri: Uri, column: String): String? = try {
        resolver.query(uri, arrayOf(column), null, null, null)?.use { c -> if (c.moveToFirst() && !c.isNull(0)) c.getString(0) else null }
    } catch (e: Exception) {
        null
    }

    private fun queryLong(uri: Uri, column: String): Long = queryString(uri, column)?.toLongOrNull() ?: -1L

    private fun Cursor.toEntry(parent: Uri): FileEntry {
        val mime = getString(2)
        return FileEntry(
            uri = DocumentsContract.buildDocumentUriUsingTree(parent, getString(0)).toString(),
            name = getString(1) ?: "?",
            size = if (isNull(3)) -1L else getLong(3),
            mimeType = mime,
            lastModified = if (isNull(4)) 0L else getLong(4),
            isDirectory = mime == Document.MIME_TYPE_DIR
        )
    }

    private companion object {
        val PROJECTION = arrayOf(
            Document.COLUMN_DOCUMENT_ID,
            Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_MIME_TYPE,
            Document.COLUMN_SIZE,
            Document.COLUMN_LAST_MODIFIED
        )
    }
}
