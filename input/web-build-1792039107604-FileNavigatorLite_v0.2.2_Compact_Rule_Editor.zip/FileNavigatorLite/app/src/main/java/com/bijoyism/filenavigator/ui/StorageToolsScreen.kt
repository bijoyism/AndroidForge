package com.bijoyism.filenavigator.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.bijoyism.filenavigator.util.formatSize

@Composable
fun StorageToolsScreen(vm: StorageToolsViewModel) {
    val context = LocalContext.current
    val report by vm.report.collectAsState()
    val busy by vm.busy.collectAsState()
    val message by vm.message.collectAsState()
    var archiveSource by remember { mutableStateOf<Uri?>(null) }
    var extractSource by remember { mutableStateOf<Uri?>(null) }
    var archiveName by rememberSaveable { mutableStateOf("Archive.zip") }
    var pendingAction by rememberSaveable { mutableStateOf("") }

    val chooseFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            when (pendingAction) {
                "zip-source" -> { archiveSource = uri; pendingAction = "zip-destination" }
                "zip-destination" -> {
                    archiveSource?.let { vm.createArchive(it, uri, archiveName) }
                    pendingAction = ""
                }
                "extract-destination" -> {
                    extractSource?.let { vm.extractArchive(it, uri) }
                    pendingAction = ""
                }
            }
        }
    }
    val chooseZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { extractSource = uri; pendingAction = "extract-destination"; chooseFolder.launch(null) }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Storage & tools", style = MaterialTheme.typography.headlineLarge)
        Text(
            "Understand storage, find exact duplicates and manage ZIP archives. Scanning is read-only.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        SectionCard("Storage analyzer", Modifier.animateContentSize()) {
            Text("Scan up to 10,000 files across authorized folders. Files that cannot be read are skipped and counted.")
            Button(onClick = vm::analyze, enabled = !busy) { Text("Analyze storage") }
            if (busy) CircularProgressIndicator()
            message?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            AnimatedVisibility(report != null) {
                report?.let { data ->
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${data.scannedFiles} files · ${formatSize(context, data.totalBytes)}", style = MaterialTheme.typography.titleLarge)
                        Text("Storage by category", style = MaterialTheme.typography.titleMedium)
                        data.categoryBytes.toList().sortedByDescending { it.second }.forEach { (category, bytes) ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(category)
                                Text(formatSize(context, bytes), color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        Text("Largest files", style = MaterialTheme.typography.titleMedium)
                        data.largestFiles.take(10).forEach { file ->
                            Column {
                                Text(file.name, maxLines = 2)
                                Text(formatSize(context, file.size), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Text("${data.skippedFiles} item(s) could not be read.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        SectionCard("Exact duplicate finder", Modifier.animateContentSize()) {
            Text("Duplicate groups are matched by file size and SHA-256 content hash. Nothing is deleted automatically.")
            val groups = report?.duplicateGroups.orEmpty()
            if (groups.isEmpty()) Text("Run a storage analysis to check for duplicates.") else {
                Text("${groups.size} duplicate group(s) found", style = MaterialTheme.typography.titleMedium)
                groups.forEachIndexed { index, group ->
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Group ${index + 1} · ${formatSize(context, group.size)}", style = MaterialTheme.typography.titleSmall)
                        group.files.forEach { Text("• ${fileNameWithParent(it.uri, it.name)}", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
        }
        SectionCard("ZIP archive tools", Modifier.animateContentSize()) {
            Text("Create a ZIP from a folder or extract an existing ZIP into a folder you choose. Existing files are not overwritten.")
            OutlinedTextField(
                value = archiveName,
                onValueChange = { archiveName = it },
                label = { Text("Archive name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = { pendingAction = "zip-source"; chooseFolder.launch(null) }, enabled = !busy) {
                Text("Create ZIP from folder")
            }
            OutlinedButton(onClick = { chooseZip.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }, enabled = !busy) {
                Text("Extract ZIP archive")
            }
            when (pendingAction) {
                "zip-destination" -> TextButton(onClick = { chooseFolder.launch(null) }) { Text("Choose destination folder") }
                "extract-destination" -> Text("Choose a destination folder to finish extraction.")
                else -> Unit
            }
        }
        SectionCard("Safety") {
            Text("This screen never deletes duplicates. ZIP extraction rejects path traversal entries and stops on filename conflicts. Keep important files backed up before bulk operations.")
        }
    }
}

private fun fileNameWithParent(uri: String, name: String): String = "$name · ${Uri.parse(uri).lastPathSegment.orEmpty().takeLast(28)}"
