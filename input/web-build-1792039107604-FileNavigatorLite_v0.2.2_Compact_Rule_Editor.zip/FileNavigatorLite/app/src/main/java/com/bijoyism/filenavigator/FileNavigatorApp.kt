package com.bijoyism.filenavigator

import android.app.Application
import android.content.Context
import com.bijoyism.filenavigator.automation.Automation
import com.bijoyism.filenavigator.automation.RuleEngine
import com.bijoyism.filenavigator.automation.Scanner
import com.bijoyism.filenavigator.data.AppData
import com.bijoyism.filenavigator.notifications.Notifier
import com.bijoyism.filenavigator.storage.SafStorage
import com.bijoyism.filenavigator.worker.ReconcileScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Manual dependency injection: one place that wires everything together. */
class AppContainer(context: Context) {
    val appContext: Context = context.applicationContext
    val storage = SafStorage(context)
    val data = AppData.create(context)
    val engine = RuleEngine(storage, data)
    val automation = Automation(engine, data)
    val scanner = Scanner(engine, data, Notifier(context))
}

class FileNavigatorApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            val settings = container.data.settings.first()
            ReconcileScheduler.setEnabled(this@FileNavigatorApp, settings.autoOrganize, settings.intervalMinutes)
        }
    }
}
