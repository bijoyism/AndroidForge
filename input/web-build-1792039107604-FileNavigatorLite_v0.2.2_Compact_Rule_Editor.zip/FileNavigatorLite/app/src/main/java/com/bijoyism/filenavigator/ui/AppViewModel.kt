package com.bijoyism.filenavigator.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bijoyism.filenavigator.AppContainer
import com.bijoyism.filenavigator.data.AppSettings
import com.bijoyism.filenavigator.domain.HistoryEntry
import com.bijoyism.filenavigator.domain.Rule
import com.bijoyism.filenavigator.worker.ReconcileScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** State for Home, Activity and Settings. */
class AppViewModel(private val c: AppContainer) : ViewModel() {
    val rules: StateFlow<List<Rule>> = c.data.rules.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val history: StateFlow<List<HistoryEntry>> = c.data.history.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val settings: StateFlow<AppSettings> = c.data.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning

    private val _scanText = MutableStateFlow<String?>(null)
    val scanText: StateFlow<String?> = _scanText

    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice

    private val _grants = MutableStateFlow(c.storage.grantedRoots())
    val grants: StateFlow<List<String>> = _grants

    fun label(uri: String): String = c.storage.label(uri)

    fun scanNow() {
        if (_scanning.value) return
        viewModelScope.launch {
            _scanning.value = true
            _scanText.value = try {
                val r = c.scanner.scan()
                buildString {
                    append("${r.matching} file(s) match your rules; ${r.newMatches} new since the last scan.")
                    if (r.notified) append(" Notification sent.")
                    r.problems.forEach { append("\n• ${it.ruleName}: ${it.message}") }
                }
            } catch (e: Exception) {
                "Scan failed: ${e.message}"
            }
            _scanning.value = false
        }
    }

    fun undo(entry: HistoryEntry) {
        viewModelScope.launch {
            val result = c.engine.undo(entry)
            if (result.ok) c.data.markUndone(entry.id)
            _notice.value = result.message
        }
    }

    fun clearHistory() {
        viewModelScope.launch { c.data.clearHistory() }
    }

    fun dismissNotice() {
        _notice.value = null
    }

    fun writeBackup(uri: Uri) {
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val text = c.data.exportBackup()
                    c.appContext.contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { it.write(text) }
                        ?: error("Could not open the selected backup file")
                }
            }
            _notice.value = result.fold({ "Backup exported successfully." }, { "Backup failed: ${it.message}" })
        }
    }

    fun restoreBackup(uri: Uri) {
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val text = c.appContext.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        ?: error("Could not read the selected backup file")
                    c.data.importBackup(text)
                }
            }
            if (result.isSuccess) {
                ReconcileScheduler.setEnabled(c.appContext, false, settings.value.intervalMinutes)
            }
            _notice.value = result.fold(
                { "Backup restored. Automatic organization was left disabled for safety; review your rules before enabling it." },
                { "Restore failed: ${it.message}" }
            )
        }
    }

    fun setNotifications(on: Boolean) {
        viewModelScope.launch { c.data.setNotifications(on) }
    }

    fun setQuiet(on: Boolean) {
        viewModelScope.launch { c.data.setQuiet(on) }
    }

    fun setAutoOrganize(on: Boolean) {
        viewModelScope.launch {
            c.data.setAutoOrganize(on)
            val context = c.appContext
            ReconcileScheduler.setEnabled(context, on, settings.value.intervalMinutes)
        }
    }

    fun setIntervalMinutes(minutes: Int) {
        viewModelScope.launch {
            c.data.setIntervalMinutes(minutes)
            if (settings.value.autoOrganize) {
                ReconcileScheduler.schedule(c.appContext, minutes)
            }
        }
    }

    fun setThemeMode(mode: String) { viewModelScope.launch { c.data.setThemeMode(mode) } }
    fun setColorTheme(theme: String) { viewModelScope.launch { c.data.setColorTheme(theme) } }

    fun grant(uri: Uri) {
        c.storage.grant(uri)
        _grants.update { c.storage.grantedRoots() }
    }

    fun revoke(uri: String) {
        c.storage.revoke(uri)
        _grants.update { c.storage.grantedRoots() }
    }
}
