package com.bijoyism.filenavigator.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bijoyism.filenavigator.AppContainer
import com.bijoyism.filenavigator.storage.StorageAnalyzer
import com.bijoyism.filenavigator.storage.StorageReport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class StorageToolsViewModel(private val container: AppContainer) : ViewModel() {
    private val _report = MutableStateFlow<StorageReport?>(null)
    val report: StateFlow<StorageReport?> = _report
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    fun analyze() {
        if (_busy.value) return
        viewModelScope.launch {
            _busy.value = true
            _message.value = null
            val roots = container.storage.grantedRoots()
            _message.value = if (roots.isEmpty()) "Add a folder in Settings before scanning." else null
            if (roots.isNotEmpty()) {
                runCatching { withContext(Dispatchers.IO) { StorageAnalyzer(container.storage).analyze(roots) } }
                    .onSuccess { _report.value = it; _message.value = "Storage scan complete." }
                    .onFailure { _message.value = "Scan failed: ${it.message ?: "unknown error"}" }
            }
            _busy.value = false
        }
    }

    fun createArchive(source: Uri, destination: Uri, name: String) {
        runArchive("Creating ZIP archive…") {
            container.storage.grant(source)
            container.storage.grant(destination)
            val sourceUri = source.toString()
            val destUri = destination.toString()
            container.storage.createZip(sourceUri, destUri, name.ifBlank { "Archive.zip" })
            "ZIP archive created."
        }
    }

    fun extractArchive(archive: Uri, destination: Uri) {
        runArchive("Extracting archive…") {
            container.storage.grant(archive)
            container.storage.grant(destination)
            val count = container.storage.extractZip(archive.toString(), destination.toString())
            "Extracted $count file(s). Existing files are never overwritten."
        }
    }

    private fun runArchive(startMessage: String, operation: suspend () -> String) {
        if (_busy.value) return
        viewModelScope.launch {
            _busy.value = true
            _message.value = startMessage
            runCatching { withContext(Dispatchers.IO) { operation() } }
                .onSuccess { _message.value = it }
                .onFailure { _message.value = "Operation failed: ${it.message ?: "unknown error"}" }
            _busy.value = false
        }
    }
}
