package com.jo.dualspace

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.AlphaAnimation
import android.widget.Button
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var wallpaper: ImageView
    private lateinit var appGrid: GridLayout
    private lateinit var dock: LinearLayout
    private lateinit var spaceLabel: TextView
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var hint: TextView
    private var downX = 0f
    private var downY = 0f
    private val prefs by lazy { getSharedPreferences("dualspace_settings", MODE_PRIVATE) }

    private val isLandscape: Boolean
        get() = resources.configuration.orientation ==
            android.content.res.Configuration.ORIENTATION_LANDSCAPE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        wallpaper = findViewById(R.id.wallpaper)
        appGrid = findViewById(R.id.appGrid)
        dock = findViewById(R.id.dock)
        spaceLabel = findViewById(R.id.spaceLabel)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        hint = findViewById(R.id.hint)
        updateClockAndDate()
        applyOrientationProfile()
        populateApps()
        setupGestures()
        findViewById<View>(R.id.root).setOnLongClickListener {
            showSettings()
            true
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        applyOrientationProfile()
        populateApps()
    }

    private fun profileKey(base: String) =
        "${if (isLandscape) "landscape" else "portrait"}_$base"

    private fun applyOrientationProfile() {
        spaceLabel.text = if (isLandscape) "LANDSCAPE SPACE" else "PORTRAIT SPACE"
        appGrid.columnCount = if (isLandscape) 6 else 4
        val wallpaperString = prefs.getString(profileKey("wallpaper"), null)
        if (wallpaperString != null) {
            try {
                wallpaper.setImageURI(Uri.parse(wallpaperString))
            } catch (_: Exception) {
                wallpaper.setImageDrawable(null)
            }
        } else {
            wallpaper.setImageDrawable(null)
            wallpaper.setBackgroundColor(if (isLandscape) Color.rgb(24, 30, 52) else Color.rgb(17, 19, 26))
        }
        val accent = prefs.getInt(profileKey("accent"), Color.rgb(66, 133, 244))
        spaceLabel.setTextColor(accent)
        findViewById<View>(R.id.content).startAnimation(
            AlphaAnimation(0.65f, 1f).apply { duration = 220 }
        )
        hint.text = if (isLandscape) "Landscape layout • long-press for settings"
                    else "Portrait layout • long-press for settings"
    }

    private fun updateClockAndDate() {
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        date.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)
    }

    private fun launcherApps(): List<ResolveInfo> {
        val pm = packageManager
        return pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase(Locale.getDefault()) }
    }

    private fun populateApps() {
        appGrid.removeAllViews()
        dock.removeAllViews()
        val pm = packageManager
        val apps = launcherApps()
        apps.take(if (isLandscape) 18 else 16).forEach { info ->
            val item = createAppItem(info.loadLabel(pm).toString(), info.loadIcon(pm)) {
                pm.getLaunchIntentForPackage(info.activityInfo.packageName)?.let { startActivity(it) }
            }
            item.layoutParams = GridLayout.LayoutParams().apply {
                width = 0
                height = if (isLandscape) dp(74) else dp(88)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
            appGrid.addView(item)
        }
        listOf("Wallpaper", "Apps", "Settings").forEach { label ->
            val button = Button(this).apply {
                text = label
                textSize = 11f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener {
                    when (label) {
                        "Wallpaper" -> chooseWallpaper()
                        "Apps" -> showAppList(apps)
                        else -> showSettings()
                    }
                }
            }
            dock.addView(button, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
    }

    private fun createAppItem(label: String, icon: android.graphics.drawable.Drawable, click: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(4), dp(2), dp(4))
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }
        box.addView(ImageView(this).apply {
            setImageDrawable(icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = label
        }, LinearLayout.LayoutParams(dp(38), dp(38)))
        box.addView(TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 10f
            gravity = Gravity.CENTER
            maxLines = 2
            typeface = Typeface.create("sans", Typeface.NORMAL)
            setShadowLayer(3f, 1f, 1f, Color.BLACK)
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(30)))
        return box
    }

    private fun chooseWallpaper() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }, REQUEST_WALLPAPER)
    }

    @Deprecated("Kept for compatibility with the starter project's Android APIs")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_WALLPAPER && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            prefs.edit().putString(profileKey("wallpaper"), uri.toString()).apply()
            applyOrientationProfile()
            Toast.makeText(this, "Wallpaper saved for this orientation", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSettings() {
        val options = arrayOf(
            "Choose wallpaper for ${if (isLandscape) "landscape" else "portrait"}",
            "Change accent colour",
            "About DualSpace"
        )
        AlertDialog.Builder(this).setTitle("DualSpace settings")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> chooseWallpaper()
                    1 -> chooseAccent()
                    2 -> AlertDialog.Builder(this).setTitle("DualSpace 0.2")
                        .setMessage("A lightweight launcher prototype with separate portrait and landscape profiles.")
                        .setPositiveButton("OK", null).show()
                }
            }.setNegativeButton("Close", null).show()
    }

    private fun chooseAccent() {
        val names = arrayOf("Google blue", "Green", "Yellow", "Red")
        val colors = intArrayOf(
            Color.rgb(66, 133, 244), Color.rgb(52, 168, 83),
            Color.rgb(251, 188, 4), Color.rgb(234, 67, 53)
        )
        AlertDialog.Builder(this).setTitle("Accent for this orientation")
            .setItems(names) { _, which ->
                prefs.edit().putInt(profileKey("accent"), colors[which]).apply()
                applyOrientationProfile()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showAppList(apps: List<ResolveInfo>) {
        val pm = packageManager
        AlertDialog.Builder(this).setTitle("All apps")
            .setItems(apps.map { it.loadLabel(pm).toString() }.toTypedArray()) { _, which ->
                pm.getLaunchIntentForPackage(apps[which].activityInfo.packageName)?.let { startActivity(it) }
            }.setNegativeButton("Close", null).show()
    }

    private fun setupGestures() {
        findViewById<View>(R.id.root).setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x; downY = event.y; true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    if (abs(dx) > dp(90) && abs(dx) > abs(dy) * 1.2f) {
                        if (dx < 0) showSettings() else showAppList(launcherApps())
                        true
                    } else false
                }
                else -> false
            }
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQUEST_WALLPAPER = 410
    }
}
