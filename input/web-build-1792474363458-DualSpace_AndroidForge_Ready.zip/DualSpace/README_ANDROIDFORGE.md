# DualSpace — AndroidForge-friendly Android project

This ZIP contains a conventional Android Gradle project, not a prebuilt APK. It is arranged so a builder that imports standard Android Gradle projects can inspect/build it.

## Project details
- App: DualSpace
- Application ID: `com.jo.dualspace`
- Kotlin + XML
- Minimum Android: 8.0 / API 26
- Target SDK: 29 (chosen for broad Android 10 compatibility)
- Version: 0.2.0
- App icon: original four-colour orbit mark with a clean Google-app-inspired palette. It is not an official Google logo.

## Import / build
1. Extract this ZIP.
2. In AndroidForge, choose its option for importing an existing Android/Gradle project or uploading a source ZIP.
3. Select the extracted project folder or ZIP, depending on AndroidForge's import screen.
4. If it asks for a build configuration, use the Gradle Android project option and the `app` module.
5. Build a debug APK first. Install and test before choosing it as the default Home app.

AndroidForge interfaces and accepted archive formats can differ by version. If it rejects this archive, send a screenshot of its import screen or the exact error; do not rename project files at random.

## Current prototype features
- Launcher/Home intent
- Independent wallpaper URI and accent colour for portrait and landscape
- Adaptive icon grid column count
- Clock and date
- App list, wallpaper picker and settings dialogs
- Basic swipe shortcuts

## Important limitations
This is an early prototype, not a completed advanced launcher. Per-icon drag-and-drop positions, folders, app widgets, a gesture editor, icon-pack support, full theme editor and backup/restore are not implemented yet. The clock/date text is not a live-updating widget yet; it updates when the activity starts. The build has not been compiled in this environment, so a successful APK build is not guaranteed until tested in AndroidForge or AndroidIDE.
