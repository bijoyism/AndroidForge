# File Navigator — AndroidForge source project

A Kotlin + Jetpack Compose Android project inspired by the supplied File Navigator reference screenshots. Package: `com.bijoyism.filenavigator`. Minimum Android version: Android 8.0 (API 26).

## Build

The project is configured for JDK 17, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and compile SDK 35.

- In Android Studio: open this folder and let Gradle sync, then run `:app:assembleDebug`.
- In GitHub Actions: the included `.github/workflows/android.yml` installs Gradle and builds `app-debug.apk`.
- If AndroidForge requires a Gradle wrapper, use its wrapper/bootstrap option or build through the included GitHub Actions workflow; this archive does not include the binary Gradle wrapper JAR.

## Implemented in this source package

- Three-screen Compose UI: Home, Navigator Settings, and App Settings.
- Monochrome light/dark palette and screenshot-inspired rounded cards.
- Expandable categories and editable per-source Notify/Auto choices and enabled switches.
- Persisted source-rule settings, theme selection, storage-volume preference, and dynamic-colors preference using SharedPreferences.
- Android Storage Access Framework folder picker, with persisted URI permission requests.
- Restore-default-rules confirmation and truthful empty move-history state.
- Android 8.0+ minimum SDK configuration.

## Important implementation status

This is a UI and configuration foundation, **not yet the complete automatic file-organizing engine described in the master prompt**. The Start/Stop control currently changes the displayed preference only; it does not run a foreground monitoring service or automatically move files. Move history is intentionally empty rather than fabricated. Dynamic wallpaper colors, legal-document screens, notifications with Move/Delete actions, real MediaStore observation, and actual move/delete workflows still need implementation before production use. The folder picker stores a selected destination label/URI only in the current UI flow; full URI persistence and use by a real file-operation engine are not yet complete.

No APK build has been verified in this environment. Use AndroidForge/GitHub Actions to build and share the resulting build log if it fails.
