package com.bijoyism.filenavigator

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Ink = Color(0xFF171717)
private val Grey = Color(0xFF686868)
private val SurfaceGrey = Color(0xFFF0F0F0)
private val RowGrey = Color(0xFFE7E7E7)
private val TealGrey = Color(0xFFDDE5E5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("navigator", MODE_PRIVATE)
        setContent { FileNavigatorApp(prefs) }
    }
}

private data class SourceRule(
    val id: String, val category: String, val source: String,
    val destination: String, val enabled: Boolean = true, val auto: Boolean = false
)

private fun defaultRules() = listOf(
    SourceRule("pic-camera", "Pictures", "Camera", "Pictures/Photos", true, true),
    SourceRule("pic-screen", "Pictures", "Screenshot", "Pictures/Screenshots", true, true),
    SourceRule("pic-download", "Pictures", "Download", "Pictures/Downloads", true, true),
    SourceRule("vid-camera", "Videos", "Camera", "Videos/Camera", true, false),
    SourceRule("vid-app", "Videos", "Other App", "Videos/Other", true, false),
    SourceRule("vid-download", "Videos", "Download", "Videos/Downloads", true, false),
    SourceRule("doc-download", "Documents", "Download", "Documents/Files", true, false),
    SourceRule("apk-download", "APKs", "Download", "APKs", true, false),
    SourceRule("audio-download", "Audio", "Download", "Audio/Downloads", true, false),
    SourceRule("archive-download", "Archives", "Download", "Archives", true, false)
)

@Composable
private fun FileNavigatorApp(prefs: android.content.SharedPreferences) {
    var tab by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(prefs.getBoolean("running", false)) }
    var showVolumes by remember { mutableStateOf(prefs.getBoolean("volumes", true)) }
    var dynamicColors by remember { mutableStateOf(prefs.getBoolean("dynamic", false)) }
    var theme by remember { mutableStateOf(prefs.getString("theme", "Light") ?: "Light") }
    var rules by remember { mutableStateOf(loadRules(prefs)) }
    var folderPickerRule by remember { mutableStateOf<String?>(null) }
    var pickedFolder by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            pickedFolder = uri.toString()
            val id = folderPickerRule
            if (id != null) {
                rules = rules.map { if (it.id == id) it.copy(destination = uri.lastPathSegment ?: uri.toString()) else it }
                saveRules(prefs, rules)
                message = "Destination folder saved"
            }
        }
        folderPickerRule = null
    }
    val dark = theme == "Dark"
    val colors = if (dark) darkColorScheme(
        primary = Color.White, onPrimary = Color.Black, background = Color(0xFF101010),
        surface = Color(0xFF191919), onSurface = Color(0xFFF4F4F4), onBackground = Color.White,
        secondaryContainer = Color(0xFF303030), onSecondaryContainer = Color.White
    ) else lightColorScheme(
        primary = Ink, onPrimary = Color.White, background = Color(0xFFFAFAFA),
        surface = Color.White, onSurface = Ink, onBackground = Ink,
        secondaryContainer = RowGrey, onSecondaryContainer = Ink
    )
    MaterialTheme(colorScheme = colors) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Dashboard, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Tune, null) }, label = { Text("Navigator Settings") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("App Settings") })
                }
            }, snackbarHost = { SnackbarHost(remember { SnackbarHostState() }) }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(Modifier.padding(padding), running, onToggle = {
                    running = !running
                    prefs.edit().putBoolean("running", running).apply()
                    message = if (running) "Navigator enabled. Background auto-organization is not yet active in this build." else "Navigator stopped"
                }, message = message, onDismissMessage = { message = null })
                1 -> NavigatorSettingsScreen(Modifier.padding(padding), rules, onRuleChange = { updated -> rules = updated; saveRules(prefs, updated) }, onPickFolder = { id -> folderPickerRule = id; folderPicker.launch(null) }, onReset = { rules = defaultRules(); saveRules(prefs, rules); message = "Default rules restored" })
                else -> AppSettingsScreen(Modifier.padding(padding), showVolumes, { showVolumes = it; prefs.edit().putBoolean("volumes", it).apply() }, theme, { theme = it; prefs.edit().putString("theme", it).apply() }, dynamicColors, { dynamicColors = it; prefs.edit().putBoolean("dynamic", it).apply() })
            }
        }
    }
}

private fun loadRules(prefs: android.content.SharedPreferences): List<SourceRule> {
    val raw = prefs.getString("rules", null) ?: return defaultRules()
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            SourceRule(o.getString("id"), o.getString("category"), o.getString("source"), o.getString("destination"), o.optBoolean("enabled", true), o.optBoolean("auto", false))
        }
    } catch (_: Exception) { defaultRules() }
}
private fun saveRules(prefs: android.content.SharedPreferences, rules: List<SourceRule>) {
    val arr = JSONArray()
    rules.forEach { r -> arr.put(JSONObject().put("id", r.id).put("category", r.category).put("source", r.source).put("destination", r.destination).put("enabled", r.enabled).put("auto", r.auto)) }
    prefs.edit().putString("rules", arr.toString()).apply()
}

@Composable
private fun ScreenTitle(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 30.dp, bottom = 18.dp)) {
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Light, lineHeight = 36.sp)
        if (subtitle != null) { Spacer(Modifier.height(6.dp)); Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 15.sp) }
    }
}

@Composable
private fun HomeScreen(modifier: Modifier, running: Boolean, onToggle: () -> Unit, message: String?, onDismissMessage: () -> Unit) {
    Column(modifier.fillMaxSize()) {
        ScreenTitle("File Navigator")
        LazyColumn(contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            item {
                Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(22.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.FolderOpen, null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(30.dp))
                            Spacer(Modifier.width(14.dp)); Text("Navigator:", fontSize = 22.sp, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.width(7.dp)); Text(if (running) "Active" else "Stopped", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 21.sp)
                        }
                        Spacer(Modifier.height(22.dp))
                        Button(onClick = onToggle, modifier = Modifier.fillMaxWidth().height(60.dp), shape = RoundedCornerShape(40.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onSurface, contentColor = MaterialTheme.colorScheme.surface)) {
                            Icon(if (running) Icons.Default.Pause else Icons.Default.PlayArrow, null, modifier = Modifier.size(28.dp)); Spacer(Modifier.width(10.dp)); Text(if (running) "Stop" else "Start", fontSize = 20.sp)
                        }
                        if (message != null) { Spacer(Modifier.height(12.dp)); Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp); TextButton(onClick = onDismissMessage) { Text("Dismiss") } }
                    }
                }
            }
            item {
                Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 3.dp, modifier = Modifier.fillMaxWidth().heightIn(min = 270.dp)) {
                    Column(Modifier.padding(22.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.History, null, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(14.dp)); Text("Move History", fontSize = 22.sp, fontWeight = FontWeight.Medium); Spacer(Modifier.weight(1f)); IconButton(onClick = {}) { Icon(Icons.Default.MoreVert, "History options") } }
                        Spacer(Modifier.height(18.dp)); Text("No file movements yet", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 16.sp)
                        Spacer(Modifier.height(6.dp)); Text("Real operations will appear here when file organization is implemented and enabled.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun NavigatorSettingsScreen(modifier: Modifier, rules: List<SourceRule>, onRuleChange: (List<SourceRule>) -> Unit, onPickFolder: (String) -> Unit, onReset: () -> Unit) {
    val categories = listOf("Pictures", "Videos", "Audio", "Documents", "APKs", "Archives", "Other")
    var expanded by remember { mutableStateOf(setOf("Pictures", "Videos")) }
    var showReset by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize()) {
        ScreenTitle("Navigator Settings")
        Row(Modifier.padding(horizontal = 22.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Navigated File Types", fontSize = 22.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            FilledTonalIconButton(onClick = { expanded = if (expanded.size == categories.size) emptySet() else categories.toSet() }, shape = CircleShape) { Icon(Icons.Default.Edit, "Expand or collapse categories") }
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(categories) { category ->
                val categoryRules = rules.filter { it.category == category }
                Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(18.dp), shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth().animateContentSize()) {
                    Column {
                        Row(Modifier.fillMaxWidth().clickable { expanded = if (category in expanded) expanded - category else expanded + category }.padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(categoryIcon(category), null, modifier = Modifier.size(28.dp)); Spacer(Modifier.width(14.dp)); Text(category, fontSize = 19.sp, modifier = Modifier.weight(1f)); Icon(if (category in expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
                        }
                        if (category in expanded) {
                            if (categoryRules.isEmpty()) Text("No source rules configured", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 18.dp, bottom = 14.dp))
                            categoryRules.forEach { rule ->
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f))
                                Column(Modifier.fillMaxWidth().background(if (MaterialTheme.colorScheme.background == Color(0xFFFAFAFA)) TealGrey.copy(alpha = .55f) else Color(0xFF242424)).padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(sourceIcon(rule.source), null, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(10.dp)); Text(rule.source, fontSize = 16.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            FilterChip(selected = !rule.auto, onClick = { onRuleChange(rules.map { if (it.id == rule.id) it.copy(auto = false) else it }) }, label = { Text("Notify", fontSize = 12.sp) })
                                            Spacer(Modifier.width(4.dp)); FilterChip(selected = rule.auto, onClick = { onRuleChange(rules.map { if (it.id == rule.id) it.copy(auto = true) else it }) }, label = { Text("Auto", fontSize = 12.sp) })
                                        }
                                        Checkbox(checked = rule.enabled, onCheckedChange = { checked -> onRuleChange(rules.map { if (it.id == rule.id) it.copy(enabled = checked) else it }) })
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("/${rule.destination}", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        TextButton(onClick = { onPickFolder(rule.id) }) { Text("Choose") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            item { OutlinedButton(onClick = { showReset = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Restore, null); Spacer(Modifier.width(8.dp)); Text("Restore default rules") } }
        }
    }
    if (showReset) AlertDialog(onDismissRequest = { showReset = false }, title = { Text("Restore default rules?") }, text = { Text("Your current source-rule settings will be replaced.") }, confirmButton = { TextButton(onClick = { onReset(); showReset = false }) { Text("Restore") } }, dismissButton = { TextButton(onClick = { showReset = false }) { Text("Cancel") } })
}

@Composable
private fun AppSettingsScreen(modifier: Modifier, showVolumes: Boolean, onVolumes: (Boolean) -> Unit, theme: String, onTheme: (String) -> Unit, dynamic: Boolean, onDynamic: (Boolean) -> Unit) {
    Column(modifier.fillMaxSize()) {
        ScreenTitle("App Settings")
        LazyColumn(contentPadding = PaddingValues(start = 18.dp, top = 8.dp, end = 18.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                SettingsCard("General", Icons.Default.Storage) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Storage, null); Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text("Show storage volume names", fontSize = 17.sp); Text("Example: primary:Folder/OtherFolder instead of Folder/OtherFolder", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, lineHeight = 19.sp) }; Switch(checked = showVolumes, onCheckedChange = onVolumes) }
                }
            }
            item {
                SettingsCard("Appearance", Icons.Default.Contrast) {
                    Text("Theme", fontSize = 17.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        listOf("Light", "Default", "Dark").forEach { option ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onTheme(option) }.padding(8.dp)) {
                                Text(option, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(8.dp))
                                Box(Modifier.size(48.dp).clip(CircleShape).background(when (option) { "Light" -> Color.White; "Dark" -> Color.Black; else -> Color(0xFFB8B8B8) }).then(if (theme == option) Modifier.padding(0.dp) else Modifier), contentAlignment = Alignment.Center) { if (theme == option) Surface(shape = CircleShape, color = Color.Transparent, border = BorderStroke(2.dp, MaterialTheme.colorScheme.onSurface), modifier = Modifier.fillMaxSize()) {} }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Palette, null); Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text("Dynamic Colors", fontSize = 17.sp); Text("Use wallpaper-derived colors where supported", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp) }; Switch(checked = dynamic, onCheckedChange = onDynamic) }
                    if (dynamic) Text("This build keeps a monochrome palette; wallpaper-derived colors are not wired up yet.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                }
            }
            item {
                SettingsCard("Legal", Icons.Default.Policy) {
                    Row(Modifier.fillMaxWidth().clickable { }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Policy, null); Spacer(Modifier.width(14.dp)); Text("Privacy Policy", fontSize = 17.sp) }
                    Row(Modifier.fillMaxWidth().clickable { }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Copyright, null); Spacer(Modifier.width(14.dp)); Text("License", fontSize = 17.sp) }
                }
            }
            item { Text("File Navigator 1.0.0 · Android 8.0+", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(8.dp)) }
        }
    }
}

@Composable
private fun SettingsCard(title: String, icon: ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Medium)
            content()
        }
    }
}

private fun categoryIcon(category: String): ImageVector = when (category) {
    "Pictures" -> Icons.Default.Image
    "Videos" -> Icons.Default.Movie
    "Audio" -> Icons.Default.AudioFile
    "Documents" -> Icons.Default.Description
    "APKs" -> Icons.Default.Android
    "Archives" -> Icons.Default.Archive
    else -> Icons.Default.InsertDriveFile
}
private fun sourceIcon(source: String): ImageVector = when (source) {
    "Camera" -> Icons.Default.CameraAlt
    "Screenshot" -> Icons.Default.PhoneAndroid
    "Download" -> Icons.Default.Download
    else -> Icons.Default.Apps
}
