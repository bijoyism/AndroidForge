package com.bijoyism.filenavigator.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bijoyism.filenavigator.AppContainer
import com.bijoyism.filenavigator.FileNavigatorApp
import com.bijoyism.filenavigator.navigation.Destination

private fun iconFor(destination: Destination): ImageVector = when (destination) {
    Destination.Home -> Icons.Filled.Home
    Destination.Files -> Icons.Filled.Menu
    Destination.Automation -> Icons.Filled.Refresh
    Destination.Activity -> Icons.Filled.Info
    Destination.Settings -> Icons.Filled.Settings
}

private class VmFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val created: ViewModel = when {
            modelClass.isAssignableFrom(AppViewModel::class.java) -> AppViewModel(container)
            modelClass.isAssignableFrom(FilesViewModel::class.java) -> FilesViewModel(container)
            modelClass.isAssignableFrom(AutomationViewModel::class.java) -> AutomationViewModel(container)
            else -> throw IllegalArgumentException("Unknown ViewModel ${modelClass.name}")
        }
        return created as T
    }
}

@Composable
fun AppScaffold(requested: Destination?, onRequestHandled: () -> Unit) {
    val container = (LocalContext.current.applicationContext as FileNavigatorApp).container
    val factory = remember { VmFactory(container) }
    val appVm: AppViewModel = viewModel(factory = factory)
    val filesVm: FilesViewModel = viewModel(factory = factory)
    val autoVm: AutomationViewModel = viewModel(factory = factory)
    var selected by rememberSaveable { mutableStateOf(Destination.Home) }

    LaunchedEffect(requested) {
        if (requested != null) {
            selected = requested
            onRequestHandled()
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                Destination.entries.forEach { destination ->
                    NavigationBarItem(
                        selected = destination == selected,
                        onClick = { selected = destination },
                        icon = { Icon(iconFor(destination), contentDescription = destination.label) },
                        label = { Text(destination.label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            Crossfade(targetState = selected, animationSpec = tween(durationMillis = 260), label = "screen-transition") { destination ->
            when (destination) {
                Destination.Home -> HomeScreen(appVm, onOpen = { selected = it })
                Destination.Files -> {
                    val rules by autoVm.rules.collectAsState()
                    FilesScreen(filesVm, rules)
                }
                Destination.Automation -> AutomationScreen(autoVm)
                Destination.Activity -> ActivityScreen(appVm)
                Destination.Settings -> SettingsScreen(appVm)
            }
            }
        }
    }
}
