package com.bijoyism.filenavigator.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

private val scanIntervals = listOf(15, 30, 60, 180, 360, 720, 1440)

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsState()
    val grants by vm.grants.collectAsState()
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> vm.setNotifications(granted) }
    val addFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) vm.grant(uri) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineLarge)
        Text("Make File Navigator feel like yours.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)

        SectionCard("Automatic organization", Modifier.animateContentSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Run in the background", style = MaterialTheme.typography.titleMedium)
                    Text("Automatically move files that match your enabled rules. No confirmation for each move.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = settings.autoOrganize, onCheckedChange = vm::setAutoOrganize)
            }
            AnimatedVisibility(visible = settings.autoOrganize) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Check for matching files", style = MaterialTheme.typography.titleSmall)
                    Text("Every ${intervalLabel(settings.intervalMinutes)}", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        listOf(15, 30, 60).forEach { mins ->
                            FilterChip(selected = settings.intervalMinutes == mins, onClick = { vm.setIntervalMinutes(mins) }, label = { Text(intervalLabel(mins)) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        listOf(180, 360, 720, 1440).forEach { mins ->
                            FilterChip(selected = settings.intervalMinutes == mins, onClick = { vm.setIntervalMinutes(mins) }, label = { Text(intervalLabel(mins)) })
                        }
                    }
                    Text("Android may delay background checks to save battery. The shortest supported interval is 15 minutes.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Only enabled rules run. Folder access must remain authorized, and files are never silently overwritten.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        SectionCard("Appearance", Modifier.animateContentSize()) {
            Text("Theme mode", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("system" to "System", "light" to "Light", "dark" to "Dark").forEach { (key, label) ->
                    FilterChip(selected = settings.themeMode == key, onClick = { vm.setThemeMode(key) }, label = { Text(label) })
                }
            }
            Text("Colour palette", style = MaterialTheme.typography.titleSmall)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("dynamic" to "Wallpaper colours", "blue" to "Ocean blue", "green" to "Sage green", "purple" to "Violet", "orange" to "Sunset").forEach { (key, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text(label, Modifier.weight(1f))
                        if (settings.colorTheme == key) Text("Selected", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                        TextButton(onClick = { vm.setColorTheme(key) }) { Text(if (settings.colorTheme == key) "Active" else "Apply") }
                    }
                }
            }
            Text("Expressive rounded surfaces and motion are used throughout the interface. Wallpaper colours require Android 12 or newer; other palettes work on older devices too.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SectionCard("Notifications") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Notify about new matching files", Modifier.weight(1f))
                Switch(checked = settings.notifications, onCheckedChange = { on ->
                    val needsPermission = on && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    if (needsPermission) permission.launch(Manifest.permission.POST_NOTIFICATIONS) else vm.setNotifications(on)
                })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Quiet mode (scan silently, no notifications)", Modifier.weight(1f))
                Switch(checked = settings.quiet, onCheckedChange = vm::setQuiet)
            }
        }

        SectionCard("Authorized folders") {
            if (grants.isEmpty()) Text("No folders authorized yet.")
            grants.forEach { uri ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text(vm.label(uri), Modifier.weight(1f))
                    TextButton(onClick = { vm.revoke(uri) }) { Text("Revoke") }
                }
            }
            OutlinedButton(onClick = { addFolder.launch(null) }) { Text("Add folder") }
        }

        SectionCard("About") {
            Text("File Navigator Lite keeps rules and history on this device. Background checks are scheduled by Android and may not run at the exact selected minute.", style = MaterialTheme.typography.bodyMedium)
        }
    }
}

private fun intervalLabel(minutes: Int): String = when {
    minutes < 60 -> "${minutes}m"
    minutes == 60 -> "1h"
    minutes % 60 == 0 && minutes < 1440 -> "${minutes / 60}h"
    else -> "24h"
}
