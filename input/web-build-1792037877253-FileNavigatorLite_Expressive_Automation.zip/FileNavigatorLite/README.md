# File Navigator Lite

Lightweight Android file manager with rule-based automatic organization.
Kotlin, Jetpack Compose, Material 3, MVVM, DataStore, WorkManager. Min SDK 29 (Android 10).
Independent implementation, not derived from w2sv/FileNavigator.

## Build the APK without a PC
1. Create a GitHub repo and upload this folder's contents (web UI works).
2. Actions > **Build APK** runs: format check, unit tests, lint, debug build.
3. Download artifact **FileNavigatorLite-debug** from the finished run, unzip, install `app-debug.apk`.
4. If the format check fails, run Actions > **Auto-format (manual)**; it commits the fix, then Build APK re-runs.

No Gradle wrapper is committed (it cannot be generated offline). CI uses Gradle 8.9 through `gradle/actions/setup-gradle`.

## Status (honest)
This code was written without being compiled or run. It has not been built, tested on a device, or run through CI yet. Expect to fix a few compile, lint or format errors on the first CI run. Acceptance criteria that need a device (install, browsing, rule execution, background detection) are untested.

See `docs/` for Android 10 notes, permissions and privacy, known limitations, and Redmi 9i test steps.

## Layout
`ui/` screens and view models, `navigation/`, `domain/` models, rule matcher and storage interface, `data/` DataStore,
`storage/` Storage Access Framework implementation, `automation/` rule engine and scanner, `notifications/`, `worker/`, `history/`, `util/`.
Unit tests live in `app/src/test` and run against an in-memory fake storage.


## Automatic organization and appearance

Settings includes a periodic background organizer (15 minutes to 24 hours), theme mode (System/Light/Dark), and colour palettes (wallpaper/dynamic, Ocean Blue, Sage Green, Violet, Sunset). Background organization is off by default; enable it after configuring and enabling rules and granting source/destination folder access. Android WorkManager runs periodically and may delay execution for battery optimization. The app never silently overwrites conflicts.
