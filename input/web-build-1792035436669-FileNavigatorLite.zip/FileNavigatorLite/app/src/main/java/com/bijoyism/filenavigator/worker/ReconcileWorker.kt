package com.bijoyism.filenavigator.worker

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.bijoyism.filenavigator.FileNavigatorApp
import java.util.concurrent.TimeUnit

/** Periodic reconciliation: finds files that appeared while the app was closed. */
class ReconcileWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val container = (applicationContext as FileNavigatorApp).container
        try {
            container.scanner.scan()
        } catch (e: Exception) {
            Log.w("FileNavigator", "Reconcile failed", e)
        }
        return Result.success()
    }
}

object ReconcileScheduler {
    fun schedule(context: Context) {
        val request = PeriodicWorkRequestBuilder<ReconcileWorker>(30, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("reconcile", ExistingPeriodicWorkPolicy.KEEP, request)
    }
}
