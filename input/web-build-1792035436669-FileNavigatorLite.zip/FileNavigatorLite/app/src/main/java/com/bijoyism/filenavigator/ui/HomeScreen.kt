package com.bijoyism.filenavigator.ui

import android.content.Context
import android.os.StatFs
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.bijoyism.filenavigator.history.route
import com.bijoyism.filenavigator.navigation.Destination
import com.bijoyism.filenavigator.util.formatSize

private fun storageSummary(context: Context): Pair<Long, Long>? {
    val dir = context.getExternalFilesDir(null) ?: return null
    return runCatching {
        val stat = StatFs(dir.path)
        stat.totalBytes to stat.availableBytes
    }.getOrNull()
}

@Composable
fun HomeScreen(vm: AppViewModel, onOpen: (Destination) -> Unit) {
    val context = LocalContext.current
    val rules by vm.rules.collectAsState()
    val history by vm.history.collectAsState()
    val scanning by vm.scanning.collectAsState()
    val scanText by vm.scanText.collectAsState()
    val storage = remember { storageSummary(context) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("File Navigator Lite", style = MaterialTheme.typography.headlineSmall)
        Button(onClick = { vm.scanNow() }, enabled = !scanning, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text(if (scanning) "Scanning…" else "Scan now")
        }
        if (scanning) LinearProgressIndicator(Modifier.fillMaxWidth())
        scanText?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }

        SectionCard("Automation") {
            val enabled = rules.count { it.enabled }
            if (rules.isEmpty()) {
                Text("No rules yet. Create one to start organizing files automatically.")
            } else {
                Text("$enabled of ${rules.size} rule(s) enabled")
            }
            TextButton(onClick = { onOpen(Destination.Automation) }) { Text(if (rules.isEmpty()) "Create a rule" else "Manage rules") }
        }

        SectionCard("Storage") {
            if (storage == null) {
                Text("Storage information is not available on this device.")
            } else {
                val (total, free) = storage
                val used = (total - free).coerceAtLeast(0)
                LinearProgressIndicator(progress = { if (total > 0) used.toFloat() / total else 0f }, modifier = Modifier.fillMaxWidth())
                Text("${formatSize(context, used)} used of ${formatSize(context, total)} (${formatSize(context, free)} free)")
            }
        }

        SectionCard("Recent activity") {
            if (history.isEmpty()) {
                Text("Nothing yet.")
            } else {
                history.take(5).forEach { e ->
                    Text("${if (e.success) "✓" else "✗"} ${e.type.lowercase()} ${e.name}", style = MaterialTheme.typography.bodyMedium)
                    Text(e.route(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = { onOpen(Destination.Activity) }) { Text("See all") }
            }
        }
    }
}
