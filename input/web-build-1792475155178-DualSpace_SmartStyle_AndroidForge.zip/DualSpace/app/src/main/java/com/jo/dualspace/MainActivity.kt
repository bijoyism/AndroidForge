package com.jo.dualspace

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.AlphaAnimation
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var wallpaper: ImageView
    private lateinit var appGrid: GridLayout
    private lateinit var dock: LinearLayout
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var greeting: TextView
    private lateinit var sectionTitle: TextView
    private var downX = 0f
    private var downY = 0f
    private val prefs by lazy { getSharedPreferences("dualspace_settings", MODE_PRIVATE) }
    private val isLandscape: Boolean
        get() = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        wallpaper = findViewById(R.id.wallpaper)
        appGrid = findViewById(R.id.appGrid)
        dock = findViewById(R.id.dock)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        greeting = findViewById(R.id.greeting)
        sectionTitle = findViewById(R.id.sectionTitle)

        updateClockAndDate()
        applyProfile()
        renderApps()
        setupGestures()

        findViewById<View>(R.id.root).setOnLongClickListener {
            showSettings()
            true
        }
        findViewById<View>(R.id.searchBar).setOnClickListener { showAppDrawer() }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        applyProfile()
        renderApps()
    }

    private fun key(name: String) = "${if (isLandscape) "landscape" else "portrait"}_$name"

    private fun updateClockAndDate() {
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        date.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)
    }

    private fun applyProfile() {
        greeting.text = if (isLandscape) "LANDSCAPE SPACE" else "PORTRAIT SPACE"
        appGrid.columnCount = if (isLandscape) 6 else 4
        sectionTitle.text = if (isLandscape) "Quick launch" else "Favourites"
        val uriText = prefs.getString(key("wallpaper"), null)
        if (uriText != null) {
            try { wallpaper.setImageURI(Uri.parse(uriText)) }
            catch (_: Exception) { wallpaper.setImageDrawable(null) }
        } else {
            wallpaper.setImageDrawable(null)
            wallpaper.setBackgroundColor(if (isLandscape) Color.rgb(228, 237, 250) else Color.rgb(247, 248, 252))
        }
        val lightText = prefs.getBoolean(key("light_text"), false)
        val textColor = if (lightText) Color.WHITE else Color.rgb(23, 26, 34)
        clock.setTextColor(textColor)
        sectionTitle.setTextColor(textColor)
        findViewById<View>(R.id.content).startAnimation(AlphaAnimation(0.88f, 1f).apply { duration = 180 })
    }

    private fun apps(): List<ResolveInfo> {
        val pm = packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase(Locale.getDefault()) }
    }

    private fun renderApps() {
        appGrid.removeAllViews()
        dock.removeAllViews()
        val all = apps()
        val favourites = prefs.getString(key("favourites"), "")!!
            .split("|").filter { it.isNotBlank() }.toSet()
        val chosen = if (favourites.isEmpty()) all.take(if (isLandscape) 12 else 8)
                     else all.filter { it.activityInfo.packageName in favourites }.take(18)
        val shown = if (chosen.isEmpty()) all.take(if (isLandscape) 12 else 8) else chosen

        shown.forEach { info ->
            val item = appTile(info) {
                packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)?.let { startActivity(it) }
            }
            item.layoutParams = GridLayout.LayoutParams().apply {
                width = 0
                height = if (isLandscape) dp(78) else dp(88)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
            appGrid.addView(item)
            item.setOnLongClickListener {
                val options = arrayOf("Launch app", "Set as favourite", "Remove from favourites")
                AlertDialog.Builder(this).setTitle(info.loadLabel(packageManager).toString())
                    .setItems(options) { _, which ->
                        when (which) {
                            0 -> packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)?.let { startActivity(it) }
                            1 -> saveFavourite(info.activityInfo.packageName, true)
                            2 -> saveFavourite(info.activityInfo.packageName, false)
                        }
                    }.show()
                true
            }
        }

        val dockItems = listOf("All apps", "Wallpaper", "Settings")
        dockItems.forEach { label ->
            val button = Button(this).apply {
                text = label
                textSize = 11f
                isAllCaps = false
                setTextColor(Color.rgb(48, 55, 70))
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener {
                    when (label) {
                        "All apps" -> showAppDrawer()
                        "Wallpaper" -> chooseWallpaper()
                        else -> showSettings()
                    }
                }
            }
            dock.addView(button, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
    }

    private fun appTile(info: ResolveInfo, click: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(5), dp(3), dp(5))
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }
        box.addView(ImageView(this).apply {
            setImageDrawable(info.loadIcon(packageManager))
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = info.loadLabel(packageManager).toString()
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        box.addView(TextView(this).apply {
            text = info.loadLabel(packageManager).toString()
            setTextColor(if (prefs.getBoolean(key("light_text"), false)) Color.WHITE else Color.rgb(48, 55, 70))
            textSize = 10f
            gravity = Gravity.CENTER
            maxLines = 2
            typeface = Typeface.create("sans", Typeface.NORMAL)
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(30)))
        return box
    }

    private fun saveFavourite(packageName: String, add: Boolean) {
        val set = prefs.getString(key("favourites"), "")!!.split("|").filter { it.isNotBlank() }.toMutableSet()
        if (add) set.add(packageName) else set.remove(packageName)
        prefs.edit().putString(key("favourites"), set.joinToString("|")).apply()
        renderApps()
        Toast.makeText(this, if (add) "Favourite saved for this orientation" else "Favourite removed", Toast.LENGTH_SHORT).show()
    }

    private fun showAppDrawer() {
        val list = apps()
        val labels = list.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("All apps")
            .setItems(labels) { _, which ->
                packageManager.getLaunchIntentForPackage(list[which].activityInfo.packageName)?.let { startActivity(it) }
            }.setPositiveButton("Search") { _, _ -> showSearchDialog() }
            .setNegativeButton("Close", null).show()
    }

    private fun showSearchDialog() {
        val field = EditText(this).apply { hint = "Type an app name" }
        AlertDialog.Builder(this).setTitle("Search apps").setView(field)
            .setPositiveButton("Search") { _, _ ->
                val query = field.text.toString().trim()
                val match = apps().firstOrNull { it.loadLabel(packageManager).toString().contains(query, true) }
                if (match != null) packageManager.getLaunchIntentForPackage(match.activityInfo.packageName)?.let { startActivity(it) }
                else Toast.makeText(this, "No matching app found", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun chooseWallpaper() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }, REQUEST_WALLPAPER)
    }

    @Deprecated("Compatible with the starter Android API level")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_WALLPAPER && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.edit().putString(key("wallpaper"), uri.toString()).apply()
            applyProfile()
            Toast.makeText(this, "Wallpaper saved for this orientation", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSettings() {
        val options = arrayOf(
            "Set wallpaper for this orientation",
            "Choose favourite apps",
            "Toggle light/dark icon labels",
            "About DualSpace"
        )
        AlertDialog.Builder(this).setTitle("Home settings")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> chooseWallpaper()
                    1 -> showFavouritePicker()
                    2 -> {
                        prefs.edit().putBoolean(key("light_text"), !prefs.getBoolean(key("light_text"), false)).apply()
                        applyProfile(); renderApps()
                    }
                    3 -> AlertDialog.Builder(this).setTitle("DualSpace 0.3")
                        .setMessage("An orientation-aware launcher prototype with separate home spaces, wallpapers and favourite apps.")
                        .setPositiveButton("OK", null).show()
                }
            }.setNegativeButton("Close", null).show()
    }

    private fun showFavouritePicker() {
        val list = apps()
        val current = prefs.getString(key("favourites"), "")!!.split("|").toSet()
        val labels = list.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        val checked = BooleanArray(list.size) { list[it].activityInfo.packageName in current }
        AlertDialog.Builder(this).setTitle("Select favourites")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Save") { _, _ ->
                val chosen = list.indices.filter { checked[it] }.map { list[it].activityInfo.packageName }
                prefs.edit().putString(key("favourites"), chosen.joinToString("|")).apply()
                renderApps()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun setupGestures() {
        findViewById<View>(R.id.root).setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.x; downY = event.y; true }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    if (abs(dy) > dp(85) && abs(dy) > abs(dx) * 1.2f) {
                        if (dy < 0) showAppDrawer() else showSettings()
                        true
                    } else if (abs(dx) > dp(100) && abs(dx) > abs(dy) * 1.2f) {
                        if (dx < 0) showSettings() else showAppDrawer()
                        true
                    } else false
                }
                else -> false
            }
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object { private const val REQUEST_WALLPAPER = 410 }
}
