# DualSpace 0.3 — AndroidForge import package

This is a standard Android Gradle source project prepared for an AndroidForge-style source ZIP import.

## Features
- User-provided app icon, installed as the launcher icon in density-specific PNG resources
- Kotlin + XML; application ID `com.jo.dualspace`
- Minimum Android 8.0 / API 26; target SDK 29 for Android 10 compatibility
- Independent portrait and landscape wallpaper profiles
- Orientation-dependent grid size and separately saved favourite apps
- Clock/date header, search entry point, favourite app tiles, bottom action dock
- Swipe up to open the app drawer, swipe down for home settings
- Long-press an app tile to set/remove it as a favourite
- Basic light/dark icon-label contrast setting

## Import
1. Upload or import this ZIP using AndroidForge's existing Android/Gradle project option.
2. Select the `app` module if prompted.
3. Build a debug APK and install it.
4. Select DualSpace as your Home app in Android's launcher chooser.

AndroidForge options may differ by version. If this ZIP is not accepted, share the import error/screenshot so the project can be adjusted to that builder.

## Notes
This is a prototype inspired by the general organization of category-focused Android launchers, not a copy of Smart Launcher. The current app drawer is a simple native dialog, not yet a full categorized drawer. Built-in clock/date are header views; a live clock service, draggable widget system, folders, icon packs, per-icon position persistence, advanced themes and full gesture editor remain future work. Source has not been compiled in this environment.
