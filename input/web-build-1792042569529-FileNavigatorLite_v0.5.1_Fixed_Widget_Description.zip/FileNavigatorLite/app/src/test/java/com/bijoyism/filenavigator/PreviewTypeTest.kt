package com.bijoyism.filenavigator

import com.bijoyism.filenavigator.preview.PreviewType
import com.bijoyism.filenavigator.preview.previewType
import org.junit.Assert.assertEquals
import org.junit.Test

class PreviewTypeTest {
    @Test fun routesCommonPreviewFormats() {
        assertEquals(PreviewType.IMAGE, previewType("photo.webp", null))
        assertEquals(PreviewType.TEXT, previewType("notes.md", null))
        assertEquals(PreviewType.PDF, previewType("manual.pdf", "application/pdf"))
        assertEquals(PreviewType.AUDIO, previewType("song.mp3", null))
        assertEquals(PreviewType.VIDEO, previewType("clip.mp4", null))
        assertEquals(PreviewType.ARCHIVE, previewType("backup.zip", null))
        assertEquals(PreviewType.APK, previewType("app.apk", null))
        assertEquals(PreviewType.EXTERNAL, previewType("unknown.bin", null))
    }

    @Test fun mimeTypeTakesPartInImageRouting() {
        assertEquals(PreviewType.IMAGE, previewType("blob", "image/png"))
    }
}
