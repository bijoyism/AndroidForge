package com.bijoyism.filenavigator

import com.bijoyism.filenavigator.security.PinSecurity
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PinSecurityTest {
    @Test fun hashVerifiesCorrectPinAndRejectsWrongPin() {
        val encoded = PinSecurity.hash("4826")
        assertTrue(PinSecurity.verify("4826", encoded))
        assertFalse(PinSecurity.verify("4827", encoded))
        assertFalse(PinSecurity.verify("4826", null))
    }

    @Test fun saltsMakeHashesDifferent() {
        assertNotEquals(PinSecurity.hash("4826"), PinSecurity.hash("4826"))
    }

    @Test fun pinLengthAndDigitsAreValidated() {
        assertTrue(runCatching { PinSecurity.hash("123") }.isFailure)
        assertTrue(runCatching { PinSecurity.hash("12a4") }.isFailure)
        assertTrue(runCatching { PinSecurity.hash("123456789") }.isFailure)
    }
}
