package com.bijoyism.filenavigator

import com.bijoyism.filenavigator.domain.BatchRenamePlanner
import com.bijoyism.filenavigator.domain.FileEntry
import com.bijoyism.filenavigator.domain.FileQuery
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FileQueryTest {
    private val image = FileEntry("uri:1", "Holiday.JPG", 2048, "image/jpeg", 100L, false)
    private val hidden = FileEntry("uri:2", ".cache", 20, "text/plain", 100L, false)

    @Test fun filtersComposeAndIgnoreCase() {
        assertTrue(FileQuery(text = "holiday", extension = ".jpg", mimePrefix = "image/", minBytes = 1000).matches(image))
        assertFalse(FileQuery(extension = "png").matches(image))
        assertFalse(FileQuery().matches(hidden))
        assertTrue(FileQuery(includeHidden = true).matches(hidden))
    }

    @Test fun numberedRenamePreservesExtensions() {
        assertEquals(listOf("a.txt" to "IMG_001_a.txt", "b" to "IMG_002_b"),
            BatchRenamePlanner.numbered(listOf("a.txt", "b"), prefix = "IMG_", width = 3))
    }

    @Test fun replaceRequiresNonEmptySearch() {
        assertEquals("photo-final.jpg", BatchRenamePlanner.replace(listOf("photo-old.jpg"), "old", "final").single().second)
    }

    @Test fun sizeAndModificationWindowsAreInclusive() {
        val query = FileQuery(minBytes = 2048, maxBytes = 2048, modifiedAfterMillis = 100L, modifiedBeforeMillis = 100L)
        assertTrue(query.matches(image))
        assertFalse(query.copy(maxBytes = 2047).matches(image))
        assertFalse(query.copy(modifiedAfterMillis = 101L).matches(image))
    }

    @Test fun batchRenameRejectsPathSeparators() {
        val prefixRejected = runCatching { BatchRenamePlanner.numbered(listOf("a.txt"), prefix = "../") }
        val replacementRejected = runCatching { BatchRenamePlanner.replace(listOf("a.txt"), "a", "folder/name") }
        assertTrue(prefixRejected.isFailure)
        assertTrue(replacementRejected.isFailure)
    }

    @Test fun dotfilesKeepTheirWholeNameWhenNumbered() {
        assertEquals(".env" to "001_.env", BatchRenamePlanner.numbered(listOf(".env")).single())
    }
}