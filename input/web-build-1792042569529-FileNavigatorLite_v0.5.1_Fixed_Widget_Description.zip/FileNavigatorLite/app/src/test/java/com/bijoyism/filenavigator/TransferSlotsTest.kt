package com.bijoyism.filenavigator

import com.bijoyism.filenavigator.domain.TransferSlots
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TransferSlotsTest {
    @Test fun slotAssignmentIsStableAndWithinConfiguredRange() {
        val id = "transfer-example-123"
        val slot = TransferSlots.slotFor(id, 3)
        assertEquals(slot, TransferSlots.slotFor(id, 3))
        assertTrue(slot in 0..2)
        assertTrue(TransferSlots.slotFor(id, 1) == 0)
    }

    @Test fun invalidConcurrencyIsRejected() {
        assertTrue(runCatching { TransferSlots.slotFor("job", 0) }.isFailure)
        assertTrue(runCatching { TransferSlots.slotFor("job", 4) }.isFailure)
    }
}
