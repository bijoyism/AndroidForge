package com.bijoyism.filenavigator.worker

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.bijoyism.filenavigator.FileNavigatorApp
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit
import java.util.Calendar

/**
 * Runs rule-based organization while the app UI is closed.
 *
 * Android schedules periodic work opportunistically (not at an exact minute).
 * The user must first grant access to source/destination folders and enable a rule.
 */
class ReconcileWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val container = (applicationContext as FileNavigatorApp).container
        return try {
            val settings = container.data.settings.first()
            if (!settings.autoOrganize) return Result.success()
            val featurePrefs = container.features.prefs.first()
            if (featurePrefs.timeWindowEnabled) {
                val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                val start = featurePrefs.timeWindowStartHour
                val end = featurePrefs.timeWindowEndHour
                val inWindow = if (start <= end) hour in start..end else hour >= start || hour <= end
                if (!inWindow) return Result.success()
            }
            val enabledRules = container.data.rules.first().filter { it.enabled }
            if (enabledRules.isEmpty()) {
                Result.success()
            } else {
                // Preview and execute in the background: no confirmation dialog is needed
                // after the user has explicitly configured and enabled their rules.
                val plan = container.automation.preview(enabledRules).moves
                if (plan.isNotEmpty()) {
                    val results = container.automation.run(plan)
                    if (settings.notifications && !settings.quiet) {
                        com.bijoyism.filenavigator.notifications.Notifier(applicationContext).notifyOrganizationSummary(
                            moved = results.count { it.status == com.bijoyism.filenavigator.automation.ItemStatus.DONE },
                            skipped = results.count { it.status == com.bijoyism.filenavigator.automation.ItemStatus.SKIPPED },
                            failed = results.count { it.status == com.bijoyism.filenavigator.automation.ItemStatus.FAILED }
                        )
                    }
                }
                Result.success()
            }
        } catch (e: SecurityException) {
            Log.w("FileNavigator", "Background organization lacks folder access; reopen Settings and re-authorize the folder.", e)
            Result.retry()
        } catch (e: Exception) {
            Log.w("FileNavigator", "Background organization failed; WorkManager will retry.", e)
            Result.retry()
        }
    }
}

object ReconcileScheduler {
    private const val WORK_NAME = "automatic_file_organization"

    fun schedule(context: Context, intervalMinutes: Int = 60, batteryNotLow: Boolean = false, networkPolicy: String = "any") {
        val constraints = Constraints.Builder().apply {
            if (batteryNotLow) setRequiresBatteryNotLow(true)
            when (networkPolicy) {
                "unmetered" -> setRequiredNetworkType(NetworkType.UNMETERED)
                "connected" -> setRequiredNetworkType(NetworkType.CONNECTED)
            }
        }.build()
        val request = PeriodicWorkRequestBuilder<ReconcileWorker>(
            intervalMinutes.coerceIn(15, 1440).toLong(), TimeUnit.MINUTES
        ).setConstraints(constraints).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }

    fun setEnabled(context: Context, enabled: Boolean, intervalMinutes: Int = 60, batteryNotLow: Boolean = false, networkPolicy: String = "any") {
        if (enabled) schedule(context, intervalMinutes, batteryNotLow, networkPolicy)
        else WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    }
}
