package com.bijoyism.filenavigator.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.bijoyism.filenavigator.MainActivity
import com.bijoyism.filenavigator.R
import com.bijoyism.filenavigator.navigation.Destination

/** A small offline widget with shortcuts to the browser and storage tools. */
class FileNavigatorWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> manager.updateAppWidget(id, buildViews(context)) }
    }

    private fun buildViews(context: Context): RemoteViews = RemoteViews(context.packageName, R.layout.widget_file_navigator).apply {
        setOnClickPendingIntent(R.id.widget_open_files, shortcut(context, Destination.Files, 101))
        setOnClickPendingIntent(R.id.widget_open_storage, shortcut(context, Destination.Storage, 102))
    }

    private fun shortcut(context: Context, destination: Destination, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
            .putExtra(MainActivity.EXTRA_OPEN, destination.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
