package com.bijoyism.filenavigator.navigation

enum class Destination(val label: String) {
    Home("Home"),
    Files("Files"),
    Automation("Automation"),
    Activity("Activity"),
    Storage("Tools"),
    Settings("Settings")
}
