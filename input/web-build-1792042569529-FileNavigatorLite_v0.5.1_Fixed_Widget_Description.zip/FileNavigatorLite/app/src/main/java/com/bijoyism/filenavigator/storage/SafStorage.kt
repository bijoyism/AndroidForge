package com.bijoyism.filenavigator.storage

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import com.bijoyism.filenavigator.domain.FileEntry
import com.bijoyism.filenavigator.domain.StorageException
import com.bijoyism.filenavigator.domain.TransferCancelledException
import com.bijoyism.filenavigator.domain.StorageGateway
import kotlinx.coroutines.ensureActive

/**
 * Storage Access Framework implementation (works on API 29). Every folder is identified by a URI string that is
 * either a tree URI chosen by the user or a document URI inside such a tree.
 */
class SafStorage(context: Context) : StorageGateway {
    private val resolver = context.contentResolver

    fun sha256(fileUri: String): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        resolver.openInputStream(Uri.parse(fileUri))?.use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        } ?: throw StorageException("Could not read file for duplicate check")
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun openInputStream(fileUri: String) = resolver.openInputStream(Uri.parse(fileUri))
    fun openOutputStream(fileUri: String) = resolver.openOutputStream(Uri.parse(fileUri), "w")

    fun createFileDocument(parentUri: String, mimeType: String, name: String): String = guard("Could not create file") {
        DocumentsContract.createDocument(resolver, docUri(parentUri), mimeType, name)?.toString()
            ?: throw StorageException("The storage provider refused to create $name")
    }

    /** Difference-hash for image similarity suggestions. This is approximate, not an identity check. */
    fun perceptualHash(fileUri: String): Long {
        val uri = Uri.parse(fileUri)
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
            ?: throw StorageException("Could not read image")
        var sample = 1
        val longest = maxOf(bounds.outWidth, bounds.outHeight).coerceAtLeast(1)
        while (longest / sample > 256) sample *= 2
        val options = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = android.graphics.Bitmap.Config.RGB_565 }
        val decoded = resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, options) }
            ?: throw StorageException("Could not decode image")
        val scaled = android.graphics.Bitmap.createScaledBitmap(decoded, 9, 8, true)
        if (scaled !== decoded) decoded.recycle()
        var hash = 0L
        for (y in 0 until 8) for (x in 0 until 8) {
            val left = scaled.getPixel(x, y)
            val right = scaled.getPixel(x + 1, y)
            val leftGray = ((android.graphics.Color.red(left) * 299) + (android.graphics.Color.green(left) * 587) + (android.graphics.Color.blue(left) * 114)) / 1000
            val rightGray = ((android.graphics.Color.red(right) * 299) + (android.graphics.Color.green(right) * 587) + (android.graphics.Color.blue(right) * 114)) / 1000
            hash = (hash shl 1) or if (leftGray > rightGray) 1L else 0L
        }
        scaled.recycle()
        return hash
    }

    data class ZipItem(val name: String, val size: Long, val compressedSize: Long, val isDirectory: Boolean)

    fun listZipEntries(zipUri: String, limit: Int = 5000): List<ZipItem> = guard("Could not inspect ZIP archive") {
        val input = resolver.openInputStream(Uri.parse(zipUri)) ?: throw StorageException("Could not read ZIP archive")
        val entries = mutableListOf<ZipItem>()
        java.util.zip.ZipInputStream(input.buffered()).use { zip ->
            while (entries.size < limit) {
                val item = zip.nextEntry ?: break
                validateArchivePath(item.name)
                entries.add(ZipItem(item.name, item.size, item.compressedSize, item.isDirectory))
                zip.closeEntry()
            }
        }
        entries
    }

    fun extractZipSelected(zipUri: String, outputFolderUri: String, selectedNames: Set<String>, maxEntries: Int = 5000): Int =
        guard("Could not extract selected ZIP entries") {
            var extracted = 0
            val root = docUri(outputFolderUri)
            val input = resolver.openInputStream(Uri.parse(zipUri)) ?: throw StorageException("Could not read ZIP archive")
            java.util.zip.ZipInputStream(input.buffered()).use { zip ->
                var seen = 0
                while (true) {
                    val item = zip.nextEntry ?: break
                    if (++seen > maxEntries) throw StorageException("Archive contains too many entries; limit is $maxEntries")
                    validateArchivePath(item.name)
                    val safeName = item.name.replace('\\', '/')
                    if (selectedNames.isNotEmpty() && safeName !in selectedNames) { zip.closeEntry(); continue }
                    val segments = safeName.split('/').filter { it.isNotBlank() }
                    if (segments.isEmpty()) { zip.closeEntry(); continue }
                    var parent = root
                    segments.dropLast(1).forEach { segment ->
                        val found = list(parent.toString()).firstOrNull { it.isDirectory && it.name == segment }
                        parent = if (found != null) docUri(found.uri) else {
                            DocumentsContract.createDocument(resolver, parent, Document.MIME_TYPE_DIR, segment)
                                ?: throw StorageException("Could not create folder $segment")
                        }
                    }
                    if (item.isDirectory) {
                        if (list(parent.toString()).none { it.isDirectory && it.name == segments.last() }) {
                            DocumentsContract.createDocument(resolver, parent, Document.MIME_TYPE_DIR, segments.last())
                        }
                    } else {
                        val targetName = segments.last()
                        if (list(parent.toString()).any { it.name == targetName }) throw StorageException("Extraction stopped: $targetName already exists")
                        val target = DocumentsContract.createDocument(resolver, parent, "application/octet-stream", targetName)
                            ?: throw StorageException("Could not create $targetName")
                        try {
                            resolver.openOutputStream(target, "w")?.use { out ->
                                val buffer = ByteArray(64 * 1024)
                                while (true) {
                                    val count = zip.read(buffer)
                                    if (count < 0) break
                                    out.write(buffer, 0, count)
                                }
                            } ?: throw StorageException("Could not write $targetName")
                            extracted++
                        } catch (e: Exception) {
                            runCatching { DocumentsContract.deleteDocument(resolver, target) }
                            throw e
                        }
                    }
                    zip.closeEntry()
                }
            }
            extracted
        }

    private fun validateArchivePath(name: String) {
        val normalized = name.replace('\\', '/')
        if (normalized.startsWith('/') || normalized.startsWith("../") || normalized.split('/').any { it == ".." } || normalized.contains('\u0000')) {
            throw StorageException("Unsafe path in ZIP archive")
        }
    }

    fun createZip(folderUri: String, outputFolderUri: String, archiveName: String, compressionLevel: Int = 6): String =
        guard("Could not create ZIP archive") {
            val parent = docUri(outputFolderUri)
            val archive = DocumentsContract.createDocument(
                resolver,
                parent,
                "application/zip",
                archiveName.removeSuffix(".zip") + ".zip"
            ) ?: throw StorageException("The destination provider refused to create the ZIP file")
            try {
                val stream = resolver.openOutputStream(archive, "w")
                    ?: throw StorageException("Could not open ZIP output stream")
                java.util.zip.ZipOutputStream(stream.buffered()).use { zip ->
                    zip.setLevel(compressionLevel.coerceIn(0, 9))
                    appendFolderToZip(folderUri, "", zip, 0)
                }
                archive.toString()
            } catch (error: Exception) {
                runCatching { DocumentsContract.deleteDocument(resolver, archive) }
                throw error
            }
        }

    private fun appendFolderToZip(folderUri: String, prefix: String, zip: java.util.zip.ZipOutputStream, depth: Int) {
        if (depth > 20) throw StorageException("Folder nesting is too deep to archive safely")
        list(folderUri).forEach { entry ->
            val path = if (prefix.isEmpty()) entry.name else "$prefix/${entry.name}"
            if (entry.isDirectory) {
                zip.putNextEntry(java.util.zip.ZipEntry("$path/"))
                zip.closeEntry()
                appendFolderToZip(entry.uri, path, zip, depth + 1)
            } else {
                zip.putNextEntry(java.util.zip.ZipEntry(path))
                resolver.openInputStream(Uri.parse(entry.uri))?.use { it.copyTo(zip) }
                    ?: throw StorageException("Could not read ${entry.name}")
                zip.closeEntry()
            }
        }
    }

    fun extractZip(zipUri: String, outputFolderUri: String): Int = guard("Could not extract ZIP archive") {
        var extracted = 0
        val root = docUri(outputFolderUri)
        val input = resolver.openInputStream(Uri.parse(zipUri)) ?: throw StorageException("Could not read ZIP archive")
        java.util.zip.ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val item = zip.nextEntry ?: break
                val safePath = item.name.replace('\\', '/').split('/')
                if (item.name.startsWith("/") || safePath.any { it == ".." } || item.name.contains('\u0000')) {
                    throw StorageException("Unsafe path in ZIP archive")
                }
                var parent = root
                val parts = safePath.filter { it.isNotBlank() }
                if (parts.isEmpty()) continue
                parts.dropLast(1).forEach { segment ->
                    val found = list(parent.toString()).firstOrNull { it.isDirectory && it.name == segment }
                    parent = if (found != null) docUri(found.uri) else {
                        DocumentsContract.createDocument(resolver, parent, Document.MIME_TYPE_DIR, segment)
                            ?: throw StorageException("Could not create folder $segment")
                    }
                }
                if (item.isDirectory) {
                    if (list(parent.toString()).none { it.isDirectory && it.name == parts.last() }) {
                        DocumentsContract.createDocument(resolver, parent, Document.MIME_TYPE_DIR, parts.last())
                    }
                } else {
                    val targetName = parts.last()
                    if (list(parent.toString()).any { it.name == targetName }) {
                        throw StorageException("Extraction stopped: $targetName already exists")
                    }
                    val target = DocumentsContract.createDocument(resolver, parent, "application/octet-stream", targetName)
                        ?: throw StorageException("Could not create $targetName")
                    resolver.openOutputStream(target, "w")?.use { zip.copyTo(it) }
                        ?: throw StorageException("Could not write $targetName")
                    extracted++
                }
                zip.closeEntry()
            }
        }
        extracted
    }

    fun findGrantedRoot(folderUri: String): String? = grantedRoots().firstOrNull { root -> runCatching { sameTree(Uri.parse(root), Uri.parse(folderUri)) }.getOrDefault(false) }

    fun grantedRoots(): List<String> = resolver.persistedUriPermissions
        .filter { it.isReadPermission && it.isWritePermission && DocumentsContract.isTreeUri(it.uri) }
        .map { it.uri.toString() }
        .sorted()

    fun grant(uri: Uri) {
        runCatching { resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
    }

    fun revoke(uri: String) {
        runCatching { resolver.releasePersistableUriPermission(Uri.parse(uri), Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
    }

    override fun hasAccess(folderUri: String): Boolean {
        val uri = Uri.parse(folderUri)
        val granted = resolver.persistedUriPermissions.any { it.isReadPermission && it.isWritePermission && sameTree(it.uri, uri) }
        return granted && documentExists(docUri(folderUri))
    }

    override fun sameFolder(a: String, b: String): Boolean = try {
        val first = docUri(a)
        val second = docUri(b)
        first.authority == second.authority && DocumentsContract.getDocumentId(first) == DocumentsContract.getDocumentId(second)
    } catch (e: IllegalArgumentException) {
        false
    }

    /** Reads a single authorized document's metadata without walking its parent directory. */
    fun entry(fileUri: String): FileEntry? = guard("Could not read file details") {
        val uri = Uri.parse(fileUri)
        val cursor = resolver.query(uri, PROJECTION, null, null, null) ?: return@guard null
        cursor.use {
            if (!it.moveToFirst()) return@use null
            val mime = it.getString(2)
            FileEntry(
                uri = fileUri,
                name = it.getString(1) ?: uri.lastPathSegment?.substringAfterLast('/') ?: "File",
                size = if (it.isNull(3)) -1L else it.getLong(3),
                mimeType = mime,
                lastModified = if (it.isNull(4)) 0L else it.getLong(4),
                isDirectory = mime == Document.MIME_TYPE_DIR
            )
        }
    }

    override fun list(folderUri: String): List<FileEntry> = guard("Cannot read folder") {
        val folder = docUri(folderUri)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(folder, DocumentsContract.getDocumentId(folder))
        val out = ArrayList<FileEntry>()
        val cursor = resolver.query(children, PROJECTION, null, null, null) ?: throw StorageException("The folder could not be read")
        cursor.use { while (it.moveToNext()) out.add(it.toEntry(folder)) }
        out
    }

    override fun copy(fileUri: String, destFolderUri: String, name: String): String = guard("Copy failed") {
        copyDocument(docUri(fileUri), docUri(destFolderUri), name).toString()
    }

    /** File copy with byte-level progress. Used by the persistent transfer worker; directory trees use copyDocument. */
    suspend fun copyWithProgress(fileUri: String, destFolderUri: String, name: String, onProgress: suspend (Long, Long) -> Unit, isCancelled: () -> Boolean = { false }): String {
        val source = docUri(fileUri)
        val destination = docUri(destFolderUri)
        val mime = queryString(source, Document.COLUMN_MIME_TYPE) ?: "application/octet-stream"
        if (mime == Document.MIME_TYPE_DIR) throw StorageException("The transfer queue currently accepts individual files, not folders.")
        val expected = queryLong(source, Document.COLUMN_SIZE).coerceAtLeast(0L)
        val target = DocumentsContract.createDocument(resolver, destination, mime, name)
            ?: throw StorageException("Could not create $name")
        try {
            val input = resolver.openInputStream(source) ?: throw StorageException("Cannot read $name")
            val output = resolver.openOutputStream(target, "w") ?: throw StorageException("Cannot write $name")
            var copied = 0L
            val buffer = ByteArray(64 * 1024)
            input.use { from -> output.use { to ->
                while (true) {
                    kotlinx.coroutines.currentCoroutineContext().ensureActive()
                    if (isCancelled()) throw TransferCancelledException()
                    val count = from.read(buffer)
                    if (count < 0) break
                    to.write(buffer, 0, count)
                    copied += count
                    onProgress(copied, expected)
                }
                to.flush()
            } }
            if (expected > 0 && copied != expected) throw StorageException("Copy size check failed for $name (expected $expected bytes, wrote $copied)")
            onProgress(copied, expected.coerceAtLeast(copied))
            return target.toString()
        } catch (e: Exception) {
            runCatching { DocumentsContract.deleteDocument(resolver, target) }
            throw if (e is StorageException || e is kotlinx.coroutines.CancellationException || e is TransferCancelledException) e else StorageException("Copy failed: ${e.message}", e)
        }
    }

    suspend fun moveWithProgress(fileUri: String, sourceFolderUri: String, destFolderUri: String, name: String, onProgress: suspend (Long, Long) -> Unit, isCancelled: () -> Boolean = { false }): String {
        val copied = copyWithProgress(fileUri, destFolderUri, name, onProgress, isCancelled)
        try {
            val sourceHash = sha256(fileUri)
            val targetHash = sha256(copied)
            if (sourceHash != targetHash) throw StorageException("Integrity verification failed before removing the original")
            if (isCancelled()) throw TransferCancelledException()
            delete(fileUri)
            return copied
        } catch (e: Exception) {
            runCatching { delete(copied) }
            throw e
        }
    }

    override fun move(fileUri: String, srcFolderUri: String, destFolderUri: String, name: String): String = guard("Move failed") {
        val source = docUri(fileUri)
        val sourceParent = docUri(srcFolderUri)
        val destParent = docUri(destFolderUri)
        // A provider-side move is atomic and fast, but only usable when the name is unchanged.
        val direct = if (queryString(source, Document.COLUMN_DISPLAY_NAME) == name) {
            runCatching { DocumentsContract.moveDocument(resolver, source, sourceParent, destParent) }.getOrNull()
        } else {
            null
        }
        if (direct != null) {
            direct.toString()
        } else {
            val copied = copyDocument(source, destParent, name)
            val removed = runCatching { DocumentsContract.deleteDocument(resolver, source) }.getOrDefault(false)
            if (!removed) {
                runCatching { DocumentsContract.deleteDocument(resolver, copied) }
                throw StorageException("Could not remove the original after copying, so nothing was changed")
            }
            copied.toString()
        }
    }

    override fun delete(uri: String) = guard("Delete failed") {
        if (!DocumentsContract.deleteDocument(resolver, docUri(uri))) throw StorageException("The provider refused to delete this item")
    }

    override fun rename(uri: String, newName: String): String = guard("Rename failed") {
        DocumentsContract.renameDocument(resolver, docUri(uri), newName)?.toString() ?: throw StorageException("The provider refused to rename this item")
    }

    override fun createFolder(parentUri: String, name: String): String = guard("Could not create folder") {
        DocumentsContract.createDocument(resolver, docUri(parentUri), Document.MIME_TYPE_DIR, name)?.toString() ?: throw StorageException("The provider refused to create the folder")
    }

    override fun label(folderUri: String): String {
        val id = runCatching { DocumentsContract.getDocumentId(docUri(folderUri)) }.getOrDefault(folderUri)
        val path = id.substringAfter(':', id)
        return if (path.isEmpty()) "Storage root" else path
    }

    private fun copyDocument(source: Uri, destParent: Uri, name: String): Uri {
        val mime = queryString(source, Document.COLUMN_MIME_TYPE) ?: "application/octet-stream"
        if (mime == Document.MIME_TYPE_DIR) {
            val newDir = DocumentsContract.createDocument(resolver, destParent, Document.MIME_TYPE_DIR, name) ?: throw StorageException("Could not create folder $name")
            try {
                list(source.toString()).forEach { copyDocument(Uri.parse(it.uri), newDir, it.name) }
            } catch (e: Exception) {
                runCatching { DocumentsContract.deleteDocument(resolver, newDir) }
                throw e
            }
            return newDir
        }
        val expected = queryLong(source, Document.COLUMN_SIZE)
        val target = DocumentsContract.createDocument(resolver, destParent, mime, name) ?: throw StorageException("Could not create $name")
        try {
            val input = resolver.openInputStream(source) ?: throw StorageException("Cannot read $name")
            val output = resolver.openOutputStream(target, "w") ?: throw StorageException("Cannot write $name")
            val copied = input.use { i -> output.use { o -> i.copyTo(o) } }
            val written = queryLong(target, Document.COLUMN_SIZE)
            if (expected >= 0 && (copied != expected || (written >= 0 && written != expected))) {
                throw StorageException("Integrity check failed for $name")
            }
            return target
        } catch (e: Exception) {
            runCatching { DocumentsContract.deleteDocument(resolver, target) }
            throw e
        }
    }

    private inline fun <T> guard(message: String, block: () -> T): T = try {
        block()
    } catch (e: StorageException) {
        throw e
    } catch (e: SecurityException) {
        throw StorageException("Access to this folder was revoked. Grant it again.", e)
    } catch (e: Exception) {
        throw StorageException("$message: ${e.message}", e)
    }

    private fun docUri(value: String): Uri {
        val uri = Uri.parse(value)
        return if (uri.pathSegments.contains("document")) uri else DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri))
    }

    private fun sameTree(a: Uri, b: Uri): Boolean = try {
        a.authority == b.authority && DocumentsContract.getTreeDocumentId(a) == DocumentsContract.getTreeDocumentId(b)
    } catch (e: IllegalArgumentException) {
        false
    }

    private fun documentExists(uri: Uri): Boolean = try {
        resolver.query(uri, arrayOf(Document.COLUMN_DOCUMENT_ID), null, null, null)?.use { it.moveToFirst() } ?: false
    } catch (e: Exception) {
        false
    }

    private fun queryString(uri: Uri, column: String): String? = try {
        resolver.query(uri, arrayOf(column), null, null, null)?.use { c -> if (c.moveToFirst() && !c.isNull(0)) c.getString(0) else null }
    } catch (e: Exception) {
        null
    }

    private fun queryLong(uri: Uri, column: String): Long = queryString(uri, column)?.toLongOrNull() ?: -1L

    private fun Cursor.toEntry(parent: Uri): FileEntry {
        val mime = getString(2)
        return FileEntry(
            uri = DocumentsContract.buildDocumentUriUsingTree(parent, getString(0)).toString(),
            name = getString(1) ?: "?",
            size = if (isNull(3)) -1L else getLong(3),
            mimeType = mime,
            lastModified = if (isNull(4)) 0L else getLong(4),
            isDirectory = mime == Document.MIME_TYPE_DIR
        )
    }

    private companion object {
        val PROJECTION = arrayOf(
            Document.COLUMN_DOCUMENT_ID,
            Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_MIME_TYPE,
            Document.COLUMN_SIZE,
            Document.COLUMN_LAST_MODIFIED
        )
    }
}
