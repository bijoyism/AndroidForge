package com.bijoyism.filenavigator.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bijoyism.filenavigator.AppContainer
import com.bijoyism.filenavigator.automation.PlannedMove
import com.bijoyism.filenavigator.automation.summarize
import com.bijoyism.filenavigator.domain.ConflictPolicy
import com.bijoyism.filenavigator.domain.FileEntry
import com.bijoyism.filenavigator.domain.FileQuery
import com.bijoyism.filenavigator.data.SmartFolder
import com.bijoyism.filenavigator.domain.HistoryEntry
import com.bijoyism.filenavigator.domain.Rule
import com.bijoyism.filenavigator.domain.SortKey
import com.bijoyism.filenavigator.data.TransferJob
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

const val PAGE_SIZE = 200

data class Crumb(val name: String, val uri: String)

data class FilesState(
    val roots: List<String> = emptyList(),
    val stack: List<Crumb> = emptyList(),
    val entries: List<FileEntry> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
    val query: String = "",
    val sort: SortKey = SortKey.NAME,
    val grid: Boolean = false,
    val selecting: Boolean = false,
    val selected: Set<String> = emptySet(),
    val shown: Int = PAGE_SIZE,
    val message: String? = null
)

@OptIn(FlowPreview::class)
class FilesViewModel(private val c: AppContainer) : ViewModel() {
    private val _state = MutableStateFlow(FilesState(roots = c.storage.grantedRoots()))
    val state: StateFlow<FilesState> = _state

    private val queryFlow = MutableStateFlow("")
    private var virtualQuery: FileQuery? = null
    private var virtualUris: List<String>? = null

    init {
        viewModelScope.launch {
            queryFlow.debounce(300).collect { q -> _state.update { it.copy(query = q, shown = PAGE_SIZE) } }
        }
    }

    fun labelOf(uri: String): String = c.storage.label(uri)

    fun setQuery(text: String) {
        queryFlow.value = text
    }

    fun setSort(key: SortKey) = _state.update { it.copy(sort = key) }

    fun toggleGrid() = _state.update { it.copy(grid = !it.grid) }
    fun setShowHidden(show: Boolean) { viewModelScope.launch { c.features.updatePrefs { it.copy(showHiddenInBrowser = show) } } }
    fun setCompactMode(compact: Boolean) { viewModelScope.launch { c.features.updatePrefs { it.copy(compactMode = compact) } } }

    fun loadMore() = _state.update { it.copy(shown = it.shown + PAGE_SIZE) }

    fun dismissMessage() = _state.update { it.copy(message = null) }

    fun refreshRoots() = _state.update { it.copy(roots = c.storage.grantedRoots()) }

    fun grant(uri: Uri) {
        c.storage.grant(uri)
        refreshRoots()
    }

    fun openRoot(uri: String) {
        virtualQuery = null
        virtualUris = null
        _state.update { it.copy(stack = listOf(Crumb(c.storage.label(uri), uri))) }
        load()
    }

    fun entryForUri(uri: String): FileEntry? = runCatching { c.storage.entry(uri) }.getOrNull()

    fun openSmartFolder(folder: SmartFolder) {
        virtualUris = null
        virtualQuery = FileQuery(text = folder.query, extension = folder.extension, mimePrefix = folder.mimePrefix, includeHidden = false)
        _state.update { it.copy(stack = listOf(Crumb(folder.name, "virtual:smart:${folder.id}")), query = "", selected = emptySet(), selecting = false) }
        load()
    }

    fun openCollection(name: String, uris: List<String>) {
        virtualQuery = null
        virtualUris = uris.distinct().take(1000)
        _state.update { it.copy(stack = listOf(Crumb(name, "virtual:collection:$name")), query = "", selected = emptySet(), selecting = false) }
        load()
    }

    fun enter(entry: FileEntry) {
        _state.update { it.copy(stack = it.stack + Crumb(entry.name, entry.uri)) }
        load()
    }

    fun navigateTo(index: Int) {
        _state.update { it.copy(stack = it.stack.take(index + 1)) }
        load()
    }

    fun up() {
        val size = _state.value.stack.size
        if (size > 1) {
            navigateTo(size - 2)
        } else {
            _state.update { it.copy(stack = emptyList(), entries = emptyList(), error = null, selected = emptySet(), selecting = false) }
            refreshRoots()
        }
    }

    fun toggleSelecting() = _state.update { it.copy(selecting = !it.selecting, selected = emptySet()) }

    fun toggle(uri: String) = _state.update { it.copy(selected = if (uri in it.selected) it.selected - uri else it.selected + uri) }

    fun selectAll(uris: List<String>) = _state.update { it.copy(selected = uris.toSet()) }

    fun selectedEntries(): List<FileEntry> = _state.value.entries.filter { it.uri in _state.value.selected }

    private fun currentFolder(): String? = _state.value.stack.lastOrNull()?.uri

    fun reload() = load()

    private fun load() {
        val folder = currentFolder() ?: return
        _state.update { it.copy(loading = true, error = null, selected = emptySet(), selecting = false, shown = PAGE_SIZE) }
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching {
                when {
                    folder.startsWith("virtual:smart:") -> {
                        val q = virtualQuery ?: FileQuery()
                        val output = mutableListOf<FileEntry>()
                        val pending = ArrayDeque<String>()
                        c.storage.grantedRoots().forEach(pending::addLast)
                        val visited = HashSet<String>()
                        while (pending.isNotEmpty() && visited.size < 10_000 && output.size < 2_000) {
                            val current = pending.removeFirst()
                            if (!visited.add(current)) continue
                            c.storage.list(current).forEach { entry ->
                                if (entry.isDirectory) pending.addLast(entry.uri)
                                if (q.matches(entry)) output.add(entry)
                            }
                        }
                        output
                    }
                    folder.startsWith("virtual:collection:") -> virtualUris.orEmpty().mapNotNull { c.storage.entry(it) }
                    else -> c.storage.list(folder)
                }
            } }
            _state.update { s -> result.fold({ s.copy(entries = it, loading = false) }, { s.copy(entries = emptyList(), loading = false, error = it.message ?: "Cannot read this folder") }) }
        }
    }

    private fun launchOp(block: suspend () -> String) {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val message = withContext(Dispatchers.IO) { runCatching { block() }.getOrElse { "Failed: ${it.message}" } }
            _state.update { it.copy(message = message) }
            load()
        }
    }

    private suspend fun tracked(type: String, name: String, from: String, to: String, block: () -> Unit) {
        try {
            block()
            c.data.add(HistoryEntry(type = type, name = name, from = from, to = to, success = true))
        } catch (e: Exception) {
            c.data.add(HistoryEntry(type = type, name = name, from = from, to = to, success = false, error = e.message))
            throw e
        }
    }

    fun deleteSelected() {
        val items = selectedEntries()
        val folder = currentFolder() ?: return
        launchOp {
            val root = c.storage.findGrantedRoot(folder) ?: folder
            var trash = c.storage.list(root).firstOrNull { it.isDirectory && it.name == ".FileNavigatorTrash" }?.uri
            if (trash == null) trash = c.storage.createFolder(root, ".FileNavigatorTrash")
            var moved = 0
            val errors = mutableListOf<String>()
            for (entry in items) {
                try {
                    val names = c.storage.list(trash).map { it.name }.toSet()
                    val targetName = com.bijoyism.filenavigator.domain.Names.unique(entry.name) { it in names }
                    val result = c.storage.move(entry.uri, folder, trash, targetName)
                    c.data.add(HistoryEntry(type = "TRASH", name = entry.name, from = c.storage.label(folder), to = "Recycle bin", success = true, srcFolderUri = folder, destFolderUri = trash, resultUri = result))
                    moved++
                } catch (ex: Exception) {
                    errors.add("${entry.name}: ${ex.message}")
                    c.data.add(HistoryEntry(type = "TRASH", name = entry.name, from = c.storage.label(folder), to = "Recycle bin", success = false, error = ex.message))
                }
            }
            buildString {
                append("Moved $moved item(s) to the recycle bin")
                if (errors.isNotEmpty()) append(", ${errors.size} failed")
                errors.forEach { append("\n• $it") }
            }
        }
    }

    fun rename(entry: FileEntry, newName: String) {
        val name = newName.trim()
        val folder = currentFolder() ?: return
        if (name.isEmpty() || name.contains('/')) {
            _state.update { it.copy(message = "Invalid name") }
            return
        }
        if (_state.value.entries.any { it.name == name }) {
            _state.update { it.copy(message = "\"$name\" already exists here") }
            return
        }
        launchOp {
            tracked("RENAME", entry.name, entry.name, name) { c.storage.rename(entry.uri, name) }
            "Renamed to $name (in ${c.storage.label(folder)})"
        }
    }

    fun createFolder(newName: String) {
        val name = newName.trim()
        val folder = currentFolder() ?: return
        if (name.isEmpty() || name.contains('/')) {
            _state.update { it.copy(message = "Invalid name") }
            return
        }
        if (_state.value.entries.any { it.name == name }) {
            _state.update { it.copy(message = "\"$name\" already exists here") }
            return
        }
        launchOp {
            tracked("MKDIR", name, c.storage.label(folder), "") { c.storage.createFolder(folder, name) }
            "Created folder $name"
        }
    }

    fun grantAndTransfer(destination: Uri, move: Boolean) {
        c.storage.grant(destination)
        refreshRoots()
        val items = selectedEntries().filterNot { it.isDirectory }
        val folder = currentFolder() ?: return
        viewModelScope.launch {
            val queued = withContext(Dispatchers.IO) {
                items.map { entry ->
                    c.queue.enqueue(TransferJob(
                        kind = if (move) "MOVE" else "COPY",
                        sourceUri = entry.uri,
                        sourceFolderUri = folder,
                        destinationFolderUri = destination.toString(),
                        targetName = entry.name,
                        verify = !move
                    ))
                }
            }
            _state.update { it.copy(message = "Queued ${queued.size} transfer(s). Open Tools → Transfer queue to monitor progress.", selected = emptySet(), selecting = false) }
            load()
        }
    }

    fun toggleFavorite(uri: String) { viewModelScope.launch { c.features.toggleFavorite(uri) } }
    fun toggleBookmark(uri: String) { viewModelScope.launch { c.features.toggleBookmark(uri) } }
    fun recordRecent(uri: String) { viewModelScope.launch { c.features.recordRecent(uri) } }
    fun setTags(uris: List<String>, tagsText: String) {
        val tags = tagsText.split(',', ';', '\n').map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(20)
        viewModelScope.launch { c.features.updatePrefs { prefs ->
            val updated = prefs.tags.toMutableMap()
            uris.forEach { uri -> if (tags.isEmpty()) updated.remove(uri) else updated[uri] = tags }
            prefs.copy(tags = updated)
        } }
    }
    fun addToCollection(collectionName: String, uris: List<String>) {
        val name = collectionName.trim().take(80)
        if (name.isBlank()) return
        viewModelScope.launch { c.features.updatePrefs { prefs ->
            val values = prefs.collections.toMutableMap()
            values[name] = (values[name].orEmpty() + uris).distinct().take(1000)
            prefs.copy(collections = values)
        } }
    }
    fun checksum(entry: FileEntry) {
        launchOp { "SHA-256 · ${entry.name}\n${c.storage.sha256(entry.uri)}" }
    }
    fun compareEntries(first: FileEntry, second: FileEntry) {
        launchOp {
            if (first.size >= 0 && second.size >= 0 && first.size != second.size) "Files differ: sizes are ${first.size} and ${second.size} bytes."
            else {
                val a = c.storage.sha256(first.uri); val b = c.storage.sha256(second.uri)
                if (a == b) "Files are byte-identical (SHA-256 matches)." else "Files differ (SHA-256 hashes do not match).\n${first.name}: $a\n${second.name}: $b"
            }
        }
    }
    val featurePrefs = c.features.prefs.stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), com.bijoyism.filenavigator.data.FeaturePrefs())

    fun batchRename(entries: List<FileEntry>, mapping: List<Pair<String, String>>) {
        val folder = currentFolder() ?: return
        if (entries.size != mapping.size) { _state.update { it.copy(message = "Rename plan does not match the selection.") }; return }
        val targets = mapping.map { it.second }
        if (targets.distinct().size != targets.size) { _state.update { it.copy(message = "The rename would create duplicate filenames.") }; return }
        val occupied = _state.value.entries.map { it.name }.toSet() - entries.map { it.name }.toSet()
        if (targets.any { it in occupied } || targets.any { it.isBlank() || it.contains('/') || it.contains('\\') }) {
            _state.update { it.copy(message = "The rename plan contains an invalid or already-used filename.") }; return
        }
        launchOp {
            val temp = mutableListOf<Pair<FileEntry, String>>()
            try {
                entries.forEachIndexed { index, entry ->
                    val temporaryName = ".fnl_rename_${System.currentTimeMillis()}_$index.tmp"
                    val temporaryUri = c.storage.rename(entry.uri, temporaryName)
                    temp.add(entry.copy(uri = temporaryUri, name = temporaryName) to mapping[index].second)
                }
                temp.forEach { (entry, target) -> c.storage.rename(entry.uri, target) }
                c.data.add(HistoryEntry(type = "BATCH_RENAME", name = "${entries.size} files", from = c.storage.label(folder), to = c.storage.label(folder), success = true))
                "Renamed ${entries.size} file(s)."
            } catch (e: Exception) {
                c.data.add(HistoryEntry(type = "BATCH_RENAME", name = "${entries.size} files", from = c.storage.label(folder), to = c.storage.label(folder), success = false, error = e.message))
                "Batch rename stopped: ${e.message}. Some files may have the temporary prefix .fnl_rename_; check the folder before retrying."
            }
        }
    }

    fun applyRule(rule: Rule) {
        val items = selectedEntries().filter { !it.isDirectory }
        val folder = currentFolder() ?: return
        launchOp {
            val plan = items.map { PlannedMove(rule.id, rule.name, it, folder, rule.destUri, rule.conflict) }
            summarize(c.automation.run(plan))
        }
    }
}
