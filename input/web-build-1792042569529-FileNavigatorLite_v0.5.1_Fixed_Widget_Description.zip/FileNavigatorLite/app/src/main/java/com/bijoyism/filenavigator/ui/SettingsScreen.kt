package com.bijoyism.filenavigator.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Button
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.bijoyism.filenavigator.security.PinSecurity

private val scanIntervals = listOf(15, 30, 60, 180, 360, 720, 1440)

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsState()
    val notice by vm.notice.collectAsState()
    val restorePreview by vm.restorePreview.collectAsState()
    val grants by vm.grants.collectAsState()
    val featurePrefs by vm.featurePrefs.collectAsState()
    var pinDialog by rememberSaveable { mutableStateOf(false) }
    var confirmBackupExport by rememberSaveable { mutableStateOf(false) }
    var pin by rememberSaveable { mutableStateOf("") }
    var confirmPin by rememberSaveable { mutableStateOf("") }
    var pinMessage by rememberSaveable { mutableStateOf<String?>(null) }
    var startHour by rememberSaveable(featurePrefs.timeWindowStartHour) { mutableStateOf(featurePrefs.timeWindowStartHour.toString()) }
    var endHour by rememberSaveable(featurePrefs.timeWindowEndHour) { mutableStateOf(featurePrefs.timeWindowEndHour.toString()) }
    var smartFolderName by rememberSaveable { mutableStateOf("") }
    var smartFolderQuery by rememberSaveable { mutableStateOf("") }
    var smartFolderExtension by rememberSaveable { mutableStateOf("") }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> vm.setNotifications(granted) }
    val addFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) vm.grant(uri) }
    val excludeFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) vm.updateFeaturePrefs { it.copy(scanExclusions = it.scanExclusions + uri.toString()) }
    }
    val exportBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.writeBackup(uri)
    }
    val importBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.previewBackup(uri)
    }
    val exportDiagnostics = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.exportDiagnostics(uri)
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineLarge)
        Text("Make File Navigator feel like yours.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)

        SectionCard("Automatic organization", Modifier.animateContentSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Run in the background", style = MaterialTheme.typography.titleMedium)
                    Text("Automatically move files that match your enabled rules. No confirmation for each move.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = settings.autoOrganize, onCheckedChange = vm::setAutoOrganize)
            }
            AnimatedVisibility(visible = settings.autoOrganize) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Check for matching files", style = MaterialTheme.typography.titleSmall)
                    Text("Every ${intervalLabel(settings.intervalMinutes)}", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        listOf(15, 30, 60).forEach { mins ->
                            FilterChip(selected = settings.intervalMinutes == mins, onClick = { vm.setIntervalMinutes(mins) }, label = { Text(intervalLabel(mins)) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        listOf(180, 360, 720, 1440).forEach { mins ->
                            FilterChip(selected = settings.intervalMinutes == mins, onClick = { vm.setIntervalMinutes(mins) }, label = { Text(intervalLabel(mins)) })
                        }
                    }
                    Text("Android may delay background checks to save battery. The shortest supported interval is 15 minutes.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Only enabled rules run. Folder access must remain authorized, and files are never silently overwritten.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        SectionCard("Scheduling policies", Modifier.animateContentSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Only run during a time window", style = MaterialTheme.typography.titleSmall)
                    Text("The worker checks the local hour before it moves files. Android can still delay the job.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = featurePrefs.timeWindowEnabled, onCheckedChange = { enabled -> vm.updateFeaturePrefs { it.copy(timeWindowEnabled = enabled) } })
            }
            if (featurePrefs.timeWindowEnabled) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = startHour, onValueChange = { startHour = it.filter(Char::isDigit).take(2) }, label = { Text("Start hour 0–23") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = endHour, onValueChange = { endHour = it.filter(Char::isDigit).take(2) }, label = { Text("End hour 0–23") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Button(onClick = {
                    val start = startHour.toIntOrNull(); val end = endHour.toIntOrNull()
                    if (start == null || start !in 0..23 || end == null || end !in 0..23) pinMessage = "Hours must be between 0 and 23."
                    else { vm.updateFeaturePrefs { it.copy(timeWindowStartHour = start, timeWindowEndHour = end) }; pinMessage = "Schedule window saved." }
                }) { Text("Save time window") }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Require battery not low", style = MaterialTheme.typography.titleSmall); Text("Defer automatic organization when Android reports low battery.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                Switch(checked = featurePrefs.batteryNotLow, onCheckedChange = { on -> vm.updateFeaturePrefs { it.copy(batteryNotLow = on) } })
            }
            Text("Network requirement", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("any" to "Any", "connected" to "Connected", "unmetered" to "Unmetered Wi-Fi").forEach { (key, label) ->
                    FilterChip(selected = featurePrefs.networkPolicy == key, onClick = { vm.updateFeaturePrefs { it.copy(networkPolicy = key) } }, label = { Text(label) })
                }
            }
        }

        SectionCard("Transfer queue", Modifier.animateContentSize()) {
            Text("Choose how many transfers may run at once. Lower values use less memory and reduce storage contention.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 2, 3).forEach { count ->
                    FilterChip(
                        selected = featurePrefs.maxConcurrentTransfers == count,
                        onClick = { vm.updateFeaturePrefs { it.copy(maxConcurrentTransfers = count) } },
                        label = { Text(if (count == 1) "1 · Low memory" else "$count parallel") }
                    )
                }
            }
            Text("Transfers are queued persistently. Concurrency changes apply to newly scheduled work; existing lane items can finish under their previous lane assignment. A paused item waits in the queue; retry starts that file again rather than resuming at an exact byte offset.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SectionCard("Appearance", Modifier.animateContentSize()) {
            Text("Theme mode", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("system" to "System", "light" to "Light", "dark" to "Dark").forEach { (key, label) ->
                    FilterChip(selected = settings.themeMode == key, onClick = { vm.setThemeMode(key) }, label = { Text(label) })
                }
            }
            Text("Colour palette", style = MaterialTheme.typography.titleSmall)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("dynamic" to "Wallpaper colours", "blue" to "Ocean blue", "green" to "Sage green", "purple" to "Violet", "orange" to "Sunset", "amoled" to "AMOLED black").forEach { (key, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text(label, Modifier.weight(1f))
                        if (settings.colorTheme == key) Text("Selected", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                        TextButton(onClick = { vm.setColorTheme(key) }) { Text(if (settings.colorTheme == key) "Active" else "Apply") }
                    }
                }
            }
            Text("Expressive rounded surfaces and motion are used throughout the interface. Wallpaper colours require Android 12 or newer; other palettes work on older devices too.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Custom accent colour", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("system" to "Theme", "blue" to "Blue", "green" to "Green", "purple" to "Violet", "orange" to "Sunset").forEach { (key, label) ->
                    FilterChip(selected = featurePrefs.accentColor == key, onClick = { vm.updateFeaturePrefs { it.copy(accentColor = key) } }, label = { Text(label) })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Reduce motion", Modifier.weight(1f)); Switch(checked = featurePrefs.reducedMotion, onCheckedChange = { on -> vm.updateFeaturePrefs { it.copy(reducedMotion = on) } }) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Haptic feedback preference", Modifier.weight(1f)); Switch(checked = featurePrefs.haptics, onCheckedChange = { on -> vm.updateFeaturePrefs { it.copy(haptics = on) } }) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Compact file rows", Modifier.weight(1f)); Switch(checked = featurePrefs.compactMode, onCheckedChange = { on -> vm.updateFeaturePrefs { it.copy(compactMode = on) } }) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Low-memory mode", Modifier.weight(1f)); Switch(checked = featurePrefs.lowMemoryMode, onCheckedChange = { on -> vm.updateFeaturePrefs { it.copy(lowMemoryMode = on) } }) }
            Text("Preview/cache budget: ${featurePrefs.cacheLimitMb} MB", style = MaterialTheme.typography.titleSmall)
            androidx.compose.material3.Slider(value = featurePrefs.cacheLimitMb.toFloat(), onValueChange = { value -> vm.updateFeaturePrefs { it.copy(cacheLimitMb = value.toInt()) } }, valueRange = 0f..128f, steps = 7)
        }

        SectionCard("Home dashboard customization", Modifier.animateContentSize()) {
            Text("Choose which dashboard sections and quick actions appear on Home.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            listOf("automation" to "Automation summary", "storage" to "Storage summary", "tools" to "Storage tools", "activity" to "Recent activity").forEach { (key, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(label, Modifier.weight(1f))
                    Switch(checked = key in featurePrefs.homeCards, onCheckedChange = { show ->
                        vm.updateFeaturePrefs { p -> p.copy(homeCards = if (show) (p.homeCards + key).distinct() else p.homeCards - key) }
                    })
                }
            }
            Text("Quick actions", style = MaterialTheme.typography.titleSmall)
            listOf("files" to "Browse files", "automation" to "Manage rules", "storage" to "Storage tools").forEach { (key, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(label, Modifier.weight(1f))
                    Switch(checked = key in featurePrefs.quickActions, onCheckedChange = { show ->
                        vm.updateFeaturePrefs { p -> p.copy(quickActions = if (show) (p.quickActions + key).distinct() else p.quickActions - key) }
                    })
                }
            }
        }

        SectionCard("Navigation customization", Modifier.animateContentSize()) {
            Text("Change the order of the bottom navigation tabs. Up and Down controls move each destination; omitted destinations are restored automatically.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            val navItems = featurePrefs.navigationOrder.filter { name -> com.bijoyism.filenavigator.navigation.Destination.entries.any { it.name == name || it.label == name } }
            navItems.forEachIndexed { index, name ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(name, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    TextButton(enabled = index > 0, onClick = {
                        val updated = navItems.toMutableList(); val value = updated.removeAt(index); updated.add(index - 1, value)
                        vm.updateFeaturePrefs { it.copy(navigationOrder = updated) }
                    }) { Text("Up") }
                    TextButton(enabled = index < navItems.lastIndex, onClick = {
                        val updated = navItems.toMutableList(); val value = updated.removeAt(index); updated.add(index + 1, value)
                        vm.updateFeaturePrefs { it.copy(navigationOrder = updated) }
                    }) { Text("Down") }
                }
            }
            OutlinedButton(onClick = { vm.updateFeaturePrefs { it.copy(navigationOrder = com.bijoyism.filenavigator.navigation.Destination.entries.map { d -> d.name }) } }) { Text("Restore default order") }
        }

        SectionCard("Notifications") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Notify about new matching files", Modifier.weight(1f))
                Switch(checked = settings.notifications, onCheckedChange = { on ->
                    val needsPermission = on && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    if (needsPermission) permission.launch(Manifest.permission.POST_NOTIFICATIONS) else vm.setNotifications(on)
                })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Quiet mode (scan silently, no notifications)", Modifier.weight(1f))
                Switch(checked = settings.quiet, onCheckedChange = vm::setQuiet)
            }
        }

        SectionCard("Authorized folders") {
            if (grants.isEmpty()) Text("No folders authorized yet.")
            grants.forEach { uri ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text(vm.label(uri), Modifier.weight(1f))
                    TextButton(onClick = { vm.revoke(uri) }) { Text("Revoke") }
                }
            }
            OutlinedButton(onClick = { addFolder.launch(null) }) { Text("Add folder") }
        }

        SectionCard("Backup & restore", Modifier.animateContentSize()) {
            Text("Export rules, theme preferences, scheduling settings and operation history to a JSON file. File contents are not included.")
            OutlinedButton(onClick = { confirmBackupExport = true }) {
                Text("Export settings backup")
            }
            OutlinedButton(onClick = { importBackup.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) }) {
                Text("Restore from backup")
            }
            Text("Restoring replaces the saved rules and history. Background automation remains off until you review and enable it again.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SectionCard("Privacy & safety") {
            Text("File Navigator Lite stores rules and operation history locally. Storage analysis reads file metadata and hashes file contents only to compare duplicates; file contents are not uploaded.")
            OutlinedButton(onClick = { exportDiagnostics.launch("file-navigator-diagnostics.json") }) { Text("Export sanitized diagnostics") }
            Text("Diagnostics include aggregate counts and app settings only; they omit filenames, full paths, hashes, file contents, PIN and vault contents.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Automatic rules only access folders you authorize. Conflicts are handled by each rule's policy, and the app does not silently replace files during background organization.", style = MaterialTheme.typography.bodyMedium)
            Text("For safety, duplicate detection is read-only. Review and delete duplicates manually from the Files screen.", style = MaterialTheme.typography.bodyMedium)
        }

        SectionCard("App lock & privacy", Modifier.animateContentSize()) {
            Text(if (featurePrefs.privacyPinHash == null) "App lock is disabled." else "PIN lock is enabled. The app locks on startup and after the selected idle timeout when it leaves the foreground.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { pin = ""; confirmPin = ""; pinDialog = true }) { Text(if (featurePrefs.privacyPinHash == null) "Set PIN" else "Change PIN") }
                if (featurePrefs.privacyPinHash != null) OutlinedButton(onClick = { vm.updatePrivacyPin(null); pinMessage = "App lock disabled." }) { Text("Remove PIN") }
            }
            Text("Idle timeout", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(1, 5, 10, 30, 60).forEach { mins -> FilterChip(selected = featurePrefs.idleLockMinutes == mins, onClick = { vm.updateFeaturePrefs { it.copy(idleLockMinutes = mins) } }, label = { Text("${mins}m") }) }
            }
            Text("PIN is stored as a PBKDF2 hash, not plaintext. If you forget it, there is no recovery key; remove app data only if you accept that local-only vault data will also be deleted.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            pinMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        }

        SectionCard("Scan exclusions", Modifier.animateContentSize()) {
            Text("Excluded folders are skipped by storage analysis. Automatic file rules still use their own source folders unless those rules are disabled.")
            featurePrefs.scanExclusions.forEach { uri ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(vm.label(uri), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                    TextButton(onClick = { vm.updateFeaturePrefs { it.copy(scanExclusions = it.scanExclusions - uri) } }) { Text("Remove") }
                }
            }
            OutlinedButton(onClick = { excludeFolder.launch(null) }) { Text("Exclude folder…") }
        }

        SectionCard("Scheduled configuration backup", Modifier.animateContentSize()) {
            Text("Create periodic local backups of settings, rules, and history. File contents and encrypted vault items are not included.")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(0 to "Off", 24 to "Daily", 72 to "Every 3 days", 168 to "Weekly").forEach { (hours, label) ->
                    FilterChip(selected = featurePrefs.backupScheduleHours == hours, onClick = { vm.updateFeaturePrefs { it.copy(backupScheduleHours = hours) }; vm.scheduleBackup(hours) }, label = { Text(label) })
                }
            }
            Text("Backups are kept in the app-private directory. Export a separate copy before uninstalling or clearing app data.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SectionCard("Smart folders & collections", Modifier.animateContentSize()) {
            Text("Create saved search shortcuts based on a name query, extension, or MIME prefix.")
            OutlinedTextField(value = smartFolderName, onValueChange = { smartFolderName = it }, label = { Text("Smart folder name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = smartFolderQuery, onValueChange = { smartFolderQuery = it }, label = { Text("Name contains") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = smartFolderExtension, onValueChange = { smartFolderExtension = it }, label = { Text("Extension (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                val name = smartFolderName.trim()
                if (name.isNotEmpty()) {
                    vm.updateFeaturePrefs { it.copy(smartFolders = it.smartFolders.filterNot { f -> f.name.equals(name, true) } + com.bijoyism.filenavigator.data.SmartFolder(name = name, query = smartFolderQuery, extension = smartFolderExtension.trim().trimStart('.'))) }
                    smartFolderName = ""; smartFolderQuery = ""; smartFolderExtension = ""
                }
            }, enabled = smartFolderName.isNotBlank()) { Text("Save smart folder") }
            featurePrefs.smartFolders.forEach { folder ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(folder.name); Text("${folder.query.ifBlank { "Any name" }}${folder.extension.takeIf { it.isNotBlank() }?.let { " · .$it" } ?: ""}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    TextButton(onClick = { vm.updateFeaturePrefs { it.copy(smartFolders = it.smartFolders.filterNot { f -> f.id == folder.id }) } }) { Text("Remove") }
                }
            }
        }

        SectionCard("About") {
            Text("File Navigator Lite keeps rules and history on this device. Background checks are scheduled by Android and may not run at the exact selected minute.", style = MaterialTheme.typography.bodyMedium)
        }
        if (confirmBackupExport) AlertDialog(
            onDismissRequest = { confirmBackupExport = false },
            title = { Text("Export settings backup?") },
            text = { Text("The backup includes automation rules, app preferences, folder URI references, favourites, bookmarks, tags, collections and operation history. It does not include file contents, vault files, or the app-lock PIN. Store the exported JSON somewhere private.") },
            confirmButton = { TextButton(onClick = { confirmBackupExport = false; exportBackup.launch("file-navigator-backup.json") }) { Text("Export") } },
            dismissButton = { TextButton(onClick = { confirmBackupExport = false }) { Text("Cancel") } }
        )
        if (pinDialog) AlertDialog(
            onDismissRequest = { pinDialog = false }, title = { Text("Set app PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = pin, onValueChange = { pin = it.filter(Char::isDigit).take(8) }, label = { Text("PIN (4–8 digits)") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                    OutlinedTextField(value = confirmPin, onValueChange = { confirmPin = it.filter(Char::isDigit).take(8) }, label = { Text("Confirm PIN") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                }
            },
            confirmButton = { TextButton(onClick = {
                if (pin != confirmPin) pinMessage = "PINs do not match."
                else runCatching { PinSecurity.hash(pin) }.onSuccess { vm.updatePrivacyPin(it); pinMessage = "App PIN saved."; pinDialog = false }.onFailure { pinMessage = it.message ?: "Invalid PIN" }
            }) { Text("Save PIN") } },
            dismissButton = { TextButton(onClick = { pinDialog = false }) { Text("Cancel") } }
        )
        restorePreview?.let { preview -> AlertDialog(
            onDismissRequest = vm::dismissRestorePreview,
            title = { Text("Review backup") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Backup format version ${preview.version}")
                Text("${preview.ruleCount} automation rule(s) and ${preview.historyCount} history record(s)")
                Text(if (preview.includesFeatureSettings) "Includes themes, favourites, bookmarks, tags, collections, filters and scheduling preferences." else "Legacy backup: feature preferences are not included.")
                Text("The app PIN and encrypted vault files are never restored from a settings backup. Automation will remain disabled.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                Text("Restoring replaces the saved rules, settings and history.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            } },
            confirmButton = { TextButton(onClick = vm::confirmRestoreBackup) { Text("Restore backup") } },
            dismissButton = { TextButton(onClick = vm::dismissRestorePreview) { Text("Cancel") } }
        ) }
        notice?.let { MessageDialog("File Navigator Lite", it, vm::dismissNotice) }
    }
}

private fun intervalLabel(minutes: Int): String = when {
    minutes < 60 -> "${minutes}m"
    minutes == 60 -> "1h"
    minutes % 60 == 0 && minutes < 1440 -> "${minutes / 60}h"
    else -> "24h"
}
