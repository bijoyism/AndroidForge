package com.bijoyism.filenavigator.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.media.MediaPlayer
import android.media.MediaMetadataRetriever
import android.widget.MediaController
import android.widget.VideoView
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Dialog
import androidx.compose.material3.Surface
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import android.view.HapticFeedbackConstants
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bijoyism.filenavigator.domain.FileEntry
import com.bijoyism.filenavigator.domain.FileQuery
import com.bijoyism.filenavigator.domain.BatchRenamePlanner
import com.bijoyism.filenavigator.domain.Rule
import com.bijoyism.filenavigator.domain.SortKey
import com.bijoyism.filenavigator.domain.filterAndSort
import com.bijoyism.filenavigator.util.formatDate
import com.bijoyism.filenavigator.util.formatSize
import com.bijoyism.filenavigator.util.openFile
import com.bijoyism.filenavigator.util.shareFiles
import com.bijoyism.filenavigator.preview.PreviewType
import com.bijoyism.filenavigator.preview.previewType
import com.bijoyism.filenavigator.preview.ThumbnailCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private sealed interface FileDialog {
    object NewFolder : FileDialog
    object ConfirmDelete : FileDialog
    object ApplyRule : FileDialog
    class Rename(val entry: FileEntry) : FileDialog
    class Details(val entry: FileEntry) : FileDialog
    object BatchRename : FileDialog
    object Tags : FileDialog
    object Collection : FileDialog
}

private fun iconFor(entry: FileEntry): String {
    val mime = entry.mimeType.orEmpty()
    return when {
        entry.isDirectory -> "📁"
        mime.startsWith("image/") -> "🖼"
        mime.startsWith("video/") -> "🎞"
        mime.startsWith("audio/") -> "🎵"
        mime == "application/pdf" -> "📕"
        entry.name.endsWith(".apk", ignoreCase = true) -> "📦"
        mime.contains("zip") || mime.contains("compressed") -> "🗜"
        mime.startsWith("text/") -> "📄"
        else -> "📃"
    }
}

private fun subtitle(context: Context, entry: FileEntry): String {
    if (entry.isDirectory) return "Folder"
    val parts = mutableListOf<String>()
    if (entry.size >= 0) parts.add(formatSize(context, entry.size))
    if (entry.lastModified > 0) parts.add(formatDate(entry.lastModified))
    return parts.joinToString(" · ")
}

@Composable
fun FilesScreen(vm: FilesViewModel, rules: List<Rule>) {
    val s by vm.state.collectAsState()
    val context = LocalContext.current
    var query by rememberSaveable { mutableStateOf("") }
    var moving by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<FileDialog?>(null) }
    var previewEntry by remember { mutableStateOf<FileEntry?>(null) }
    var filterOpen by rememberSaveable { mutableStateOf(false) }
    var favoritesOnly by rememberSaveable { mutableStateOf(false) }
    var filterExtension by rememberSaveable { mutableStateOf("") }
    var filterMime by rememberSaveable { mutableStateOf("") }
    var minMb by rememberSaveable { mutableStateOf("") }
    var maxMb by rememberSaveable { mutableStateOf("") }
    var modifiedLastSevenDays by rememberSaveable { mutableStateOf(false) }
    val featurePrefs by vm.featurePrefs.collectAsState()
    val localView = LocalView.current
    val addFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) vm.grant(uri) }
    val pickDestination = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) vm.grantAndTransfer(uri, moving) }
    BackHandler(enabled = s.stack.isNotEmpty()) { vm.up() }

    val fileQuery = remember(s.query, filterExtension, filterMime, minMb, maxMb, modifiedLastSevenDays, featurePrefs.showHiddenInBrowser) {
        FileQuery(text = s.query, extension = filterExtension, mimePrefix = filterMime,
            minBytes = minMb.toLongOrNull()?.takeIf { it >= 0 }?.times(1024L * 1024L),
            maxBytes = maxMb.toLongOrNull()?.takeIf { it >= 0 }?.times(1024L * 1024L),
            modifiedAfterMillis = if (modifiedLastSevenDays) System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000 else null,
            includeHidden = featurePrefs.showHiddenInBrowser)
    }
    val sorted = remember(s.entries, s.query, s.sort, fileQuery, favoritesOnly, featurePrefs.favorites) {
        s.entries.filter { fileQuery.matches(it) && (!favoritesOnly || it.uri in featurePrefs.favorites) }.filterAndSort(s.query, s.sort)
    }
    val shown = sorted.take(s.shown)

    fun open(entry: FileEntry) {
        if (featurePrefs.haptics) localView.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        when {
            s.selecting -> vm.toggle(entry.uri)
            entry.isDirectory -> vm.enter(entry)
            else -> {
                vm.recordRecent(entry.uri)
                if (previewType(entry.name, entry.mimeType) != PreviewType.EXTERNAL) previewEntry = entry
                else if (!openFile(context, entry)) Toast.makeText(context, "No app can open this file", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (s.stack.isEmpty()) {
            RootsView(
                roots = s.roots, label = vm::labelOf, onOpen = vm::openRoot,
                bookmarks = featurePrefs.bookmarks, recents = featurePrefs.recentUris,
                smartFolders = featurePrefs.smartFolders, collections = featurePrefs.collections,
                onRecent = { uri -> vm.entryForUri(uri)?.let { previewEntry = it } },
                onSmartFolder = vm::openSmartFolder, onCollection = vm::openCollection,
                onAdd = { addFolder.launch(null) }
            )
        } else {
            Column(Modifier.fillMaxSize()) {
                Breadcrumbs(s.stack.map { it.name }, vm::navigateTo)
                OutlinedTextField(
                    value = query,
                    onValueChange = {
                        query = it
                        vm.setQuery(it)
                    },
                    label = { Text("Search this folder") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                )
                Toolbar(
                    sort = s.sort, grid = s.grid, selecting = s.selecting, vm = vm,
                    hidden = featurePrefs.showHiddenInBrowser, compact = featurePrefs.compactMode, favoritesOnly = favoritesOnly,
                    onNewFolder = { dialog = FileDialog.NewFolder }, onFilters = { filterOpen = true },
                    onToggleHidden = { vm.setShowHidden(!featurePrefs.showHiddenInBrowser) },
                    onToggleCompact = { vm.setCompactMode(!featurePrefs.compactMode) },
                    onToggleFavorites = { favoritesOnly = !favoritesOnly },
                    onToggleBookmark = { s.stack.lastOrNull()?.uri?.let(vm::toggleBookmark) },
                    bookmarked = s.stack.lastOrNull()?.uri in featurePrefs.bookmarks
                )
                if (s.selecting) {
                    SelectionBar(
                        count = s.selected.size,
                        single = s.selected.size == 1,
                        onSelectAll = { vm.selectAll(shown.map { it.uri }) },
                        onCopy = {
                            moving = false
                            pickDestination.launch(null)
                        },
                        onMove = {
                            moving = true
                            pickDestination.launch(null)
                        },
                        onDelete = { dialog = FileDialog.ConfirmDelete },
                        onRename = { if (vm.selectedEntries().size > 1) dialog = FileDialog.BatchRename else vm.selectedEntries().firstOrNull()?.let { dialog = FileDialog.Rename(it) } },
                        onDetails = { vm.selectedEntries().firstOrNull()?.let { dialog = FileDialog.Details(it) } },
                        onShare = {
                            if (!shareFiles(context, vm.selectedEntries())) Toast.makeText(context, "Select at least one file to share", Toast.LENGTH_SHORT).show()
                        },
                        onTags = { dialog = FileDialog.Tags },
                        onCollection = { dialog = FileDialog.Collection },
                        onChecksum = { vm.selectedEntries().firstOrNull()?.let(vm::checksum) },
                        onCompare = { vm.selectedEntries().takeIf { it.size == 2 }?.let { vm.compareEntries(it[0], it[1]) } },
                        onApplyRule = { dialog = FileDialog.ApplyRule }
                    )
                }
                when {
                    s.error != null -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(s.error.orEmpty(), color = MaterialTheme.colorScheme.error)
                        Button(onClick = { vm.reload() }) { Text("Retry") }
                    }
                    !s.loading && s.entries.isEmpty() -> CenterMessage("This folder is empty.")
                    !s.loading && sorted.isEmpty() -> CenterMessage("No files match your search.")
                    s.grid -> LazyVerticalGrid(columns = GridCells.Adaptive(104.dp), modifier = Modifier.fillMaxSize()) {
                        items(shown, key = { it.uri }) { e ->
                            Column(
                                Modifier.clickable { open(e) }.padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                if (s.selecting) Checkbox(checked = e.uri in s.selected, onCheckedChange = { vm.toggle(e.uri) })
                                FileThumbnail(e, 64.dp, featurePrefs.cacheLimitMb, featurePrefs.lowMemoryMode)
                                Text(e.name, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                                TextButton(onClick = { vm.toggleFavorite(e.uri) }) { Text(if (e.uri in featurePrefs.favorites) "★" else "☆") }
                            }
                        }
                        if (sorted.size > shown.size) {
                            item(span = { GridItemSpan(maxLineSpan) }) {
                                TextButton(onClick = { vm.loadMore() }) { Text("Load more (${sorted.size - shown.size} more)") }
                            }
                        }
                    }
                    else -> LazyColumn(Modifier.fillMaxSize()) {
                        items(shown, key = { it.uri }) { e ->
                            Row(
                                Modifier.fillMaxWidth().heightIn(min = if (featurePrefs.compactMode) 44.dp else 56.dp).clickable { open(e) }.padding(horizontal = 12.dp, vertical = if (featurePrefs.compactMode) 4.dp else 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (s.selecting) Checkbox(checked = e.uri in s.selected, onCheckedChange = { vm.toggle(e.uri) })
                                FileThumbnail(e, 40.dp, featurePrefs.cacheLimitMb, featurePrefs.lowMemoryMode)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(e.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                                    Text(subtitle(context, e), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    featurePrefs.tags[e.uri]?.takeIf { it.isNotEmpty() }?.let { tags ->
                                        Text(tags.joinToString(" · ") { "#$it" }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                                TextButton(onClick = { vm.toggleFavorite(e.uri) }) { Text(if (e.uri in featurePrefs.favorites) "★" else "☆") }
                            }
                        }
                        if (sorted.size > shown.size) {
                            item { TextButton(onClick = { vm.loadMore() }) { Text("Load more (${sorted.size - shown.size} more)") } }
                        }
                    }
                }
            }
        }
        if (s.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
    }

    previewEntry?.let { entry ->
        FilePreviewDialog(entry = entry, galleryEntries = sorted.filter { previewType(it.name, it.mimeType) == PreviewType.IMAGE }, onNavigate = { previewEntry = it }, onDismiss = { previewEntry = null }, onOpenExternally = {
            previewEntry = null
            if (!openFile(context, entry)) Toast.makeText(context, "No app can open this file", Toast.LENGTH_SHORT).show()
        })
    }

    if (filterOpen) {
        AlertDialog(
            onDismissRequest = { filterOpen = false },
            title = { Text("Advanced filters") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = filterExtension, onValueChange = { filterExtension = it }, label = { Text("Extension (e.g. pdf)") }, singleLine = true)
                    OutlinedTextField(value = filterMime, onValueChange = { filterMime = it }, label = { Text("MIME prefix (e.g. image/)") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = minMb, onValueChange = { minMb = it.filter(Char::isDigit) }, label = { Text("Min MB") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = maxMb, onValueChange = { maxMb = it.filter(Char::isDigit) }, label = { Text("Max MB") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Text("Hidden files are ${if (featurePrefs.showHiddenInBrowser) "included" else "excluded"}.", style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { filterExtension = ""; filterMime = ""; minMb = ""; maxMb = ""; favoritesOnly = false }) { Text("Clear filters") }
                }
            },
            confirmButton = { TextButton(onClick = { filterOpen = false }) { Text("Apply") } },
            dismissButton = { TextButton(onClick = { filterOpen = false }) { Text("Cancel") } }
        )
    }

    when (val d = dialog) {
        null -> Unit
        FileDialog.NewFolder -> NameDialog(
            title = "New folder",
            initial = "",
            confirmLabel = "Create",
            onConfirm = {
                vm.createFolder(it)
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        FileDialog.ConfirmDelete -> ConfirmDialog(
            title = "Delete ${s.selected.size} item(s)?",
            text = "Selected items will be moved to a hidden recycle-bin folder inside the authorized storage root. Restore them from Activity history. The original files are not permanently deleted.",
            confirmLabel = "Move to trash",
            onConfirm = {
                vm.deleteSelected()
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        FileDialog.ApplyRule -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Apply a rule to selected files") },
            text = {
                Column {
                    if (rules.isEmpty()) Text("Create a rule in the Automation tab first.")
                    rules.forEach { r ->
                        TextButton(onClick = {
                            vm.applyRule(r)
                            dialog = null
                        }) { Text(r.name) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("Cancel") } }
        )
        is FileDialog.Rename -> NameDialog(
            title = "Rename",
            initial = d.entry.name,
            confirmLabel = "Rename",
            onConfirm = {
                vm.rename(d.entry, it)
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        is FileDialog.Details -> FileDetailsDialog(d.entry, onDismiss = { dialog = null })
        FileDialog.BatchRename -> BatchRenameDialog(vm.selectedEntries(), onConfirm = { mapping -> vm.batchRename(vm.selectedEntries(), mapping); dialog = null }, onDismiss = { dialog = null })
        FileDialog.Tags -> TagDialog(vm.selectedEntries(), featurePrefs.tags, onSave = { text -> vm.setTags(s.selected.toList(), text); dialog = null }, onDismiss = { dialog = null })
        FileDialog.Collection -> CollectionDialog(onSave = { name -> vm.addToCollection(name, s.selected.toList()); dialog = null }, onDismiss = { dialog = null })
    }
    s.message?.let { MessageDialog("Result", it) { vm.dismissMessage() } }
}

@Composable
private fun FileDetailsDialog(entry: FileEntry, onDismiss: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("File properties") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Name: ${entry.name}")
                Text("Size: ${if (entry.size >= 0) formatSize(context, entry.size) else "unknown"}")
                Text("Type: ${entry.mimeType ?: "unknown"}")
                Text("Modified: ${if (entry.lastModified > 0) formatDate(entry.lastModified) else "unknown"}")
                Text("URI: ${entry.uri}", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("File URI", entry.uri))
                    }) { Text("Copy URI") }
                    TextButton(onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("File name", entry.name))
                    }) { Text("Copy name") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun FileThumbnail(entry: FileEntry, size: androidx.compose.ui.unit.Dp, cacheMb: Int, lowMemory: Boolean) {
    val context = LocalContext.current
    var bitmap by remember(entry.uri, cacheMb, lowMemory) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(entry.uri, cacheMb, lowMemory) {
        if (previewType(entry.name, entry.mimeType) == PreviewType.IMAGE) {
            bitmap = withContext(Dispatchers.IO) {
                ThumbnailCache.configure(cacheMb, lowMemory)
                ThumbnailCache.get(entry.uri) ?: runCatching {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    context.contentResolver.openInputStream(Uri.parse(entry.uri))?.use { BitmapFactory.decodeStream(it, null, bounds) }
                    val target = if (lowMemory) 128 else 256
                    val longest = maxOf(bounds.outWidth, bounds.outHeight).coerceAtLeast(1)
                    var sample = 1
                    while (longest / sample > target * 2) sample *= 2
                    val options = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.RGB_565 }
                    context.contentResolver.openInputStream(Uri.parse(entry.uri))?.use { BitmapFactory.decodeStream(it, null, options) }
                }.getOrNull()?.also { ThumbnailCache.put(entry.uri, it) }
            }
        }
    }
    val loaded = bitmap
    if (loaded != null) {
        Image(loaded.asImageBitmap(), contentDescription = entry.name, modifier = Modifier.size(size), contentScale = ContentScale.Crop)
    } else {
        Box(Modifier.size(size), contentAlignment = Alignment.Center) {
            Text(iconFor(entry), fontSize = if (size.value <= 44f) 22.sp else 32.sp)
        }
    }
}

@Composable
private fun RootsView(
    roots: List<String>,
    label: (String) -> String,
    onOpen: (String) -> Unit,
    bookmarks: Set<String>,
    recents: List<String>,
    smartFolders: List<com.bijoyism.filenavigator.data.SmartFolder>,
    collections: Map<String, List<String>>,
    onRecent: (String) -> Unit,
    onSmartFolder: (com.bijoyism.filenavigator.data.SmartFolder) -> Unit,
    onCollection: (String, List<String>) -> Unit,
    onAdd: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Files", style = MaterialTheme.typography.headlineSmall)
        if (roots.isEmpty()) Text("Android 10 only lets apps use folders you pick. Choose a folder (for example Download) to browse and organize it.", style = MaterialTheme.typography.bodyMedium)
        if (bookmarks.isNotEmpty()) {
            Text("Bookmarked folders", style = MaterialTheme.typography.titleMedium)
            bookmarks.forEach { uri -> Card(Modifier.fillMaxWidth().clickable { onOpen(uri) }) { Text("★  ${label(uri)}", Modifier.padding(14.dp)) } }
        }
        if (smartFolders.isNotEmpty()) {
            Text("Smart folders", style = MaterialTheme.typography.titleMedium)
            smartFolders.forEach { folder ->
                Card(Modifier.fillMaxWidth().clickable { onSmartFolder(folder) }) {
                    Column(Modifier.padding(12.dp)) {
                        Text("⌕  ${folder.name}", style = MaterialTheme.typography.titleSmall)
                        Text(listOf(folder.query.takeIf { it.isNotBlank() }?.let { "Name: $it" }, folder.extension.takeIf { it.isNotBlank() }?.let { "Extension: .$it" }, folder.mimePrefix.takeIf { it.isNotBlank() }?.let { "MIME: $it" }).filterNotNull().joinToString(" · ").ifBlank { "All visible files" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        if (collections.isNotEmpty()) {
            Text("Collections", style = MaterialTheme.typography.titleMedium)
            collections.toSortedMap().forEach { (name, uris) ->
                Card(Modifier.fillMaxWidth().clickable { onCollection(name, uris) }) {
                    Text("▦  $name · ${uris.size} item(s)", Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        if (recents.isNotEmpty()) {
            Text("Recently opened", style = MaterialTheme.typography.titleMedium)
            recents.take(5).forEach { uri ->
                TextButton(onClick = { onRecent(uri) }, modifier = Modifier.fillMaxWidth()) {
                    Text("◷  ${Uri.parse(uri).lastPathSegment?.substringAfterLast('/') ?: "Recent file"}", maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(roots, key = { it }) { root ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(root) }) {
                    Text("📁  ${label(root)}", Modifier.padding(16.dp), style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
        Button(onClick = onAdd) { Text("Add folder") }
    }
}

@Composable
private fun Breadcrumbs(names: List<String>, onClick: (Int) -> Unit) {
    LazyRow(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
        itemsIndexed(names) { index, name ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { onClick(index) }) { Text(name, maxLines = 1) }
                if (index < names.lastIndex) Text("›")
            }
        }
    }
}

@Composable
private fun Toolbar(
    sort: SortKey, grid: Boolean, selecting: Boolean, vm: FilesViewModel,
    hidden: Boolean, compact: Boolean, favoritesOnly: Boolean,
    onNewFolder: () -> Unit, onFilters: () -> Unit, onToggleHidden: () -> Unit,
    onToggleCompact: () -> Unit, onToggleFavorites: () -> Unit, onToggleBookmark: () -> Unit, bookmarked: Boolean
) {
    var menu by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box {
            TextButton(onClick = { menu = true }) { Text("Sort: ${sort.name.lowercase()}") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                SortKey.entries.forEach { key ->
                    DropdownMenuItem(text = { Text(key.name.lowercase()) }, onClick = { vm.setSort(key); menu = false })
                }
            }
        }
        TextButton(onClick = { vm.toggleGrid() }) { Text(if (grid) "List" else "Grid") }
        TextButton(onClick = onToggleFavorites) { Text(if (favoritesOnly) "All files" else "Favorites") }
        TextButton(onClick = onToggleBookmark) { Text(if (bookmarked) "★ Bookmarked" else "☆ Bookmark folder") }
        TextButton(onClick = onFilters) { Text("Filter") }
        TextButton(onClick = onToggleHidden) { Text(if (hidden) "Hide hidden" else "Show hidden") }
        TextButton(onClick = onToggleCompact) { Text(if (compact) "Comfortable" else "Compact") }
        TextButton(onClick = { vm.toggleSelecting() }) { Text(if (selecting) "Cancel select" else "Select") }
        TextButton(onClick = onNewFolder) { Text("New folder") }
        TextButton(onClick = { vm.reload() }) { Text("Refresh") }
    }
}

@Composable
private fun SelectionBar(
    count: Int,
    single: Boolean,
    onSelectAll: () -> Unit,
    onCopy: () -> Unit,
    onMove: () -> Unit,
    onDelete: () -> Unit,
    onRename: () -> Unit,
    onDetails: () -> Unit,
    onShare: () -> Unit,
    onTags: () -> Unit,
    onCollection: () -> Unit,
    onChecksum: () -> Unit,
    onCompare: () -> Unit,
    onApplyRule: () -> Unit
) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("$count selected", Modifier.padding(horizontal = 8.dp), style = MaterialTheme.typography.labelLarge)
        TextButton(onClick = onSelectAll) { Text("All") }
        TextButton(onClick = onCopy, enabled = count > 0) { Text("Copy to…") }
        TextButton(onClick = onMove, enabled = count > 0) { Text("Move to…") }
        TextButton(onClick = onDelete, enabled = count > 0) { Text("Delete") }
        TextButton(onClick = onRename, enabled = count > 0) { Text(if (single) "Rename" else "Batch rename") }
        TextButton(onClick = onDetails, enabled = single) { Text("Details") }
        TextButton(onClick = onShare, enabled = count > 0) { Text("Share") }
        TextButton(onClick = onTags, enabled = count > 0) { Text("Tags") }
        TextButton(onClick = onCollection, enabled = count > 0) { Text("Collection") }
        TextButton(onClick = onChecksum, enabled = count == 1) { Text("SHA-256") }
        TextButton(onClick = onCompare, enabled = count == 2) { Text("Compare") }
        TextButton(onClick = onApplyRule, enabled = count > 0) { Text("Apply rule") }
    }
}


@Composable
private fun TagDialog(entries: List<FileEntry>, tagsByUri: Map<String, List<String>>, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var tagsText by rememberSaveable(entries.map { it.uri }.joinToString()) { mutableStateOf(entries.firstOrNull()?.let { tagsByUri[it.uri].orEmpty().joinToString(", ") }.orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Tags for ${entries.size} file(s)") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = tagsText, onValueChange = { tagsText = it }, label = { Text("Comma-separated tags") }, placeholder = { Text("work, important, project") })
            Text("Saving replaces tags for the selected items. Leave blank to remove tags.", style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = { TextButton(onClick = { onSave(tagsText) }) { Text("Save tags") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun CollectionDialog(onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add to collection") }, text = {
        OutlinedTextField(value = name, onValueChange = { name = it.take(80) }, label = { Text("Collection name") }, placeholder = { Text("Study materials") }, singleLine = true)
    }, confirmButton = { TextButton(onClick = { onSave(name) }, enabled = name.isNotBlank()) { Text("Add") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun BatchRenameDialog(entries: List<FileEntry>, onConfirm: (List<Pair<String, String>>) -> Unit, onDismiss: () -> Unit) {
    var prefix by rememberSaveable { mutableStateOf("") }
    var suffix by rememberSaveable { mutableStateOf("") }
    var start by rememberSaveable { mutableStateOf("1") }
    var width by rememberSaveable { mutableStateOf("3") }
    var find by rememberSaveable { mutableStateOf("") }
    var replace by rememberSaveable { mutableStateOf("") }
    var modeReplace by rememberSaveable { mutableStateOf(false) }
    val mapping = remember(entries, prefix, suffix, start, width, find, replace, modeReplace) {
        runCatching {
            if (modeReplace) BatchRenamePlanner.replace(entries.map { it.name }, find, replace)
            else BatchRenamePlanner.numbered(entries.map { it.name }, prefix, start.toIntOrNull() ?: 1, width.toIntOrNull() ?: 3, suffix)
        }.getOrElse { emptyList() }
    }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Batch rename ${entries.size} files") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Numbered names", modifier = Modifier.weight(1f))
                androidx.compose.material3.Switch(checked = modeReplace, onCheckedChange = { modeReplace = it })
                Text("Find & replace")
            }
            if (modeReplace) {
                OutlinedTextField(value = find, onValueChange = { find = it }, label = { Text("Text to find") }, singleLine = true)
                OutlinedTextField(value = replace, onValueChange = { replace = it }, label = { Text("Replace with") }, singleLine = true)
            } else {
                OutlinedTextField(value = prefix, onValueChange = { prefix = it }, label = { Text("Prefix") }, singleLine = true)
                OutlinedTextField(value = suffix, onValueChange = { suffix = it }, label = { Text("Suffix before extension") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = start, onValueChange = { start = it.filter(Char::isDigit) }, label = { Text("Start") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = width, onValueChange = { width = it.filter(Char::isDigit) }, label = { Text("Digits") }, singleLine = true, modifier = Modifier.weight(1f))
                }
            }
            Text("Preview", style = MaterialTheme.typography.titleSmall)
            mapping.take(12).forEach { (old, new) -> Text("$old  →  $new", style = MaterialTheme.typography.bodySmall) }
            if (mapping.size > 12) Text("and ${mapping.size - 12} more…", style = MaterialTheme.typography.bodySmall)
            if (mapping.isEmpty() && entries.isNotEmpty()) Text("Enter valid values to generate a preview.", color = MaterialTheme.colorScheme.error)
        }
    }, confirmButton = { TextButton(onClick = { if (mapping.size == entries.size && mapping.all { it.first != it.second }) onConfirm(mapping) }, enabled = mapping.size == entries.size && mapping.all { it.first != it.second }) { Text("Rename") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun FilePreviewDialog(entry: FileEntry, galleryEntries: List<FileEntry>, onNavigate: (FileEntry) -> Unit, onDismiss: () -> Unit, onOpenExternally: () -> Unit) {
    val context = LocalContext.current
    val type = previewType(entry.name, entry.mimeType)
    var textContent by remember(entry.uri) { mutableStateOf<String?>(null) }
    var imageBitmap by remember(entry.uri) { mutableStateOf<Bitmap?>(null) }
    var loadError by remember(entry.uri) { mutableStateOf<String?>(null) }
    var pdfPage by remember(entry.uri) { mutableStateOf(0) }
    var pdfPageCount by remember(entry.uri) { mutableStateOf(0) }
    var archiveEntries by remember(entry.uri) { mutableStateOf<List<String>>(emptyList()) }
    var apkInfo by remember(entry.uri) { mutableStateOf<String?>(null) }
    var mediaReady by remember(entry.uri) { mutableStateOf(false) }
    var mediaPlaying by remember(entry.uri) { mutableStateOf(false) }
    var mediaDuration by remember(entry.uri) { mutableStateOf(0) }
    var mediaPosition by remember(entry.uri) { mutableStateOf(0) }
    var imageScale by remember(entry.uri) { mutableStateOf(1f) }
    var imageRotation by remember(entry.uri) { mutableStateOf(0f) }
    var imageOffset by remember(entry.uri) { mutableStateOf(Offset.Zero) }
    val mediaPlayer = remember(entry.uri, type) { if (type == PreviewType.AUDIO) MediaPlayer() else null }

    DisposableEffect(mediaPlayer) {
        onDispose { runCatching { mediaPlayer?.stop() }; runCatching { mediaPlayer?.release() } }
    }

    LaunchedEffect(entry.uri, type, pdfPage) {
        loadError = null
        withContext(Dispatchers.IO) {
            runCatching {
                when (type) {
                    PreviewType.TEXT -> {
                        val content = context.contentResolver.openInputStream(Uri.parse(entry.uri))?.use { stream ->
                            val bytes = ByteArray(256 * 1024 + 1)
                            var count = 0
                            while (count < bytes.size) {
                                val n = stream.read(bytes, count, bytes.size - count)
                                if (n < 0) break
                                count += n
                            }
                            String(bytes, 0, count.coerceAtMost(256 * 1024), Charsets.UTF_8)
                        } ?: error("The file could not be read")
                        textContent = content
                    }
                    PreviewType.IMAGE -> {
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        context.contentResolver.openInputStream(Uri.parse(entry.uri))?.use { BitmapFactory.decodeStream(it, null, bounds) }
                        val longest = maxOf(bounds.outWidth, bounds.outHeight).coerceAtLeast(1)
                        val sample = Integer.highestOneBit((longest / 1600).coerceAtLeast(1))
                        val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
                        val bitmap = context.contentResolver.openInputStream(Uri.parse(entry.uri))?.use { BitmapFactory.decodeStream(it, null, options) }
                        imageBitmap = bitmap ?: error("Unsupported or damaged image")
                    }
                    PreviewType.PDF -> {
                        val pfd = context.contentResolver.openFileDescriptor(Uri.parse(entry.uri), "r") ?: error("Could not open PDF")
                        pfd.use { descriptor ->
                            PdfRenderer(descriptor).use { renderer ->
                                pdfPageCount = renderer.pageCount
                                if (renderer.pageCount > 0) {
                                    val index = pdfPage.coerceIn(0, renderer.pageCount - 1)
                                    renderer.openPage(index).use { page ->
                                        val maxWidth = 1400
                                        val scale = minOf(1f, maxWidth.toFloat() / page.width.coerceAtLeast(1))
                                        val bitmap = Bitmap.createBitmap((page.width * scale).toInt().coerceAtLeast(1), (page.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                        imageBitmap = bitmap
                                    }
                                }
                            }
                        }
                    }
                    PreviewType.ARCHIVE -> {
                        val entries = mutableListOf<String>()
                        context.contentResolver.openInputStream(Uri.parse(entry.uri))?.use { input ->
                            java.util.zip.ZipInputStream(input.buffered()).use { zip ->
                                while (entries.size < 1000) {
                                    val item = zip.nextEntry ?: break
                                    val normalized = item.name.replace('\\', '/')
                                    if (normalized.startsWith('/') || normalized.split('/').any { it == ".." }) error("Unsafe path in archive")
                                    entries.add("${if (item.isDirectory) "[Folder] " else ""}${item.name}${if (item.size >= 0) " · ${item.size} B" else ""}")
                                    zip.closeEntry()
                                }
                            }
                        } ?: error("Could not read archive")
                        archiveEntries = entries
                    }
                    PreviewType.APK -> {
                        val temp = java.io.File(context.cacheDir, "preview_${System.currentTimeMillis()}.apk")
                        try {
                            context.contentResolver.openInputStream(Uri.parse(entry.uri))?.use { input -> temp.outputStream().use { input.copyTo(it) } } ?: error("Could not read APK")
                            @Suppress("DEPRECATION")
                            val info = context.packageManager.getPackageArchiveInfo(temp.absolutePath, 0) ?: error("APK metadata is unreadable")
                            val appLabel = info.applicationInfo?.let { appInfo ->
                                appInfo.sourceDir = temp.absolutePath
                                appInfo.publicSourceDir = temp.absolutePath
                                runCatching { context.packageManager.getApplicationLabel(appInfo).toString() }.getOrDefault(entry.name)
                            } ?: entry.name
                            @Suppress("DEPRECATION")
                            val versionCode = if (android.os.Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
                            apkInfo = "App: $appLabel\nPackage: ${info.packageName}\nVersion: ${info.versionName ?: "unknown"}\nVersion code: $versionCode\nMin SDK: ${info.applicationInfo?.minSdkVersion ?: "unknown"}"
                        } finally { temp.delete() }
                    }
                    else -> Unit
                }
            }.onFailure { loadError = it.message ?: "Unable to preview this file." }
        }
    }

    LaunchedEffect(mediaPlayer, entry.uri) {
        if (mediaPlayer != null) runCatching {
            mediaPlayer.setDataSource(context, Uri.parse(entry.uri))
            mediaPlayer.setOnPreparedListener { player -> mediaReady = true; mediaDuration = player.duration.coerceAtLeast(0) }
            mediaPlayer.setOnCompletionListener { mediaPlaying = false; mediaPosition = 0 }
            mediaPlayer.prepareAsync()
        }.onFailure { loadError = it.message ?: "Unable to prepare audio." }
    }
    LaunchedEffect(mediaPlayer, mediaPlaying) {
        while (mediaPlaying && mediaPlayer != null) {
            mediaPosition = runCatching { mediaPlayer.currentPosition }.getOrDefault(mediaPosition)
            delay(500)
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(shape = MaterialTheme.shapes.extraLarge, tonalElevation = 6.dp, modifier = Modifier.fillMaxWidth().padding(12.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(entry.name, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${formatSize(context, entry.size)} · ${type.name.lowercase().replaceFirstChar { it.uppercase() }} preview", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                when (type) {
                    PreviewType.IMAGE -> {
                        val bitmap = imageBitmap
                        if (bitmap != null) Image(bitmap.asImageBitmap(), contentDescription = entry.name, modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp).graphicsLayer(scaleX = imageScale, scaleY = imageScale, rotationZ = imageRotation, translationX = imageOffset.x, translationY = imageOffset.y).pointerInput(entry.uri) { detectTransformGestures { _, pan, zoom, rotation -> imageScale = (imageScale * zoom).coerceIn(1f, 5f); imageRotation = (imageRotation + rotation).coerceIn(-180f, 180f); imageOffset = Offset(imageOffset.x + pan.x, imageOffset.y + pan.y) } }, contentScale = ContentScale.Fit)
                        else if (loadError == null) LinearProgressIndicator(Modifier.fillMaxWidth())
                        Text("Pinch to zoom · drag to pan · twist to rotate", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        val galleryIndex = galleryEntries.indexOfFirst { it.uri == entry.uri }
                        if (galleryEntries.size > 1 && galleryIndex >= 0) Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { onNavigate(galleryEntries[(galleryIndex - 1 + galleryEntries.size) % galleryEntries.size]) }, enabled = galleryIndex > 0) { Text("Previous image") }
                            Text("${galleryIndex + 1} / ${galleryEntries.size}", Modifier.weight(1f))
                            TextButton(onClick = { onNavigate(galleryEntries[(galleryIndex + 1) % galleryEntries.size]) }, enabled = galleryIndex < galleryEntries.lastIndex) { Text("Next image") }
                        }
                        TextButton(onClick = { imageScale = 1f; imageRotation = 0f; imageOffset = Offset.Zero }) { Text("Reset image transform") }
                    }
                    PreviewType.TEXT -> {
                        val content = textContent
                        if (content != null) Text(content, modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()), fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
                        else if (loadError == null) LinearProgressIndicator(Modifier.fillMaxWidth())
                        if ((textContent?.length ?: 0) >= 256 * 1024) Text("Preview limited to the first 256 KB.", style = MaterialTheme.typography.bodySmall)
                    }
                    PreviewType.PDF -> {
                        imageBitmap?.let { Image(it.asImageBitmap(), contentDescription = "PDF page ${pdfPage + 1}", modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp), contentScale = ContentScale.Fit) } ?: run { if (loadError == null) LinearProgressIndicator(Modifier.fillMaxWidth()) }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { pdfPage = (pdfPage - 1).coerceAtLeast(0); imageBitmap = null }, enabled = pdfPage > 0) { Text("Previous") }
                            Text("${if (pdfPageCount > 0) pdfPage + 1 else 0} / $pdfPageCount", modifier = Modifier.weight(1f))
                            TextButton(onClick = { pdfPage = (pdfPage + 1).coerceAtMost((pdfPageCount - 1).coerceAtLeast(0)); imageBitmap = null }, enabled = pdfPage + 1 < pdfPageCount) { Text("Next") }
                        }
                    }
                    PreviewType.AUDIO -> {
                        Text(if (mediaReady) "${mediaPosition / 1000}s / ${mediaDuration / 1000}s" else "Preparing audio…", style = MaterialTheme.typography.bodyMedium)
                        LinearProgressIndicator(progress = { if (mediaDuration > 0) mediaPosition.toFloat() / mediaDuration else 0f }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { runCatching { if (mediaPlaying) mediaPlayer?.pause() else mediaPlayer?.start() }; mediaPlaying = !mediaPlaying }, enabled = mediaReady) { Text(if (mediaPlaying) "Pause" else "Play") }
                            TextButton(onClick = { runCatching { mediaPlayer?.seekTo(0) }; mediaPosition = 0 }) { Text("Restart") }
                        }
                    }
                    PreviewType.VIDEO -> AndroidView(factory = { viewContext ->
                        VideoView(viewContext).apply {
                            setVideoURI(Uri.parse(entry.uri))
                            val controls = MediaController(viewContext)
                            controls.setAnchorView(this)
                            setMediaController(controls)
                        }
                    }, modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 420.dp))
                    PreviewType.ARCHIVE -> {
                        if (archiveEntries.isEmpty() && loadError == null) LinearProgressIndicator(Modifier.fillMaxWidth())
                        Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            archiveEntries.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                        }
                        if (archiveEntries.size >= 1000) Text("Preview limited to the first 1,000 entries.", style = MaterialTheme.typography.bodySmall)
                    }
                    PreviewType.APK -> apkInfo?.let { Text(it, modifier = Modifier.verticalScroll(rememberScrollState()), style = MaterialTheme.typography.bodyMedium) } ?: run { if (loadError == null) LinearProgressIndicator(Modifier.fillMaxWidth()) }
                    PreviewType.EXTERNAL -> Text("No native preview is available.")
                }
                loadError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = onDismiss) { Text("Close") }
                    Spacer(Modifier.weight(1f))
                    Button(onClick = onOpenExternally) { Text("Open with…") }
                }
            }
        }
    }
}
