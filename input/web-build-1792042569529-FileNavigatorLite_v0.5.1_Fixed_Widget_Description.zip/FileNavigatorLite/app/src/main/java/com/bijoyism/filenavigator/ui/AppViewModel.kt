package com.bijoyism.filenavigator.ui

import android.net.Uri
import org.json.JSONArray
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bijoyism.filenavigator.AppContainer
import com.bijoyism.filenavigator.data.AppSettings
import com.bijoyism.filenavigator.domain.HistoryEntry
import com.bijoyism.filenavigator.domain.Rule
import com.bijoyism.filenavigator.worker.ReconcileScheduler
import com.bijoyism.filenavigator.worker.BackupScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import com.bijoyism.filenavigator.data.FeaturePrefs
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import org.json.JSONObject
import kotlinx.coroutines.withContext

/** State for Home, Activity and Settings. */
data class BackupPreview(val raw: String, val version: Int, val ruleCount: Int, val historyCount: Int, val includesFeatureSettings: Boolean)

class AppViewModel(private val c: AppContainer) : ViewModel() {
    val rules: StateFlow<List<Rule>> = c.data.rules.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val history: StateFlow<List<HistoryEntry>> = c.data.history.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val settings: StateFlow<AppSettings> = c.data.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())
    val featurePrefs: StateFlow<FeaturePrefs> = c.features.prefs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FeaturePrefs())

    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning

    private val _scanText = MutableStateFlow<String?>(null)
    val scanText: StateFlow<String?> = _scanText

    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice
    private val _restorePreview = MutableStateFlow<BackupPreview?>(null)
    val restorePreview: StateFlow<BackupPreview?> = _restorePreview

    private val _grants = MutableStateFlow(c.storage.grantedRoots())
    val grants: StateFlow<List<String>> = _grants

    fun label(uri: String): String = c.storage.label(uri)

    fun scanNow() {
        if (_scanning.value) return
        viewModelScope.launch {
            _scanning.value = true
            _scanText.value = try {
                val r = c.scanner.scan()
                buildString {
                    append("${r.matching} file(s) match your rules; ${r.newMatches} new since the last scan.")
                    if (r.notified) append(" Notification sent.")
                    r.problems.forEach { append("\n• ${it.ruleName}: ${it.message}") }
                }
            } catch (e: Exception) {
                "Scan failed: ${e.message}"
            }
            _scanning.value = false
        }
    }

    fun undo(entry: HistoryEntry) {
        viewModelScope.launch {
            val result = c.engine.undo(entry)
            if (result.ok) c.data.markUndone(entry.id)
            _notice.value = result.message
        }
    }

    fun clearHistory() {
        viewModelScope.launch { c.data.clearHistory() }
    }

    fun dismissNotice() {
        _notice.value = null
    }

    /** Export only aggregate diagnostic counts and settings; excludes paths, filenames, hashes and vault data. */
    fun exportDiagnostics(uri: Uri) {
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val appSettings = c.data.settings.first()
                    val prefs = c.features.currentPrefs()
                    val rules = c.data.rules.first()
                    val history = c.data.history.first()
                    val queue = c.features.queue.first()
                    val version = runCatching { c.appContext.packageManager.getPackageInfo(c.appContext.packageName, 0).versionName }.getOrNull().orEmpty()
                    val payload = JSONObject().apply {
                        put("format", "file-navigator-lite-diagnostics")
                        put("generatedAt", System.currentTimeMillis())
                        put("appVersion", version)
                        put("androidApi", android.os.Build.VERSION.SDK_INT)
                        put("themeMode", appSettings.themeMode)
                        put("colorTheme", appSettings.colorTheme)
                        put("autoOrganizeEnabled", appSettings.autoOrganize)
                        put("intervalMinutes", appSettings.intervalMinutes)
                        put("ruleCount", rules.size)
                        put("enabledRuleCount", rules.count { it.enabled })
                        put("historyCount", history.size)
                        put("historySuccessCount", history.count { it.success })
                        put("historyFailureCount", history.count { !it.success })
                        put("favoriteCount", prefs.favorites.size)
                        put("bookmarkCount", prefs.bookmarks.size)
                        put("authorizedFolderCount", c.storage.grantedRoots().size)
                        put("lowMemoryMode", prefs.lowMemoryMode)
                        put("cacheLimitMb", prefs.cacheLimitMb)
                        put("maxConcurrentTransfers", prefs.maxConcurrentTransfers)
                        put("queueCounts", JSONObject().apply {
                            listOf("QUEUED", "RUNNING", "PAUSED", "DONE", "FAILED", "CANCELLED").forEach { state -> put(state.lowercase(), queue.count { it.status == state }) }
                        })
                    }
                    c.appContext.contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { it.write(payload.toString(2)) }
                        ?: error("Could not open the selected diagnostics file")
                }
            }
            _notice.value = result.fold(
                { "Sanitized diagnostics exported. It contains aggregate counts and settings, not filenames, paths, file contents or vault data." },
                { "Diagnostics export failed: ${it.message}" }
            )
        }
    }

    fun writeBackup(uri: Uri) {
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val base = JSONObject(c.data.exportBackup())
                    base.put("version", 2)
                    base.put("featurePrefs", JSONObject(c.features.exportPrefsJson()))
                    val text = base.toString(2)
                    c.appContext.contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { it.write(text) }
                        ?: error("Could not open the selected backup file")
                }
            }
            _notice.value = result.fold({ "Backup exported successfully." }, { "Backup failed: ${it.message}" })
        }
    }

    fun previewBackup(uri: Uri) {
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val text = c.appContext.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        ?: error("Could not read the selected backup file")
                    require(text.length <= 2 * 1024 * 1024) { "Backup file is larger than the 2 MB safety limit." }
                    val root = JSONObject(text)
                    require(root.optString("format") == "file-navigator-lite-backup") { "This is not a File Navigator Lite backup." }
                    val version = root.optInt("version", 0)
                    require(version in 1..2) { "Unsupported backup version." }
                    val rules = root.optJSONArray("rules") ?: error("The backup is missing rules.")
                    val history = root.optJSONArray("history") ?: error("The backup is missing history.")
                    require(root.optJSONObject("settings") != null) { "The backup is missing settings." }
                    if (version >= 2) require(root.optJSONObject("featurePrefs") != null) { "Feature settings section is missing." }
                    BackupPreview(text, version, rules.length(), history.length(), version >= 2)
                }
            }
            _restorePreview.value = result.getOrNull()
            _notice.value = result.exceptionOrNull()?.let { "Backup preview failed: ${it.message}" }
        }
    }

    fun dismissRestorePreview() { _restorePreview.value = null }

    fun confirmRestoreBackup() {
        val preview = _restorePreview.value ?: return
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val root = JSONObject(preview.raw)
                    if (preview.version >= 2) c.features.importPrefsJson(root.getJSONObject("featurePrefs").toString())
                    root.put("version", 1)
                    root.remove("featurePrefs")
                    c.data.importBackup(root.toString())
                }
            }
            if (result.isSuccess) {
                val prefs = c.features.prefs.first()
                ReconcileScheduler.setEnabled(c.appContext, false, settings.value.intervalMinutes, prefs.batteryNotLow, prefs.networkPolicy)
            }
            _restorePreview.value = null
            _notice.value = result.fold(
                { "Backup restored. The app PIN was not imported and background automation remains off. Review your rules and permissions before enabling automation." },
                { "Restore failed: ${it.message}" }
            )
        }
    }

    fun setNotifications(on: Boolean) {
        viewModelScope.launch { c.data.setNotifications(on) }
    }

    fun setQuiet(on: Boolean) {
        viewModelScope.launch { c.data.setQuiet(on) }
    }

    fun setAutoOrganize(on: Boolean) {
        viewModelScope.launch {
            c.data.setAutoOrganize(on)
            val context = c.appContext
            val prefs = c.features.prefs.first()
            ReconcileScheduler.setEnabled(context, on, settings.value.intervalMinutes, prefs.batteryNotLow, prefs.networkPolicy)
        }
    }

    fun setIntervalMinutes(minutes: Int) {
        viewModelScope.launch {
            c.data.setIntervalMinutes(minutes)
            if (settings.value.autoOrganize) {
                val prefs = c.features.prefs.first()
                ReconcileScheduler.schedule(c.appContext, minutes, prefs.batteryNotLow, prefs.networkPolicy)
            }
        }
    }

    fun setThemeMode(mode: String) { viewModelScope.launch { c.data.setThemeMode(mode) } }
    fun setColorTheme(theme: String) { viewModelScope.launch { c.data.setColorTheme(theme) } }
    fun updateFeaturePrefs(transform: (FeaturePrefs) -> FeaturePrefs) {
        viewModelScope.launch {
            c.features.updatePrefs(transform)
            val updated = c.features.prefs.first()
            if (settings.value.autoOrganize) ReconcileScheduler.schedule(c.appContext, settings.value.intervalMinutes, updated.batteryNotLow, updated.networkPolicy)
        }
    }
    fun updatePrivacyPin(pin: String?) { viewModelScope.launch { c.features.updatePrefs { it.copy(privacyPinHash = pin) } } }
    fun scheduleBackup(hours: Int) { BackupScheduler.configure(c.appContext, hours) }

    fun grant(uri: Uri) {
        c.storage.grant(uri)
        _grants.update { c.storage.grantedRoots() }
    }

    fun revoke(uri: String) {
        c.storage.revoke(uri)
        _grants.update { c.storage.grantedRoots() }
    }
}
