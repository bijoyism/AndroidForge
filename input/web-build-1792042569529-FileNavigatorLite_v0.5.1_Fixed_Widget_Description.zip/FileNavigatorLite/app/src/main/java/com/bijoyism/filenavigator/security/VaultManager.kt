package com.bijoyism.filenavigator.security

import android.content.Context
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** AES-GCM encrypted vault. Files remain in app-private storage; original names are encrypted inside the payload. */
class VaultManager(private val context: Context) {
    private val directory = File(context.filesDir, "encrypted_vault").apply { mkdirs() }
    data class VaultItem(val id: String, val name: String, val size: Long)

    fun list(): List<VaultItem> = directory.listFiles { f -> f.isFile && f.extension == "vlt" }
        .orEmpty().mapNotNull { file -> runCatching { VaultItem(file.nameWithoutExtension, readEncryptedName(file), file.length()) }.getOrNull() }
        .sortedBy { it.name.lowercase() }

    fun importFrom(uri: Uri): VaultItem {
        val name = queryDisplayName(uri).ifBlank { "Private file" }.take(240)
        val id = java.util.UUID.randomUUID().toString()
        val target = File(directory, "$id.vlt")
        try {
            val iv = ByteArray(12).also { java.security.SecureRandom().nextBytes(it) }
            val output = FileOutputStream(target)
            output.write(iv.size)
            output.write(iv)
            output.flush()
            val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv)) }
            CipherOutputStream(output, cipher).use { encrypted ->
                DataOutputStream(encrypted).use { data ->
                    data.writeUTF(name)
                    context.contentResolver.openInputStream(uri)?.use { input -> input.copyTo(data, 64 * 1024) }
                        ?: error("Cannot open selected file")
                }
            }
            return VaultItem(id, name, target.length())
        } catch (e: Exception) {
            target.delete()
            throw e
        }
    }

    fun exportTo(id: String, destination: Uri) {
        val file = fileFor(id)
        FileInputStream(file).use { raw ->
            val ivSize = raw.read()
            require(ivSize in 12..16) { "Invalid vault item" }
            val iv = ByteArray(ivSize)
            require(raw.read(iv) == ivSize) { "Vault item is incomplete" }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv)) }
            val encrypted = CipherInputStream(raw, cipher)
            DataInputStream(encrypted).use { data ->
                data.readUTF() // name is encrypted; destination path/name is chosen via the system picker.
                context.contentResolver.openOutputStream(destination, "w")?.use { out -> data.copyTo(out, 64 * 1024) }
                    ?: error("Could not write selected destination")
            }
        }
    }

    fun delete(id: String): Boolean = fileFor(id).delete()

    private fun readEncryptedName(file: File): String = FileInputStream(file).use { raw ->
        val ivSize = raw.read(); require(ivSize in 12..16)
        val iv = ByteArray(ivSize); require(raw.read(iv) == ivSize)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv)) }
        DataInputStream(CipherInputStream(raw, cipher)).use { it.readUTF() }
    }

    private fun fileFor(id: String): File {
        require(id.matches(Regex("[0-9a-fA-F-]{36}"))) { "Invalid vault item ID" }
        return File(directory, "$id.vlt").also { require(it.isFile) { "Vault item no longer exists" } }
    }

    private fun queryDisplayName(uri: Uri): String = runCatching {
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0).orEmpty() else ""
        }.orEmpty()
    }.getOrDefault("")

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    companion object { private const val KEY_ALIAS = "file_navigator_vault_aes_gcm" }
}
