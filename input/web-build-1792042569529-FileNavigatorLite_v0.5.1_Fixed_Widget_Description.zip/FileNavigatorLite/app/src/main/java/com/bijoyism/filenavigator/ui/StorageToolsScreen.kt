package com.bijoyism.filenavigator.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Slider
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.bijoyism.filenavigator.util.formatSize

@Composable
fun StorageToolsScreen(vm: StorageToolsViewModel) {
    val context = LocalContext.current
    val report by vm.report.collectAsState()
    val busy by vm.busy.collectAsState()
    val message by vm.message.collectAsState()
    val performanceSummary by vm.performanceSummary.collectAsState()
    val queue by vm.queue.collectAsState()
    var archiveSource by remember { mutableStateOf<Uri?>(null) }
    var extractSource by remember { mutableStateOf<Uri?>(null) }
    var archiveName by rememberSaveable { mutableStateOf("Archive.zip") }
    var pendingAction by rememberSaveable { mutableStateOf("") }
    var compressionLevel by rememberSaveable { mutableStateOf(6f) }
    var inspectUri by remember { mutableStateOf<Uri?>(null) }
    var selectedArchiveEntries by remember { mutableStateOf(setOf<String>()) }
    var archivePassword by rememberSaveable { mutableStateOf("") }
    var splitPartSizeMb by rememberSaveable { mutableStateOf("100") }
    var joinedParts by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var vaultExportId by rememberSaveable { mutableStateOf<String?>(null) }
    var confirmEmptyTrash by rememberSaveable { mutableStateOf(false) }
    val archiveEntries by vm.archiveEntries.collectAsState()
    val vaultItems by vm.vaultItems.collectAsState()
    val vaultMessage by vm.vaultMessage.collectAsState()
    val progress by vm.progress.collectAsState()
    LaunchedEffect(Unit) { vm.refreshVault() }

    val chooseFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            when (pendingAction) {
                "zip-source" -> { archiveSource = uri; pendingAction = "zip-destination" }
                "zip-destination" -> {
                    archiveSource?.let { vm.createArchive(it, uri, archiveName, compressionLevel.toInt()) }
                    pendingAction = ""
                }
                "extract-destination" -> {
                    extractSource?.let { vm.extractArchive(it, uri) }
                    pendingAction = ""
                }
                "selected-extract-destination" -> {
                    inspectUri?.let { vm.extractSelectedArchive(it, uri, selectedArchiveEntries) }
                    pendingAction = ""
                }
                "enc-zip-source" -> { archiveSource = uri; pendingAction = "enc-zip-destination" }
                "enc-zip-destination" -> {
                    archiveSource?.let { vm.createEncryptedZip(it, uri, archiveName, archivePassword.toCharArray()) }
                    archivePassword = ""; pendingAction = ""
                }
                "tar-source" -> { archiveSource = uri; pendingAction = "tar-destination" }
                "tar-destination" -> { archiveSource?.let { vm.createTarGz(it, uri, archiveName) }; pendingAction = "" }
                "gzip-destination" -> { extractSource?.let { vm.createGzip(it, uri, archiveName) }; pendingAction = "" }
                "gunzip-destination" -> { extractSource?.let { vm.extractGzip(it, uri, archiveName.removeSuffix(".gz")) }; pendingAction = "" }
                "split-destination" -> { extractSource?.let { vm.splitFile(it, uri, archiveName.substringBeforeLast('.').ifBlank { "file" }, splitPartSizeMb.toIntOrNull() ?: 100) }; pendingAction = "" }
                "join-destination" -> { vm.joinParts(joinedParts, uri, archiveName); pendingAction = "" }
                "tar-extract-destination" -> { extractSource?.let { vm.extractTarGz(it, uri) }; pendingAction = "" }
                "enc-extract-destination" -> { extractSource?.let { vm.extractEncryptedZip(it, uri, archivePassword.toCharArray()) }; archivePassword = ""; pendingAction = "" }
            }
        }
    }
    val chooseZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { extractSource = uri; pendingAction = "extract-destination"; chooseFolder.launch(null) }
    }
    val inspectZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { inspectUri = uri; selectedArchiveEntries = emptySet(); vm.inspectArchive(uri) }
    }
    val chooseExtraFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            when (pendingAction) {
                "gzip-source" -> { extractSource = uri; pendingAction = "gzip-destination"; chooseFolder.launch(null) }
                "gunzip-source" -> { extractSource = uri; pendingAction = "gunzip-destination"; chooseFolder.launch(null) }
                "split-source" -> { extractSource = uri; pendingAction = "split-destination"; chooseFolder.launch(null) }
                "tar-extract-source" -> { extractSource = uri; pendingAction = "tar-extract-destination"; chooseFolder.launch(null) }
                "enc-extract-source" -> { extractSource = uri; pendingAction = "enc-extract-destination"; chooseFolder.launch(null) }
            }
        }
    }
    val chooseParts = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) { joinedParts = uris; pendingAction = "join-destination"; chooseFolder.launch(null) }
    }
    val exportReport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri -> if (uri != null) vm.exportReport(uri) }
    val chooseVaultFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importVault(uri) }
    val exportVaultFile = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val id = vaultExportId
        if (uri != null && id != null) vm.exportVault(id, uri)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Storage & tools", style = MaterialTheme.typography.headlineLarge)
        Text(
            "Understand storage, find exact duplicates and manage ZIP archives. Scanning is read-only.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        SectionCard("Persistent transfer queue", Modifier.animateContentSize()) {
            Text("Copy and move tasks are stored on this device and processed in the background. Android and storage-provider restrictions can affect exact progress reporting.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${queue.count { it.status in setOf("QUEUED", "RUNNING", "PAUSED") }} active · ${queue.count { it.status == "DONE" }} completed", modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                TextButton(onClick = vm::clearQueueHistory, enabled = queue.any { it.status in setOf("DONE", "FAILED", "CANCELLED") }) { Text("Clear finished") }
            }
            val activeTransfers = queue.filter { it.status in setOf("QUEUED", "RUNNING") }
            if (activeTransfers.isNotEmpty()) {
                val totalProgress = activeTransfers.map { it.progress.coerceIn(0, 100) }.average().toFloat() / 100f
                Text("Overall active progress · ${(totalProgress * 100).toInt()}%", style = MaterialTheme.typography.labelLarge)
                LinearProgressIndicator(progress = { totalProgress }, modifier = Modifier.fillMaxWidth())
            }
            if (queue.isEmpty()) Text("The queue is empty. Select files in Files and choose Copy to… or Move to… to enqueue transfers.")
            queue.sortedByDescending { it.createdAt }.take(100).forEach { job ->
                Column(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(job.targetName, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                        Text(job.status.lowercase().replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.labelMedium, color = when (job.status) {
                            "FAILED", "CANCELLED" -> MaterialTheme.colorScheme.error
                            "DONE" -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        })
                    }
                    LinearProgressIndicator(progress = { job.progress / 100f }, modifier = Modifier.fillMaxWidth())
                    Text("${job.kind} · ${job.progress}%${job.error?.let { " · $it" } ?: ""}", style = MaterialTheme.typography.bodySmall, color = if (job.error != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (job.status == "QUEUED") TextButton(onClick = { vm.pauseQueue(job.id) }) { Text("Pause") }
                        if (job.status in setOf("PAUSED", "FAILED", "CANCELLED")) TextButton(onClick = { vm.retryQueue(job.id) }) { Text("Resume / retry") }
                        if (job.status in setOf("QUEUED", "RUNNING", "PAUSED")) TextButton(onClick = { vm.cancelQueue(job.id) }) { Text("Cancel") }
                    }
                }
            }
        }

        SectionCard("Storage analyzer", Modifier.animateContentSize()) {
            Text("Scan up to 10,000 files across authorized folders. Files that cannot be read are skipped and counted.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = vm::analyze, enabled = !busy) { Text("Analyze storage") }
                OutlinedButton(onClick = vm::cancelAnalysis, enabled = busy) { Text("Cancel scan") }
                TextButton(onClick = { exportReport.launch("file-navigator-storage-report.csv") }, enabled = report != null) { Text("Export CSV") }
            }
            if (busy) { LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth()); CircularProgressIndicator() }
            message?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            performanceSummary?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary) }
            AnimatedVisibility(report != null) {
                report?.let { data ->
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${data.scannedFiles} files · ${formatSize(context, data.totalBytes)}", style = MaterialTheme.typography.titleLarge)
                        Text("Storage by category", style = MaterialTheme.typography.titleMedium)
                        data.categoryBytes.toList().sortedByDescending { it.second }.forEach { (category, bytes) ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(category)
                                Text(formatSize(context, bytes), color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        Text("Largest files", style = MaterialTheme.typography.titleMedium)
                        data.largestFiles.take(10).forEach { file ->
                            Column {
                                Text(file.name, maxLines = 2)
                                Text(formatSize(context, file.size), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Text("${data.skippedFiles} item(s) could not be read.", style = MaterialTheme.typography.bodySmall)
                        SectionCard("Old files") {
                            Text("Files not modified in over a year (${data.oldFiles.size} shown). Review before deleting.")
                            data.oldFiles.take(20).forEach { Text("${it.name} · ${formatSize(context, it.size)}", style = MaterialTheme.typography.bodySmall) }
                        }
                        SectionCard("Empty folders") {
                            Text("${data.emptyFolders.size} empty folder(s) found. No folders are removed automatically.")
                            data.emptyFolders.take(20).forEach { Text(it.name, style = MaterialTheme.typography.bodySmall) }
                        }
                        SectionCard("Similar image suggestions") {
                            Text("Perceptual hashes suggest these images may look similar. This is approximate; review files before removing anything.")
                            data.similarImageGroups.take(20).forEachIndexed { i, group -> Text("Group ${i + 1}: ${group.joinToString { it.name }}", style = MaterialTheme.typography.bodySmall) }
                        }
                        SectionCard("File types") {
                            data.typeCounts.forEach { (extension, count) -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(extension); Text(count.toString()) } }
                        }
                    }
                }
            }
        }
        SectionCard("Exact duplicate finder", Modifier.animateContentSize()) {
            Text("Duplicate groups are matched by file size and SHA-256 content hash. Nothing is deleted automatically.")
            val groups = report?.duplicateGroups.orEmpty()
            if (groups.isEmpty()) Text("Run a storage analysis to check for duplicates.") else {
                Text("${groups.size} duplicate group(s) found", style = MaterialTheme.typography.titleMedium)
                groups.forEachIndexed { index, group ->
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Group ${index + 1} · ${formatSize(context, group.size)}", style = MaterialTheme.typography.titleSmall)
                        group.files.forEach { Text("• ${fileNameWithParent(it.uri, it.name)}", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
        }
        SectionCard("ZIP archive tools", Modifier.animateContentSize()) {
            Text("Create a ZIP from a folder or extract an existing ZIP into a folder you choose. Existing files are not overwritten.")
            OutlinedTextField(
                value = archiveName,
                onValueChange = { archiveName = it },
                label = { Text("Archive name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("Compression level: ${compressionLevel.toInt()} / 9")
            Slider(value = compressionLevel, onValueChange = { compressionLevel = it }, valueRange = 0f..9f, steps = 8)
            Button(onClick = { pendingAction = "zip-source"; chooseFolder.launch(null) }, enabled = !busy) {
                Text("Create ZIP…")
            }
            OutlinedButton(onClick = { chooseZip.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }, enabled = !busy) { Text("Extract ZIP archive") }
            OutlinedButton(onClick = { inspectZip.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }, enabled = !busy) { Text("Browse ZIP before extraction") }
            OutlinedTextField(value = archivePassword, onValueChange = { archivePassword = it.take(128) }, label = { Text("Archive password (encrypted ZIP)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pendingAction = "enc-zip-source"; chooseFolder.launch(null) }, enabled = !busy && archivePassword.length >= 8) { Text("Create AES-256 ZIP") }
                OutlinedButton(onClick = { pendingAction = "enc-extract-source"; chooseExtraFile.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }, enabled = !busy && archivePassword.isNotBlank()) { Text("Extract encrypted ZIP") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pendingAction = "tar-source"; chooseFolder.launch(null) }, enabled = !busy) { Text("Create TAR.GZ") }
                OutlinedButton(onClick = { pendingAction = "tar-extract-source"; chooseExtraFile.launch(arrayOf("application/gzip", "application/x-gzip", "application/octet-stream", "*/*")) }, enabled = !busy) { Text("Extract TAR.GZ") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pendingAction = "gzip-source"; chooseExtraFile.launch(arrayOf("*/*")) }, enabled = !busy) { Text("GZIP file") }
                OutlinedButton(onClick = { pendingAction = "gunzip-source"; chooseExtraFile.launch(arrayOf("application/gzip", "application/x-gzip", "*/*")) }, enabled = !busy) { Text("Extract GZIP") }
            }
            OutlinedTextField(value = splitPartSizeMb, onValueChange = { splitPartSizeMb = it.filter(Char::isDigit).take(4) }, label = { Text("Split part size (MB)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pendingAction = "split-source"; chooseExtraFile.launch(arrayOf("*/*")) }, enabled = !busy) { Text("Split file") }
                OutlinedButton(onClick = { chooseParts.launch(arrayOf("*/*")) }, enabled = !busy) { Text("Join .part files") }
            }
            if (archiveEntries.isNotEmpty()) {
                Text("Archive entries (${archiveEntries.size}) · select items for extraction", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { selectedArchiveEntries = archiveEntries.filterNot { it.isDirectory }.map { it.name }.toSet() }) { Text("Select files") }
                    TextButton(onClick = { selectedArchiveEntries = emptySet() }) { Text("Clear") }
                }
                Column(Modifier.heightIn(max = 280.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    archiveEntries.forEach { item ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = item.name in selectedArchiveEntries, onCheckedChange = { checked -> selectedArchiveEntries = if (checked) selectedArchiveEntries + item.name else selectedArchiveEntries - item.name }, enabled = !item.isDirectory)
                            Column(Modifier.weight(1f)) {
                                Text(item.name, maxLines = 2, style = MaterialTheme.typography.bodySmall)
                                val sizeText = if (item.size >= 0) "${formatSize(context, item.size)}${if (item.compressedSize >= 0) " · compressed ${formatSize(context, item.compressedSize)}" else ""}" else "Size unknown"
                                Text(sizeText, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                OutlinedButton(onClick = { pendingAction = "selected-extract-destination"; chooseFolder.launch(null) }, enabled = selectedArchiveEntries.isNotEmpty() && inspectUri != null) { Text("Extract selected files…") }
            }
            when (pendingAction) {
                "zip-destination", "enc-zip-destination", "tar-destination", "gzip-destination", "gunzip-destination", "split-destination", "join-destination", "tar-extract-destination", "enc-extract-destination" -> TextButton(onClick = { chooseFolder.launch(null) }) { Text("Choose destination folder") }
                "extract-destination" -> Text("Choose a destination folder to finish extraction.")
                else -> Unit
            }
        }
        SectionCard("Recycle bin & cleanup", Modifier.animateContentSize()) {
            Text("File deletion from the browser moves items to a hidden recycle-bin folder. You can restore recent trash operations from Activity history.")
            OutlinedButton(onClick = { confirmEmptyTrash = true }) { Text("Empty recycle bin permanently…") }
            Text("Cleanup suggestions from the last scan: ${report?.oldFiles?.size ?: 0} old files, ${report?.emptyFolders?.size ?: 0} empty folders, ${report?.duplicateGroups?.size ?: 0} exact duplicate groups. No cleanup action runs automatically.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SectionCard("Encrypted private vault", Modifier.animateContentSize()) {
            Text("Vault files are encrypted with AES-GCM using a non-exportable Android Keystore key. Importing creates an encrypted copy; it does not delete the original. Uninstalling the app removes local vault data, so keep separate copies of important originals.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { chooseVaultFile.launch(arrayOf("*/*")) }) { Text("Import file") }
                OutlinedButton(onClick = vm::refreshVault) { Text("Refresh vault") }
            }
            vaultMessage?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (vaultItems.isEmpty()) Text("No encrypted items yet. The vault is local to this app and is not included in settings backups.")
            vaultItems.forEach { item ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.name, maxLines = 2, style = MaterialTheme.typography.bodyMedium)
                        Text("Encrypted · ${formatSize(context, item.size)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = { vaultExportId = item.id; exportVaultFile.launch(item.name) }) { Text("Export") }
                    TextButton(onClick = { vm.deleteVault(item.id) }) { Text("Remove") }
                }
            }
        }

        if (confirmEmptyTrash) AlertDialog(
            onDismissRequest = { confirmEmptyTrash = false },
            title = { Text("Empty recycle bin permanently?") },
            text = { Text("This permanently deletes all items stored in the app's recycle-bin folders. This cannot be undone. Other files are not affected.") },
            confirmButton = { TextButton(onClick = { vm.emptyTrash(); confirmEmptyTrash = false }) { Text("Permanently delete") } },
            dismissButton = { TextButton(onClick = { confirmEmptyTrash = false }) { Text("Cancel") } }
        )

        SectionCard("Safety") {
            Text("This screen never deletes duplicates. ZIP extraction rejects path traversal entries and stops on filename conflicts. Keep important files backed up before bulk operations.")
        }
    }
}

private fun fileNameWithParent(uri: String, name: String): String = "$name · ${Uri.parse(uri).lastPathSegment.orEmpty().takeLast(28)}"
