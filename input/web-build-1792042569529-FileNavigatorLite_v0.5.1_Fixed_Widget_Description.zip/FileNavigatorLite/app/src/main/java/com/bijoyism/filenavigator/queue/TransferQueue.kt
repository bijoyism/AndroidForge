package com.bijoyism.filenavigator.queue

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.bijoyism.filenavigator.FileNavigatorApp
import com.bijoyism.filenavigator.data.FeatureData
import com.bijoyism.filenavigator.data.TransferJob
import com.bijoyism.filenavigator.domain.TransferSlots
import com.bijoyism.filenavigator.domain.TransferCancelledException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import com.bijoyism.filenavigator.notifications.TransferNotifier
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

/** Persistent queue stored separately from settings. WorkManager resumes eligible jobs after process/device restart. */
class TransferQueueManager(private val context: Context, private val featureData: FeatureData) {
    suspend fun enqueue(job: TransferJob): TransferJob {
        featureData.addQueueJob(job)
        schedule(job)
        return job
    }

    suspend fun retry(id: String): Boolean {
        val job = featureData.queue.first().firstOrNull { it.id == id } ?: return false
        if (job.status !in setOf("FAILED", "CANCELLED", "PAUSED")) return false
        val next = job.copy(status = "QUEUED", progress = 0, error = null, workId = null, updatedAt = System.currentTimeMillis())
        featureData.updateQueueJob(id) { next }
        schedule(next)
        return true
    }

    suspend fun pauseQueued(id: String): Boolean {
        val job = featureData.queue.first().firstOrNull { it.id == id } ?: return false
        if (job.status != "QUEUED") return false
        // Leave its WorkRequest in the lane. When it reaches the head, the worker sees PAUSED
        // and exits successfully so later jobs in the same lane are not cancelled as dependents.
        featureData.updateQueueJob(id) { it.copy(status = "PAUSED", error = "Paused before the transfer started.") }
        return true
    }

    suspend fun cancel(id: String): Boolean {
        val job = featureData.queue.first().firstOrNull { it.id == id } ?: return false
        if (job.status !in setOf("QUEUED", "RUNNING", "PAUSED")) return false
        job.workId?.let(TransferCancellationRegistry::cancel)
        if (job.status == "RUNNING") {
            featureData.updateQueueJob(id) { it.copy(error = "Cancellation requested…") }
        } else {
            // Do not cancel a tagged request in the middle of a unique-work lane; doing so can
            // cancel dependent work. The worker will skip this item when it reaches the head.
            featureData.updateQueueJob(id) { it.copy(status = "CANCELLED", error = "Cancelled by user.") }
        }
        return true
    }

    private suspend fun schedule(job: TransferJob) {
        val prefs = featureData.currentPrefs()
        val constraints = Constraints.Builder().apply {
            if (prefs.batteryNotLow) setRequiresBatteryNotLow(true)
            when (prefs.networkPolicy) {
                "unmetered" -> setRequiredNetworkType(NetworkType.UNMETERED)
                "connected" -> setRequiredNetworkType(NetworkType.CONNECTED)
            }
        }.build()
        val attemptId = java.util.UUID.randomUUID().toString()
        val scheduledRequest = OneTimeWorkRequestBuilder<TransferWorker>()
            .setInputData(Data.Builder()
                .putString(TransferWorker.KEY_JOB_ID, job.id)
                .putString(TransferWorker.KEY_ATTEMPT_ID, attemptId)
                .build())
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .addTag(tag(job.id))
            .build()
        featureData.updateQueueJob(job.id) { it.copy(workId = attemptId) }
        // Each deterministic slot serializes its own chain, while allowing 1–3 chains
        // to run independently according to the user's low-memory/performance setting.
        val slotCount = prefs.maxConcurrentTransfers.coerceIn(1, 3)
        val slot = TransferSlots.slotFor(job.id, slotCount)
        WorkManager.getInstance(context).enqueueUniqueWork(
            "transfer_queue_slot_$slot",
            ExistingWorkPolicy.APPEND_OR_REPLACE,
            scheduledRequest
        )
    }

    companion object { fun tag(id: String) = "transfer-$id" }
}

class TransferWorker(context: Context, params: androidx.work.WorkerParameters) : androidx.work.CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getString(KEY_JOB_ID) ?: return Result.failure()
        val attemptId = inputData.getString(KEY_ATTEMPT_ID) ?: return Result.failure()
        val container = (applicationContext as FileNavigatorApp).container
        val features = container.features
        val job = features.queue.first().firstOrNull { it.id == id } ?: run { TransferCancellationRegistry.clear(attemptId); return Result.failure() }
        // A stale queued WorkRequest can remain in a lane after pause/retry. The attempt token
        // prevents an old request from starting a newer retry of the same persisted job.
        if (job.status != "QUEUED" || job.workId != attemptId) {
            TransferCancellationRegistry.clear(attemptId)
            return Result.success()
        }
        TransferCancellationRegistry.start(attemptId)
        if (TransferCancellationRegistry.isCancelled(attemptId)) {
            features.updateQueueJob(id) { it.copy(status = "CANCELLED", error = "Cancelled by user.") }
            TransferCancellationRegistry.clear(attemptId)
            return Result.success()
        }
        return try {
            features.updateQueueJob(id) { it.copy(status = "RUNNING", progress = 5, error = null) }
            if (container.data.settings.first().notifications) TransferNotifier.show(applicationContext, id, "File transfer started", job.targetName, 5)
            if (!container.storage.hasAccess(job.sourceFolderUri)) throw IllegalStateException("Source folder access was revoked. Re-authorize the folder in Settings.")
            if (!container.storage.hasAccess(job.destinationFolderUri)) throw IllegalStateException("Destination folder access was revoked. Re-authorize the folder in Settings.")
            val destNames = container.storage.list(job.destinationFolderUri).map { it.name }.toSet()
            val requestedName = if (job.targetName.isBlank()) container.storage.label(job.sourceUri).substringAfterLast('/') else job.targetName
            val finalName = if (requestedName in destNames) com.bijoyism.filenavigator.domain.Names.unique(requestedName) { it in destNames } else requestedName
            val notificationsEnabled = container.data.settings.first().notifications
            var lastProgress = -1
            val resultUri = when (job.kind.uppercase()) {
                "MOVE" -> container.storage.moveWithProgress(job.sourceUri, job.sourceFolderUri, job.destinationFolderUri, finalName, { copied, total ->
                    val percent = if (total > 0) (10 + (80.0 * copied / total).toInt()).coerceIn(10, 90) else 50
                    if (percent != lastProgress) {
                        lastProgress = percent
                        features.updateQueueJob(id) { it.copy(progress = percent) }
                        if (notificationsEnabled && percent % 20 == 10) TransferNotifier.show(applicationContext, id, "Moving file", "$finalName · $percent%", percent)
                    }
                }, isCancelled = { TransferCancellationRegistry.isCancelled(attemptId) })
                else -> container.storage.copyWithProgress(job.sourceUri, job.destinationFolderUri, finalName, { copied, total ->
                    val percent = if (total > 0) (10 + (80.0 * copied / total).toInt()).coerceIn(10, 90) else 50
                    if (percent != lastProgress) {
                        lastProgress = percent
                        features.updateQueueJob(id) { it.copy(progress = percent) }
                        if (notificationsEnabled && percent % 20 == 10) TransferNotifier.show(applicationContext, id, "Copying file", "$finalName · $percent%", percent)
                    }
                }, isCancelled = { TransferCancellationRegistry.isCancelled(attemptId) })
            }
            // A move commits only after its source is removed; never delete the destination
            // after that commit. Copy jobs can still be safely discarded on a late cancel.
            if (TransferCancellationRegistry.isCancelled(attemptId) && job.kind.uppercase() != "MOVE") {
                runCatching { container.storage.delete(resultUri) }
                throw TransferCancelledException()
            }
            features.updateQueueJob(id) { it.copy(progress = 95) }
            if (job.verify && job.kind.uppercase() != "MOVE") {
                val sourceHash = container.storage.sha256(job.sourceUri)
                val resultHash = container.storage.sha256(resultUri)
                if (sourceHash != resultHash) {
                    runCatching { container.storage.delete(resultUri) }
                    throw IllegalStateException("Integrity check failed; incomplete copy was removed.")
                }
            }
            if (TransferCancellationRegistry.isCancelled(attemptId) && job.kind.uppercase() != "MOVE") {
                runCatching { container.storage.delete(resultUri) }
                throw TransferCancelledException()
            }
            container.data.add(com.bijoyism.filenavigator.domain.HistoryEntry(
                type = job.kind.uppercase(), name = finalName, from = container.storage.label(job.sourceFolderUri),
                to = container.storage.label(job.destinationFolderUri), success = true,
                srcFolderUri = if (job.kind.uppercase() == "MOVE") job.sourceFolderUri else null,
                destFolderUri = job.destinationFolderUri, resultUri = resultUri
            ))
            features.updateQueueJob(id) { it.copy(status = "DONE", progress = 100, error = null) }
            if (container.data.settings.first().notifications) TransferNotifier.show(applicationContext, id, "File transfer complete", job.targetName, 100, finished = true)
            Result.success()
        } catch (e: TransferCancelledException) {
            features.updateQueueJob(id) { it.copy(status = "CANCELLED", error = "Cancelled by user.") }
            if (container.data.settings.first().notifications) TransferNotifier.show(applicationContext, id, "File transfer cancelled", job.targetName, finished = true)
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            features.updateQueueJob(id) { it.copy(status = "CANCELLED", error = "Transfer interrupted by Android.") }
            throw e
        } catch (e: Exception) {
            features.updateQueueJob(id) { it.copy(status = "FAILED", error = e.message ?: e.javaClass.simpleName) }
            if (container.data.settings.first().notifications) TransferNotifier.show(applicationContext, id, "File transfer failed", e.message ?: job.targetName, finished = true)
            container.data.add(com.bijoyism.filenavigator.domain.HistoryEntry(type = job.kind, name = job.targetName, from = container.storage.label(job.sourceFolderUri), to = container.storage.label(job.destinationFolderUri), success = false, error = e.message))
            Result.failure()
        } finally {
            TransferCancellationRegistry.clear(attemptId)
        }
    }

    companion object {
        const val KEY_JOB_ID = "queue_job_id"
        const val KEY_ATTEMPT_ID = "queue_attempt_id"
    }
}

/** Cooperative user cancellation for streaming loops; each WorkRequest has its own attempt token. */
private object TransferCancellationRegistry {
    private val flags = ConcurrentHashMap<String, AtomicBoolean>()
    fun start(attemptId: String) { flags.putIfAbsent(attemptId, AtomicBoolean(false)) }
    fun cancel(attemptId: String) { flags.computeIfAbsent(attemptId) { AtomicBoolean(false) }.set(true) }
    fun isCancelled(attemptId: String): Boolean = flags[attemptId]?.get() == true
    fun clear(attemptId: String) { flags.remove(attemptId) }
}
