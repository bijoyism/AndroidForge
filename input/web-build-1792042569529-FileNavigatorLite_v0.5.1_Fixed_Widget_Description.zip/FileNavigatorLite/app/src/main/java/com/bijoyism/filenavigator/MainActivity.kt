package com.bijoyism.filenavigator

import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.bijoyism.filenavigator.navigation.Destination
import com.bijoyism.filenavigator.data.AppData
import com.bijoyism.filenavigator.data.FeatureData
import com.bijoyism.filenavigator.data.FeaturePrefs
import com.bijoyism.filenavigator.security.PinSecurity
import com.bijoyism.filenavigator.ui.AppScaffold
import com.bijoyism.filenavigator.ui.theme.FileNavigatorTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private var requested by mutableStateOf<Destination?>(null)
    private var pinHash by mutableStateOf<String?>(null)
    private var prefsLoaded by mutableStateOf(false)
    private var unlocked by mutableStateOf(false)
    private var idleLockMinutes by mutableStateOf(5)
    private var pausedAt: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requested = parse(intent)
        installDynamicShortcuts()
        val data = AppData.create(this)
        val featureData = FeatureData(this)
        lifecycleScope.launch {
            val initial = featureData.prefs.first()
            pinHash = initial.privacyPinHash
            idleLockMinutes = initial.idleLockMinutes
            unlocked = initial.privacyPinHash == null
            prefsLoaded = true
            featureData.prefs.collect { prefs ->
                pinHash = prefs.privacyPinHash
                idleLockMinutes = prefs.idleLockMinutes
            }
        }
        setContent {
            val settings by data.settings.collectAsState(initial = com.bijoyism.filenavigator.data.AppSettings())
            val featurePrefs by featureData.prefs.collectAsState(initial = FeaturePrefs())
            FileNavigatorTheme(themeMode = settings.themeMode, colorTheme = settings.colorTheme, accentColor = featurePrefs.accentColor) {
                when {
                    !prefsLoaded -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    pinHash != null && !unlocked -> PinGate(onUnlock = { entered ->
                        if (PinSecurity.verify(entered, pinHash)) { unlocked = true; true } else false
                    })
                    else -> AppScaffold(requested = requested, onRequestHandled = { requested = null }, reducedMotion = featurePrefs.reducedMotion)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (prefsLoaded && pinHash != null && pausedAt > 0L && System.currentTimeMillis() - pausedAt >= idleLockMinutes * 60_000L) {
            unlocked = false
        }
        pausedAt = 0L
    }

    override fun onPause() {
        if (prefsLoaded && pinHash != null) pausedAt = System.currentTimeMillis()
        super.onPause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        requested = parse(intent)
    }

    private fun parse(intent: Intent?): Destination? = Destination.entries.firstOrNull { it.name == intent?.getStringExtra(EXTRA_OPEN) }

    private fun installDynamicShortcuts() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N_MR1) return
        runCatching {
            val manager = getSystemService(ShortcutManager::class.java) ?: return
            manager.dynamicShortcuts = listOf(
                ShortcutInfo.Builder(this, "file-navigator-files")
                    .setShortLabel("Browse files")
                    .setLongLabel("Browse files in File Navigator Lite")
                    .setIcon(Icon.createWithResource(this, R.mipmap.ic_launcher))
                    .setIntent(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_VIEW).putExtra(EXTRA_OPEN, Destination.Files.name))
                    .build(),
                ShortcutInfo.Builder(this, "file-navigator-storage")
                    .setShortLabel("Storage tools")
                    .setLongLabel("Analyze storage in File Navigator Lite")
                    .setIcon(Icon.createWithResource(this, R.mipmap.ic_launcher))
                    .setIntent(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_VIEW).putExtra(EXTRA_OPEN, Destination.Storage.name))
                    .build()
            )
        }
    }

    companion object { const val EXTRA_OPEN = "open" }
}

@androidx.compose.runtime.Composable
private fun PinGate(onUnlock: (String) -> Boolean) {
    var pin by androidx.compose.runtime.remember { mutableStateOf("") }
    var error by androidx.compose.runtime.remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("File Navigator is locked", style = MaterialTheme.typography.headlineMedium)
        Text("Enter your app PIN to continue.", modifier = Modifier.padding(top = 8.dp, bottom = 16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(value = pin, onValueChange = { pin = it.filter(Char::isDigit).take(8); error = null }, label = { Text("4–8 digit PIN") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
        Button(onClick = { if (pin.length in 4..8 && onUnlock(pin)) error = null else error = "Incorrect PIN. Try again." }, modifier = Modifier.padding(top = 16.dp)) { Text("Unlock") }
        TextButton(onClick = { pin = "" }) { Text("Clear") }
    }
}
