package com.bijoyism.filenavigator.history

import com.bijoyism.filenavigator.domain.HistoryEntry

fun HistoryEntry.route(): String = if (to.isEmpty()) from else "$from → $to"

fun HistoryEntry.canUndo(): Boolean = type in setOf("MOVE", "TRASH") && success && !undone && srcFolderUri != null && resultUri != null
