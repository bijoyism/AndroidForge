package com.bijoyism.filenavigator.preview

import android.graphics.Bitmap
import android.util.LruCache

/** Bounded in-memory thumbnail cache. It never writes file contents to disk. */
object ThumbnailCache {
    @Volatile private var configuredKb: Int = 8 * 1024
    @Volatile private var cacheEnabled: Boolean = true
    @Volatile private var cache: LruCache<String, Bitmap> = newCache(configuredKb)

    @Synchronized
    fun configure(limitMb: Int, lowMemory: Boolean) {
        val safeMb = if (lowMemory) limitMb.coerceIn(0, 8) else limitMb.coerceIn(0, 128)
        val newKb = (safeMb * 1024).coerceAtLeast(1)
        val enabled = safeMb > 0
        if (newKb != configuredKb || enabled != cacheEnabled) {
            cache.evictAll()
            cache = newCache(newKb)
            configuredKb = newKb
            cacheEnabled = enabled
        }
    }

    fun get(uri: String): Bitmap? = if (cacheEnabled) cache.get(uri) else null
    fun put(uri: String, bitmap: Bitmap) { if (cacheEnabled) cache.put(uri, bitmap) }
    fun clear() { cache.evictAll() }

    private fun newCache(maxKb: Int): LruCache<String, Bitmap> = object : LruCache<String, Bitmap>(maxKb) {
        override fun sizeOf(key: String, value: Bitmap): Int = (value.allocationByteCount / 1024).coerceAtLeast(1)
    }
}
