package com.bijoyism.filenavigator.notifications

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.bijoyism.filenavigator.FileNavigatorApp
import com.bijoyism.filenavigator.MainActivity
import com.bijoyism.filenavigator.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class Notifier(private val context: Context) {

    @SuppressLint("MissingPermission")
    fun notifyNewFiles(count: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        val channel = NotificationChannel(CHANNEL_ID, "File organization", NotificationManager.IMPORTANCE_LOW)
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java).putExtra(MainActivity.EXTRA_OPEN, "Automation").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            flags
        )
        val organize = broadcast(1, ACTION_ORGANIZE, flags)
        val dismiss = broadcast(2, ACTION_DISMISS, flags)

        val text = if (count == 1) "1 new file matches your rules" else "$count new files match your rules"
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("File Navigator Lite")
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(0, "Organize now", organize)
            .addAction(0, "Review", open)
            .addAction(0, "Dismiss", dismiss)
            .build()
        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
    }

    @SuppressLint("MissingPermission")
    fun notifyOrganizationSummary(moved: Int, skipped: Int, failed: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        if (moved + skipped + failed == 0) return
        runCatching {
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "File organization", NotificationManager.IMPORTANCE_LOW)
            )
            val open = PendingIntent.getActivity(
                context, 4,
                Intent(context, MainActivity::class.java).putExtra(MainActivity.EXTRA_OPEN, "Activity")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val details = buildList {
                if (moved > 0) add("$moved moved")
                if (skipped > 0) add("$skipped skipped")
                if (failed > 0) add("$failed failed")
            }.joinToString(" · ")
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("File organization complete")
                .setContentText(details)
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID + 1, notification)
        }
    }

    private fun broadcast(code: Int, action: String, flags: Int): PendingIntent =
        PendingIntent.getBroadcast(context, code, Intent(context, NotificationActionReceiver::class.java).setAction(action), flags)

    companion object {
        const val CHANNEL_ID = "organize"
        const val NOTIFICATION_ID = 1001
        const val ACTION_ORGANIZE = "com.bijoyism.filenavigator.ORGANIZE"
        const val ACTION_DISMISS = "com.bijoyism.filenavigator.DISMISS"
    }
}

class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        context.getSystemService(NotificationManager::class.java).cancel(Notifier.NOTIFICATION_ID)
        if (intent.action != Notifier.ACTION_ORGANIZE) return
        val pending = goAsync()
        val container = (context.applicationContext as FileNavigatorApp).container
        CoroutineScope(Dispatchers.IO).launch {
            try {
                container.automation.organizeNow()
            } catch (e: Exception) {
                Log.w("FileNavigator", "Organize from notification failed", e)
            } finally {
                pending.finish()
            }
        }
    }
}

/** Safe, best-effort notifications for background transfers. Hidden if the user denied notifications. */
object TransferNotifier {
    private const val CHANNEL_ID = "file_transfers"

    @android.annotation.SuppressLint("MissingPermission")
    fun show(context: Context, id: String, title: String, message: String, progress: Int? = null, finished: Boolean = false) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        runCatching {
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "File transfers", NotificationManager.IMPORTANCE_LOW)
            )
            val open = PendingIntent.getActivity(
                context, id.hashCode(), Intent(context, MainActivity::class.java)
                    .putExtra(MainActivity.EXTRA_OPEN, "Storage")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(message)
                .setContentIntent(open)
                .setOnlyAlertOnce(true)
                .setAutoCancel(finished)
            if (progress != null && !finished) builder.setProgress(100, progress.coerceIn(0, 100), false).setOngoing(true)
            else builder.setProgress(0, 0, false).setOngoing(false)
            NotificationManagerCompat.from(context).notify(2_000 + (id.hashCode() and 0x3fff), builder.build())
        }
    }
}
