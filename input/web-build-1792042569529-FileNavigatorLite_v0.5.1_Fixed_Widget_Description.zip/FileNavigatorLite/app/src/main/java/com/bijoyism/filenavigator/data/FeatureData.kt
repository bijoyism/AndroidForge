package com.bijoyism.filenavigator.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.bijoyism.filenavigator.domain.ConflictPolicy
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private val Context.featurePrefsStore by preferencesDataStore(name = "file_navigator_feature_store")

data class SmartFolder(val id: String = UUID.randomUUID().toString(), val name: String, val query: String = "", val extension: String = "", val mimePrefix: String = "")
data class TransferJob(
    val id: String = UUID.randomUUID().toString(),
    val kind: String = "COPY",
    val sourceUri: String,
    val sourceFolderUri: String,
    val destinationFolderUri: String,
    val targetName: String,
    val verify: Boolean = true,
    val status: String = "QUEUED",
    val progress: Int = 0,
    val error: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val workId: String? = null
)

data class FeaturePrefs(
    val favorites: Set<String> = emptySet(),
    val bookmarks: Set<String> = emptySet(),
    val recentUris: List<String> = emptyList(),
    val hiddenFiles: Boolean = false,
    val compactMode: Boolean = false,
    val reducedMotion: Boolean = false,
    val haptics: Boolean = true,
    val lowMemoryMode: Boolean = false,
    val cacheLimitMb: Int = 32,
    val accentColor: String = "system",
    val idleLockMinutes: Int = 5,
    val scanExclusions: Set<String> = emptySet(),
    val tags: Map<String, List<String>> = emptyMap(),
    val collections: Map<String, List<String>> = emptyMap(),
    val smartFolders: List<SmartFolder> = emptyList(),
    val privacyPinHash: String? = null,
    val vaultEnabled: Boolean = false,
    val backupScheduleHours: Int = 0,
    val timeWindowEnabled: Boolean = false,
    val timeWindowStartHour: Int = 0,
    val timeWindowEndHour: Int = 23,
    val batteryNotLow: Boolean = false,
    val networkPolicy: String = "any",
    val maxConcurrentTransfers: Int = 1,
    val showHiddenInBrowser: Boolean = false,
    val homeCards: List<String> = listOf("automation", "storage", "tools", "activity"),
    val quickActions: List<String> = listOf("files", "automation", "storage"),
    val navigationOrder: List<String> = listOf("Home", "Files", "Automation", "Activity", "Storage", "Settings")
)

/** Locally persisted extras. Stores metadata only; file contents are not stored here. */
class FeatureData(private val context: Context) {
    private val store = context.applicationContext.featurePrefsStore
    private val prefsKey = stringPreferencesKey("feature_prefs_v1")
    private val queueKey = stringPreferencesKey("transfer_queue_v1")

    val prefs: Flow<FeaturePrefs> = store.data.map { decodePrefs(it[prefsKey] ?: "{}") }
    val queue: Flow<List<TransferJob>> = store.data.map { decodeQueue(it[queueKey] ?: "[]") }

    suspend fun currentPrefs(): FeaturePrefs = prefs.first()

    /** JSON payload used by versioned settings backups; contains preferences only, never file contents or vault keys. */
    suspend fun exportPrefsJson(): String = encodePrefs(prefs.first().copy(privacyPinHash = null))

    suspend fun importPrefsJson(raw: String) {
        val decoded = decodePrefs(raw)
        // Reject malformed/empty payloads rather than silently resetting the user's preferences.
        val parsed = JSONObject(raw)
        require(parsed.has("favorites") || parsed.has("accentColor") || parsed.has("smartFolders")) { "Feature settings backup is incomplete." }
        store.edit { p -> p[prefsKey] = encodePrefs(decoded.copy(privacyPinHash = null)) }
    }

    suspend fun updatePrefs(transform: (FeaturePrefs) -> FeaturePrefs) {
        store.edit { p -> p[prefsKey] = encodePrefs(transform(decodePrefs(p[prefsKey] ?: "{}"))) }
    }

    suspend fun toggleFavorite(uri: String) = updatePrefs { p -> p.copy(favorites = if (uri in p.favorites) p.favorites - uri else p.favorites + uri) }
    suspend fun toggleBookmark(uri: String) = updatePrefs { p -> p.copy(bookmarks = if (uri in p.bookmarks) p.bookmarks - uri else p.bookmarks + uri) }
    suspend fun recordRecent(uri: String) = updatePrefs { p -> p.copy(recentUris = (listOf(uri) + p.recentUris.filterNot { it == uri }).take(100)) }
    suspend fun addQueueJob(job: TransferJob) { store.edit { p -> p[queueKey] = encodeQueue((decodeQueue(p[queueKey] ?: "[]") + job).takeLast(500)) } }
    suspend fun queueJob(id: String): TransferJob? = queue.first().firstOrNull { it.id == id }
    suspend fun updateQueueJob(id: String, transform: (TransferJob) -> TransferJob) {
        store.edit { p -> p[queueKey] = encodeQueue(decodeQueue(p[queueKey] ?: "[]").map { if (it.id == id) transform(it).copy(updatedAt = System.currentTimeMillis()) else it }) }
    }
    suspend fun removeQueueJob(id: String) { store.edit { p -> p[queueKey] = encodeQueue(decodeQueue(p[queueKey] ?: "[]").filterNot { it.id == id }) } }
    suspend fun clearFinishedQueue() { store.edit { p -> p[queueKey] = encodeQueue(decodeQueue(p[queueKey] ?: "[]").filter { it.status in setOf("QUEUED", "RUNNING", "PAUSED") }) } }

    private fun encodePrefs(p: FeaturePrefs): String = JSONObject().apply {
        put("favorites", JSONArray(p.favorites.toList())); put("bookmarks", JSONArray(p.bookmarks.toList())); put("recent", JSONArray(p.recentUris))
        put("hiddenFiles", p.hiddenFiles); put("compactMode", p.compactMode); put("reducedMotion", p.reducedMotion); put("haptics", p.haptics)
        put("lowMemoryMode", p.lowMemoryMode); put("cacheLimitMb", p.cacheLimitMb); put("accentColor", p.accentColor); put("idleLockMinutes", p.idleLockMinutes)
        put("scanExclusions", JSONArray(p.scanExclusions.toList())); put("tags", mapToJson(p.tags)); put("collections", mapToJson(p.collections))
        put("smartFolders", JSONArray().apply { p.smartFolders.forEach { f -> put(JSONObject().put("id", f.id).put("name", f.name).put("query", f.query).put("extension", f.extension).put("mimePrefix", f.mimePrefix)) } })
        p.privacyPinHash?.let { put("pinHash", it) }; put("vaultEnabled", p.vaultEnabled); put("backupScheduleHours", p.backupScheduleHours)
        put("timeWindowEnabled", p.timeWindowEnabled); put("timeWindowStartHour", p.timeWindowStartHour); put("timeWindowEndHour", p.timeWindowEndHour)
        put("batteryNotLow", p.batteryNotLow); put("networkPolicy", p.networkPolicy); put("maxConcurrentTransfers", p.maxConcurrentTransfers)
        put("showHiddenInBrowser", p.showHiddenInBrowser); put("homeCards", JSONArray(p.homeCards)); put("quickActions", JSONArray(p.quickActions)); put("navigationOrder", JSONArray(p.navigationOrder))
    }.toString()

    private fun decodePrefs(raw: String): FeaturePrefs = runCatching {
        val o = JSONObject(raw)
        fun strings(k: String) = (o.optJSONArray(k) ?: JSONArray()).let { a -> (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotEmpty) } }
        fun stringMap(k: String): Map<String, List<String>> {
            val value = o.optJSONObject(k) ?: JSONObject()
            return value.keys().asSequence().associateWith { key -> stringsFrom(value.optJSONArray(key)) }
        }
        val fs = o.optJSONArray("smartFolders") ?: JSONArray()
        FeaturePrefs(
            favorites = strings("favorites").toSet(), bookmarks = strings("bookmarks").toSet(), recentUris = strings("recent"),
            hiddenFiles = o.optBoolean("hiddenFiles", false), compactMode = o.optBoolean("compactMode", false), reducedMotion = o.optBoolean("reducedMotion", false), haptics = o.optBoolean("haptics", true),
            lowMemoryMode = o.optBoolean("lowMemoryMode", false), cacheLimitMb = o.optInt("cacheLimitMb", 32).coerceIn(0, 256), accentColor = o.optString("accentColor", "system"), idleLockMinutes = o.optInt("idleLockMinutes", 5).coerceIn(1, 60),
            scanExclusions = strings("scanExclusions").toSet(), tags = stringMap("tags"), collections = stringMap("collections"),
            smartFolders = (0 until fs.length()).mapNotNull { i -> fs.optJSONObject(i)?.let { SmartFolder(it.optString("id", UUID.randomUUID().toString()), it.optString("name", "Smart folder"), it.optString("query"), it.optString("extension"), it.optString("mimePrefix")) } },
            privacyPinHash = o.optString("pinHash").takeIf { it.isNotBlank() }, vaultEnabled = o.optBoolean("vaultEnabled", false), backupScheduleHours = o.optInt("backupScheduleHours", 0).coerceIn(0, 168),
            timeWindowEnabled = o.optBoolean("timeWindowEnabled", false), timeWindowStartHour = o.optInt("timeWindowStartHour", 0).coerceIn(0, 23), timeWindowEndHour = o.optInt("timeWindowEndHour", 23).coerceIn(0, 23),
            batteryNotLow = o.optBoolean("batteryNotLow", false), networkPolicy = o.optString("networkPolicy", "any").takeIf { it in setOf("any", "unmetered", "connected") } ?: "any", maxConcurrentTransfers = o.optInt("maxConcurrentTransfers", 1).coerceIn(1, 3),
            showHiddenInBrowser = o.optBoolean("showHiddenInBrowser", false), homeCards = if (o.has("homeCards")) strings("homeCards").filter { it in setOf("automation", "storage", "tools", "activity") } else FeaturePrefs().homeCards, quickActions = if (o.has("quickActions")) strings("quickActions").filter { it in setOf("files", "automation", "storage") } else FeaturePrefs().quickActions, navigationOrder = strings("navigationOrder").ifEmpty { FeaturePrefs().navigationOrder }
        )
    }.getOrDefault(FeaturePrefs())

    private fun mapToJson(map: Map<String, List<String>>) = JSONObject().apply { map.forEach { (k, v) -> put(k, JSONArray(v)) } }
    private fun stringsFrom(a: JSONArray?): List<String> = a?.let { (0 until it.length()).mapNotNull { i -> it.optString(i).takeIf(String::isNotEmpty) } } ?: emptyList()

    private fun encodeQueue(jobs: List<TransferJob>): String = JSONArray().apply { jobs.forEach { j -> put(JSONObject().apply {
        put("id", j.id); put("kind", j.kind); put("sourceUri", j.sourceUri); put("sourceFolderUri", j.sourceFolderUri); put("destinationFolderUri", j.destinationFolderUri); put("targetName", j.targetName)
        put("verify", j.verify); put("status", j.status); put("progress", j.progress); j.error?.let { put("error", it) }; put("createdAt", j.createdAt); put("updatedAt", j.updatedAt); j.workId?.let { put("workId", it) }
    }) } }.toString()
    private fun decodeQueue(raw: String): List<TransferJob> = runCatching {
        val a = JSONArray(raw); (0 until a.length()).map { i -> val o = a.getJSONObject(i); TransferJob(
            id = o.optString("id", UUID.randomUUID().toString()), kind = o.optString("kind", "COPY"), sourceUri = o.optString("sourceUri"), sourceFolderUri = o.optString("sourceFolderUri"), destinationFolderUri = o.optString("destinationFolderUri"), targetName = o.optString("targetName"),
            verify = o.optBoolean("verify", true), status = o.optString("status", "QUEUED"), progress = o.optInt("progress", 0).coerceIn(0, 100), error = o.optString("error").takeIf(String::isNotBlank), createdAt = o.optLong("createdAt", System.currentTimeMillis()), updatedAt = o.optLong("updatedAt", System.currentTimeMillis()), workId = o.optString("workId").takeIf(String::isNotBlank)
        ) }
    }.getOrDefault(emptyList())
}
