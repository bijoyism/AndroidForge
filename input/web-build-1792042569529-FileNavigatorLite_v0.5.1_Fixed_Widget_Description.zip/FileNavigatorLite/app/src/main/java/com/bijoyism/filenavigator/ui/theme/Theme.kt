package com.bijoyism.filenavigator.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp), small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(24.dp), large = RoundedCornerShape(30.dp), extraLarge = RoundedCornerShape(36.dp)
)

private fun lightPalette(name: String) = when (name) {
    "green" -> lightColorScheme(primary = Color(0xFF386A20), onPrimary = Color.White, primaryContainer = Color(0xFFB8F397), onPrimaryContainer = Color(0xFF082100), secondary = Color(0xFF56624A), tertiary = Color(0xFF386667), surface = Color(0xFFF8FAF0))
    "purple" -> lightColorScheme(primary = Color(0xFF6750A4), onPrimary = Color.White, primaryContainer = Color(0xFFEADDFF), onPrimaryContainer = Color(0xFF21005D), secondary = Color(0xFF625B71), tertiary = Color(0xFF7D5260), surface = Color(0xFFFFF7FF))
    "orange" -> lightColorScheme(primary = Color(0xFF8B5000), onPrimary = Color.White, primaryContainer = Color(0xFFFFDDB3), onPrimaryContainer = Color(0xFF2C1600), secondary = Color(0xFF705A42), tertiary = Color(0xFF805457), surface = Color(0xFFFFF8F3))
    else -> lightColorScheme(primary = Color(0xFF385DA8), onPrimary = Color.White, primaryContainer = Color(0xFFD9E2FF), onPrimaryContainer = Color(0xFF001847), secondary = Color(0xFF575E71), tertiary = Color(0xFF715573), surface = Color(0xFFFAF9FF))
}

private fun darkPalette(name: String) = when (name) {
    "amoled" -> darkColorScheme(
        primary = Color(0xFFB1C5FF), onPrimary = Color(0xFF082E70),
        primaryContainer = Color(0xFF204487), secondary = Color(0xFFBFC6DC),
        tertiary = Color(0xFFDFBCE0), surface = Color.Black, background = Color.Black,
        surfaceVariant = Color(0xFF171717)
    )
    "green" -> darkColorScheme(primary = Color(0xFF9CD67B), onPrimary = Color(0xFF173800), primaryContainer = Color(0xFF28500B), secondary = Color(0xFFBECBB0), tertiary = Color(0xFFA0D0D0), surface = Color(0xFF11140F))
    "purple" -> darkColorScheme(primary = Color(0xFFD0BCFF), onPrimary = Color(0xFF381E72), primaryContainer = Color(0xFF4F378B), secondary = Color(0xFFCCC2DC), tertiary = Color(0xFFEFB8C8), surface = Color(0xFF141218))
    "orange" -> darkColorScheme(primary = Color(0xFFFFB95F), onPrimary = Color(0xFF482900), primaryContainer = Color(0xFF673D00), secondary = Color(0xFFE3C3A2), tertiary = Color(0xFFFFB4AB), surface = Color(0xFF17120D))
    else -> darkColorScheme(primary = Color(0xFFB1C5FF), onPrimary = Color(0xFF082E70), primaryContainer = Color(0xFF204487), secondary = Color(0xFFBFC6DC), tertiary = Color(0xFFDFBCE0), surface = Color(0xFF111318))
}

@Composable
fun FileNavigatorTheme(
    themeMode: String = "system",
    colorTheme: String = "dynamic",
    accentColor: String = "system",
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val dark = when (themeMode) { "light" -> false; "dark" -> true; else -> isSystemInDarkTheme() }
    val palette = if (accentColor in setOf("blue", "green", "purple", "orange", "amoled")) accentColor else colorTheme
    val colors = when {
        palette == "dynamic" && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && dark -> dynamicDarkColorScheme(context)
        palette == "dynamic" && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> dynamicLightColorScheme(context)
        dark -> darkPalette(palette)
        else -> lightPalette(palette)
    }
    MaterialTheme(colorScheme = colors, typography = MaterialTheme.typography, shapes = AppShapes, content = content)
}
