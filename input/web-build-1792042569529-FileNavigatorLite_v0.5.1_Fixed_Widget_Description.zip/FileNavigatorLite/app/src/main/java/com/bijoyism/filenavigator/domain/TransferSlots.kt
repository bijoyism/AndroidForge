package com.bijoyism.filenavigator.domain

/** Stable slot assignment lets WorkManager serialize each lane while allowing bounded parallel lanes. */
object TransferSlots {
    fun slotFor(jobId: String, slotCount: Int): Int {
        require(slotCount in 1..3) { "Transfer slots must be between 1 and 3." }
        return (jobId.hashCode() and Int.MAX_VALUE) % slotCount
    }
}
