package com.bijoyism.filenavigator.domain

/** Extra, composable filters for the file list. Empty values mean "no restriction". */
data class FileQuery(
    val text: String = "",
    val extension: String = "",
    val mimePrefix: String = "",
    val minBytes: Long? = null,
    val maxBytes: Long? = null,
    val modifiedAfterMillis: Long? = null,
    val modifiedBeforeMillis: Long? = null,
    val includeHidden: Boolean = false
) {
    fun matches(file: FileEntry): Boolean {
        if (!includeHidden && file.name.startsWith('.') ) return false
        if (text.isNotBlank() && !file.name.contains(text.trim(), ignoreCase = true)) return false
        val ext = extension.trim().trimStart('.').lowercase()
        if (ext.isNotEmpty() && file.name.substringAfterLast('.', "").lowercase() != ext) return false
        val mime = mimePrefix.trim()
        if (mime.isNotEmpty() && !file.mimeType.orEmpty().startsWith(mime, ignoreCase = true)) return false
        if (minBytes != null && (file.size < 0 || file.size < minBytes)) return false
        if (maxBytes != null && (file.size < 0 || file.size > maxBytes)) return false
        if (modifiedAfterMillis != null && file.lastModified < modifiedAfterMillis) return false
        if (modifiedBeforeMillis != null && file.lastModified > modifiedBeforeMillis) return false
        return true
    }
}

/** Pure batch rename planner. Callers must still check collisions in the destination. */
object BatchRenamePlanner {
    fun numbered(names: List<String>, prefix: String = "", start: Int = 1, width: Int = 3, suffix: String = ""): List<Pair<String, String>> {
        require(start >= 0) { "Start number must be non-negative" }
        require(width in 1..8) { "Number width must be between 1 and 8" }
        require(prefix.none { it == '/' || it == '\\' } && suffix.none { it == '/' || it == '\\' }) { "Prefix and suffix cannot contain path separators" }
        return names.mapIndexed { index, oldName ->
            val dot = oldName.lastIndexOf('.')
            val base = if (dot > 0) oldName.substring(0, dot) else oldName
            val ext = if (dot > 0) oldName.substring(dot) else ""
            oldName to "$prefix${(start + index).toString().padStart(width, '0')}_$base$suffix$ext"
        }
    }

    fun replace(names: List<String>, find: String, replacement: String): List<Pair<String, String>> {
        require(find.isNotEmpty()) { "Search text cannot be empty" }
        require(replacement.none { it == '/' || it == '\\' }) { "Replacement cannot contain path separators" }
        return names.map { it to it.replace(find, replacement, ignoreCase = false) }
    }
}
