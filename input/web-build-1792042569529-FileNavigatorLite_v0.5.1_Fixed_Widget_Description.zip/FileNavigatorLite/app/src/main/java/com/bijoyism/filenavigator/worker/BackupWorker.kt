package com.bijoyism.filenavigator.worker

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.bijoyism.filenavigator.FileNavigatorApp
import kotlinx.coroutines.flow.first
import java.io.File
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class BackupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val container = (applicationContext as FileNavigatorApp).container
        val root = JSONObject(container.data.exportBackup())
        root.put("version", 2)
        root.put("featurePrefs", JSONObject(container.features.exportPrefsJson()))
        val json = root.toString(2)
        val folder = File(applicationContext.filesDir, "scheduled_backups").apply { mkdirs() }
        val target = File(folder, "file-navigator-${System.currentTimeMillis()}.json")
        target.writeText(json, Charsets.UTF_8)
        folder.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }?.drop(7)?.forEach { it.delete() }
        Result.success()
    } catch (e: Exception) {
        Log.w("FileNavigator", "Scheduled settings backup failed", e)
        Result.retry()
    }
}

object BackupScheduler {
    private const val UNIQUE_NAME = "file_navigator_scheduled_backups"
    fun configure(context: Context, intervalHours: Int) {
        if (intervalHours <= 0) {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_NAME)
            return
        }
        val hours = intervalHours.coerceIn(24, 168)
        val request = PeriodicWorkRequestBuilder<BackupWorker>(hours.toLong(), TimeUnit.HOURS).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(UNIQUE_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
    }
}
