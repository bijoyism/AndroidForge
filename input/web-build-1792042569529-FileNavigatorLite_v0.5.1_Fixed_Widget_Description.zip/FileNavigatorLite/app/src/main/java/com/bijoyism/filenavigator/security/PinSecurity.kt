package com.bijoyism.filenavigator.security

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** PBKDF2-based local PIN verifier. The PIN is never stored in plaintext. */
object PinSecurity {
    private const val ITERATIONS = 120_000
    private const val KEY_BITS = 256

    fun hash(pin: String): String {
        require(pin.length in 4..8 && pin.all(Char::isDigit)) { "PIN must be 4–8 digits." }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val derived = derive(pin, salt)
        return "pbkdf2-sha256:$ITERATIONS:${Base64.getEncoder().encodeToString(salt)}:${Base64.getEncoder().encodeToString(derived)}"
    }

    fun verify(pin: String, encoded: String?): Boolean {
        if (encoded.isNullOrBlank()) return false
        return runCatching {
            val parts = encoded.split(':')
            require(parts.size == 4 && parts[0] == "pbkdf2-sha256")
            val iterations = parts[1].toInt().coerceIn(50_000, 500_000)
            val salt = Base64.getDecoder().decode(parts[2])
            val expected = Base64.getDecoder().decode(parts[3])
            MessageDigest.isEqual(expected, derive(pin, salt, iterations))
        }.getOrDefault(false)
    }

    private fun derive(pin: String, salt: ByteArray, iterations: Int = ITERATIONS): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, iterations, KEY_BITS)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }
}
