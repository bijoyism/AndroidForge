package com.bijoyism.filenavigator.preview

/** Lightweight preview routing; unsupported formats are delegated to Android apps. */
enum class PreviewType { IMAGE, TEXT, PDF, AUDIO, VIDEO, ARCHIVE, APK, EXTERNAL }

fun previewType(name: String, mimeType: String?): PreviewType {
    val nameLower = name.lowercase()
    val mime = mimeType.orEmpty().lowercase()
    return when {
        mime.startsWith("image/") || nameLower.endsWithAny(".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp") -> PreviewType.IMAGE
        mime.startsWith("text/") || nameLower.endsWithAny(".txt", ".md", ".csv", ".json", ".xml", ".log", ".kt", ".java", ".html", ".css", ".js") -> PreviewType.TEXT
        mime == "application/pdf" || nameLower.endsWith(".pdf") -> PreviewType.PDF
        mime.startsWith("audio/") || nameLower.endsWithAny(".mp3", ".m4a", ".wav", ".ogg", ".flac", ".aac") -> PreviewType.AUDIO
        mime.startsWith("video/") || nameLower.endsWithAny(".mp4", ".mkv", ".webm", ".3gp", ".mov") -> PreviewType.VIDEO
        nameLower.endsWithAny(".zip", ".jar", ".7z", ".rar", ".tar", ".gz") -> PreviewType.ARCHIVE
        nameLower.endsWith(".apk") -> PreviewType.APK
        else -> PreviewType.EXTERNAL
    }
}

private fun String.endsWithAny(vararg suffixes: String): Boolean = suffixes.any { endsWith(it) }
