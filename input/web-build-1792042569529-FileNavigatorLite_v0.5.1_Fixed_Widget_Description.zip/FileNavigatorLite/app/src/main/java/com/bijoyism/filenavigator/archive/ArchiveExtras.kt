package com.bijoyism.filenavigator.archive

import android.content.Context
import com.bijoyism.filenavigator.storage.SafStorage
import com.bijoyism.filenavigator.domain.FileEntry
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.AesKeyStrength
import net.lingala.zip4j.model.enums.CompressionMethod
import net.lingala.zip4j.model.enums.EncryptionMethod
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/** Streaming format helpers. Workspaces are temporary and are removed after each operation. */
class ArchiveExtras(private val context: Context, private val storage: SafStorage) {
    fun createEncryptedZip(sourceFolder: String, destinationFolder: String, archiveName: String, password: CharArray) {
        require(password.size >= 8) { "Use at least 8 characters for an encrypted archive password." }
        val workspace = File(context.cacheDir, "zip4j-${UUID.randomUUID()}").apply { mkdirs() }
        val stage = File(workspace, "source").apply { mkdirs() }
        val archive = File(workspace, "encrypted.zip")
        try {
            stageFolder(sourceFolder, stage, 0)
            val params = ZipParameters().apply {
                isEncryptFiles = true
                encryptionMethod = EncryptionMethod.AES
                aesKeyStrength = AesKeyStrength.KEY_STRENGTH_256
                compressionMethod = CompressionMethod.DEFLATE
            }
            ZipFile(archive, password).addFolder(stage, params)
            val target = storage.createFileDocument(destinationFolder, "application/zip", archiveName.removeSuffix(".zip") + ".zip")
            try {
                FileInputStream(archive).use { input -> storage.openOutputStream(target)?.use { input.copyTo(it, 64 * 1024) } ?: error("Cannot open output") }
            } catch (e: Exception) {
                runCatching { storage.delete(target) }
                throw e
            }
        } finally {
            password.fill('\u0000')
            workspace.deleteRecursively()
        }
    }

    fun extractEncryptedZip(archiveUri: String, destinationFolder: String, password: CharArray, selectedNames: Set<String> = emptySet()): Int {
        val workspace = File(context.cacheDir, "unzip4j-${UUID.randomUUID()}").apply { mkdirs() }
        val archive = File(workspace, "input.zip")
        val output = File(workspace, "out").apply { mkdirs() }
        try {
            storage.openInputStream(archiveUri)?.use { input -> FileOutputStream(archive).use { input.copyTo(it, 64 * 1024) } } ?: error("Cannot read archive")
            val zip = ZipFile(archive, password)
            val headers = zip.fileHeaders
            require(headers.size <= 10_000) { "Archive contains too many entries." }
            val totalDeclaredBytes = headers.sumOf { header -> header.uncompressedSize.coerceAtLeast(0L) }
            require(totalDeclaredBytes <= 2L * 1024 * 1024 * 1024) { "Archive expands beyond the 2 GiB safety limit." }
            var total = 0
            headers.forEach { header ->
                val name = header.fileName.replace('\\', '/')
                validatePath(name)
                if (selectedNames.isEmpty() || name in selectedNames) {
                    zip.extractFile(header, output.absolutePath)
                    total++
                }
            }
            copyStagedToStorage(output, destinationFolder, 0)
            return total
        } finally {
            password.fill('\u0000')
            workspace.deleteRecursively()
        }
    }

    fun createGzip(sourceUri: String, destFolder: String, outputName: String): String {
        val target = storage.createFileDocument(destFolder, "application/gzip", outputName.ifBlank { "archive.gz" }.removeSuffix(".gz") + ".gz")
        try {
            storage.openInputStream(sourceUri)?.use { input ->
                storage.openOutputStream(target)?.use { out -> GZIPOutputStream(BufferedOutputStream(out)).use { gzip -> input.copyTo(gzip, 64 * 1024) } }
                    ?: error("Cannot write GZIP output")
            } ?: error("Cannot read source file")
            return target
        } catch (e: Exception) { runCatching { storage.delete(target) }; throw e }
    }

    fun extractGzip(sourceUri: String, destFolder: String, outputName: String): String {
        val target = storage.createFileDocument(destFolder, "application/octet-stream", outputName.ifBlank { "extracted" })
        try {
            storage.openInputStream(sourceUri)?.use { input ->
                GZIPInputStream(BufferedInputStream(input)).use { gzip -> storage.openOutputStream(target)?.use { gzip.copyTo(it, 64 * 1024) } ?: error("Cannot write output") }
            } ?: error("Cannot read GZIP file")
            return target
        } catch (e: Exception) { runCatching { storage.delete(target) }; throw e }
    }

    fun splitFile(sourceUri: String, destinationFolder: String, baseName: String, partSizeMb: Int = 100): List<String> {
        val chunkSize = partSizeMb.coerceIn(1, 2048).toLong() * 1024 * 1024
        val created = mutableListOf<String>()
        try {
            storage.openInputStream(sourceUri)?.use { input ->
                val buffer = ByteArray(64 * 1024)
                var partNo = 1
                var currentBytes = 0L
                var target: String? = null
                var output: OutputStream? = null
                while (true) {
                    var n = input.read(buffer)
                    if (n < 0) break
                    var offset = 0
                    while (offset < n) {
                        if (output == null || currentBytes >= chunkSize) {
                            output?.close()
                            val name = "$baseName.part${partNo.toString().padStart(3, '0')}"
                            target = storage.createFileDocument(destinationFolder, "application/octet-stream", name)
                            created.add(target)
                            output = storage.openOutputStream(target) ?: error("Cannot create split part")
                            partNo++
                            currentBytes = 0
                        }
                        val count = minOf((chunkSize - currentBytes).toInt(), n - offset)
                        output!!.write(buffer, offset, count)
                        offset += count
                        currentBytes += count
                    }
                }
                output?.close()
            } ?: error("Cannot read source file")
            return created
        } catch (e: Exception) {
            created.forEach { runCatching { storage.delete(it) } }
            throw e
        }
    }

    fun joinParts(partUris: List<String>, destinationFolder: String, outputName: String): String {
        require(partUris.isNotEmpty()) { "Choose at least one split part." }
        val target = storage.createFileDocument(destinationFolder, "application/octet-stream", outputName.ifBlank { "joined.bin" })
        try {
            storage.openOutputStream(target)?.use { out ->
                partUris.forEach { uri -> storage.openInputStream(uri)?.use { it.copyTo(out, 64 * 1024) } ?: error("Cannot read a split part") }
            } ?: error("Cannot create joined output")
            return target
        } catch (e: Exception) { runCatching { storage.delete(target) }; throw e }
    }

    fun createTarGz(sourceFolder: String, destinationFolder: String, outputName: String) {
        val target = storage.createFileDocument(destinationFolder, "application/gzip", outputName.removeSuffix(".tar.gz").removeSuffix(".tgz") + ".tar.gz")
        try {
            storage.openOutputStream(target)?.use { raw -> GZIPOutputStream(BufferedOutputStream(raw)).use { gzip ->
                storage.list(sourceFolder).forEach { entry -> appendTarEntry(entry, entry.name, gzip, 0) }
                gzip.write(ByteArray(1024))
            } } ?: error("Cannot create TAR.GZ output")
        } catch (e: Exception) { runCatching { storage.delete(target) }; throw e }
    }

    fun extractTarGz(sourceUri: String, destinationFolder: String, limitEntries: Int = 10_000): Int {
        var count = 0
        var totalBytes = 0L
        storage.openInputStream(sourceUri)?.use { raw -> GZIPInputStream(BufferedInputStream(raw)).use { input ->
            while (true) {
                val header = ByteArray(512)
                if (!readExactly(input, header)) break
                if (header.all { it == 0.toByte() }) break
                if (++count > limitEntries) throw IllegalStateException("Archive entry limit exceeded")
                val name = readString(header, 0, 100)
                val prefix = readString(header, 345, 155)
                val fullName = if (prefix.isNotBlank()) "$prefix/$name" else name
                validatePath(fullName)
                val size = readOctal(header, 124, 12)
                totalBytes += size.coerceAtLeast(0L)
                if (totalBytes > 2L * 1024 * 1024 * 1024) throw IllegalStateException("Archive expands beyond the 2 GiB safety limit")
                val type = header[156].toInt().toChar()
                val parent = ensureParent(destinationFolder, fullName)
                val leaf = fullName.trimEnd('/').substringAfterLast('/')
                if (type == '5' || fullName.endsWith('/')) {
                    if (storage.list(parent).none { it.name == leaf && it.isDirectory }) storage.createFolder(parent, leaf)
                    skipExactly(input, roundBlock(size))
                } else {
                    if (storage.list(parent).any { it.name == leaf }) throw IllegalStateException("Extraction stopped: $leaf already exists")
                    val target = storage.createFileDocument(parent, "application/octet-stream", leaf)
                    try {
                        storage.openOutputStream(target)?.use { out -> copyExactly(input, out, size) } ?: error("Cannot write $leaf")
                        skipExactly(input, roundBlock(size) - size)
                        // count tracks all entries, including directories.
                    } catch (e: Exception) { runCatching { storage.delete(target) }; throw e }
                }
            }
        } } ?: error("Cannot read TAR.GZ file")
        return count
    }

    private fun stageFolder(uri: String, target: File, depth: Int) {
        require(depth <= 30) { "Folder nesting too deep" }
        storage.list(uri).forEach { entry ->
            val out = File(target, entry.name)
            if (entry.isDirectory) { out.mkdirs(); stageFolder(entry.uri, out, depth + 1) }
            else storage.openInputStream(entry.uri)?.use { input -> FileOutputStream(out).use { input.copyTo(it, 64 * 1024) } } ?: error("Cannot stage ${entry.name}")
        }
    }

    private fun copyStagedToStorage(source: File, destination: String, depth: Int) {
        require(depth <= 30) { "Extracted path too deep" }
        source.listFiles().orEmpty().forEach { child ->
            validatePath(child.name)
            if (child.isDirectory) {
                val dir = storage.createFolder(destination, child.name)
                copyStagedToStorage(child, dir, depth + 1)
            } else {
                val uri = storage.createFileDocument(destination, "application/octet-stream", child.name)
                try { FileInputStream(child).use { input -> storage.openOutputStream(uri)?.use { input.copyTo(it, 64 * 1024) } ?: error("Cannot write ${child.name}") } }
                catch (e: Exception) { runCatching { storage.delete(uri) }; throw e }
            }
        }
    }

    /** Writes TAR entries using fixed-size buffers; never loads an entire source file into RAM. */
    private fun appendTarEntry(entry: FileEntry, path: String, out: OutputStream, depth: Int) {
        require(depth <= 30) { "Folder nesting too deep" }
        validatePath(path)
        val name = if (entry.isDirectory) path.trimEnd('/') + "/" else path
        val nameBytes = name.toByteArray(Charsets.UTF_8)
        require(nameBytes.size <= 100) { "TAR path is longer than 100 bytes: $name" }
        require(entry.isDirectory || entry.size >= 0L) { "The storage provider did not report a size for ${entry.name}" }
        val size = if (entry.isDirectory) 0L else entry.size
        val header = ByteArray(512)
        putString(header, 0, 100, name)
        putOctal(header, 100, 8, if (entry.isDirectory) 493 else 420)
        putOctal(header, 108, 8, 0)
        putOctal(header, 116, 8, 0)
        putOctal(header, 124, 12, size)
        putOctal(header, 136, 12, System.currentTimeMillis() / 1000)
        for (i in 148 until 156) header[i] = 32
        header[156] = if (entry.isDirectory) '5'.code.toByte() else '0'.code.toByte()
        putString(header, 257, 6, "ustar\u0000")
        putString(header, 263, 2, "00")
        val checksum = header.sumOf { it.toInt() and 0xff }
        putString(header, 148, 6, checksum.toString(8).padStart(6, '0'))
        header[154] = 0
        header[155] = 32
        out.write(header)
        if (!entry.isDirectory) {
            val input = storage.openInputStream(entry.uri) ?: error("Cannot read ${entry.name}")
            input.use { source ->
                val buffer = ByteArray(64 * 1024)
                var remaining = size
                while (remaining > 0) {
                    val n = source.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                    if (n < 0) error("Source changed while archiving ${entry.name}")
                    out.write(buffer, 0, n)
                    remaining -= n
                }
            }
            val padding = (512 - (size % 512)).toInt() % 512
            if (padding > 0) out.write(ByteArray(padding))
        } else {
            storage.list(entry.uri).forEach { child -> appendTarEntry(child, "$name${child.name}", out, depth + 1) }
        }
    }

    private fun ensureParent(root: String, path: String): String {
        var parent = root
        val segments = path.trimEnd('/').split('/').filter { it.isNotBlank() }
        segments.dropLast(1).forEach { segment ->
            val exists = storage.list(parent).firstOrNull { it.name == segment && it.isDirectory }
            parent = exists?.uri ?: storage.createFolder(parent, segment)
        }
        return parent
    }

    private fun validatePath(path: String) {
        val normalized = path.replace('\\', '/')
        require(!normalized.startsWith('/') && !normalized.contains('\u0000') && normalized.split('/').none { it == ".." }) { "Unsafe archive path: $path" }
    }
    private fun readExactly(input: InputStream, bytes: ByteArray): Boolean {
        var offset = 0
        while (offset < bytes.size) { val n = input.read(bytes, offset, bytes.size - offset); if (n < 0) { if (offset == 0) return false else error("Archive ended in the middle of a header") }; offset += n }
        return true
    }
    private fun copyExactly(input: InputStream, output: OutputStream, size: Long) {
        var left = size; val buffer = ByteArray(64 * 1024)
        while (left > 0) { val n = input.read(buffer, 0, minOf(buffer.size.toLong(), left).toInt()); if (n < 0) error("Archive entry is truncated"); output.write(buffer, 0, n); left -= n }
    }
    private fun skipExactly(input: InputStream, count: Long) {
        var left = count; val buffer = ByteArray(8192)
        while (left > 0) { val n = input.read(buffer, 0, minOf(buffer.size.toLong(), left).toInt()); if (n < 0) error("Archive is truncated"); left -= n }
    }
    private fun roundBlock(size: Long) = ((size + 511) / 512) * 512
    private fun readString(bytes: ByteArray, start: Int, length: Int) = bytes.copyOfRange(start, start + length).takeWhile { it != 0.toByte() }.toByteArray().toString(Charsets.UTF_8).trim()
    private fun readOctal(bytes: ByteArray, start: Int, length: Int): Long = bytes.copyOfRange(start, start + length).toString(Charsets.US_ASCII).trim('\u0000', ' ').toLongOrNull(8) ?: 0L
    private fun putString(bytes: ByteArray, start: Int, length: Int, value: String) { val source = value.toByteArray(Charsets.UTF_8); source.copyInto(bytes, start, 0, minOf(source.size, length)) }
    private fun putOctal(bytes: ByteArray, start: Int, length: Int, value: Long) { val text = value.toString(8).padStart(length - 1, '0').takeLast(length - 1) + "\u0000"; putString(bytes, start, length, text) }
}
