package com.bijoyism.filenavigator.domain

/** A user-requested cancellation, distinct from WorkManager stopping a worker due to system conditions. */
class TransferCancelledException : Exception("Transfer cancelled by user.")
