package com.bijoyism.filenavigator.storage

import com.bijoyism.filenavigator.domain.FileEntry
import kotlinx.coroutines.CancellationException

/** Read-only report; similar-image matches are suggestions, exact duplicates are SHA-256 matches. */
data class DuplicateGroup(val hash: String, val size: Long, val files: List<FileEntry>)
data class StorageReport(
    val scannedFiles: Int,
    val totalBytes: Long,
    val categoryBytes: Map<String, Long>,
    val largestFiles: List<FileEntry>,
    val duplicateGroups: List<DuplicateGroup>,
    val skippedFiles: Int,
    val emptyFolders: List<FileEntry> = emptyList(),
    val oldFiles: List<FileEntry> = emptyList(),
    val similarImageGroups: List<List<FileEntry>> = emptyList(),
    val typeCounts: Map<String, Int> = emptyMap()
)

class StorageAnalyzer(private val storage: SafStorage) {
    fun analyze(
        roots: List<String>,
        excludedUris: Set<String> = emptySet(),
        shouldCancel: () -> Boolean = { false },
        onProgress: (Int) -> Unit = {},
        maxFiles: Int = MAX_FILES
    ): StorageReport {
        val files = mutableListOf<FileEntry>()
        val emptyFolders = mutableListOf<FileEntry>()
        var skipped = 0
        val visited = HashSet<String>()
        val pending = ArrayDeque<String>()
        roots.forEach(pending::addLast)
        while (pending.isNotEmpty() && visited.size < maxFiles.coerceIn(100, MAX_FILES)) {
            if (shouldCancel()) throw CancellationException("Storage scan cancelled")
            val folder = pending.removeFirst()
            if (folder in excludedUris || !visited.add(folder)) continue
            val children = runCatching { storage.list(folder) }.getOrElse {
                skipped++
                emptyList()
            }
            if (children.isEmpty()) {
                emptyFolders.add(FileEntry(folder, storage.label(folder).substringAfterLast('/'), 0L, null, 0L, true))
            }
            children.forEach { entry ->
                if (shouldCancel()) throw CancellationException("Storage scan cancelled")
                if (visited.size >= maxFiles.coerceIn(100, MAX_FILES)) return@forEach
                if (entry.isDirectory) {
                    if (entry.uri !in excludedUris) pending.addLast(entry.uri)
                } else if (files.size < maxFiles.coerceIn(100, MAX_FILES) && entry.uri !in excludedUris) files.add(entry)
            }
            onProgress(visited.size)
        }
        val categories = files.groupBy(::category).mapValues { (_, entries) -> entries.sumOf { it.size.coerceAtLeast(0) } }
        val duplicateCandidates = files.filter { it.size > 0 }.groupBy { it.size }.values.filter { it.size > 1 }.flatten()
        val hashes = mutableListOf<Triple<FileEntry, String, Long>>()
        duplicateCandidates.forEach { entry ->
            if (shouldCancel()) throw CancellationException("Storage scan cancelled")
            val hash = runCatching { storage.sha256(entry.uri) }.getOrNull()
            if (hash == null) skipped++ else hashes.add(Triple(entry, hash, entry.size))
        }
        val duplicates = hashes.groupBy { it.third to it.second }.values.filter { it.size > 1 }
            .map { group -> DuplicateGroup(group.first().second, group.first().third, group.map { it.first }) }
            .sortedByDescending { it.size }

        val imageCandidates = files.filter { isImage(it) && it.size > 0 }.take(MAX_SIMILAR_IMAGES)
        val perceptual = mutableListOf<Pair<FileEntry, Long>>()
        imageCandidates.forEach { image ->
            if (shouldCancel()) throw CancellationException("Storage scan cancelled")
            runCatching { storage.perceptualHash(image.uri) }.onSuccess { perceptual.add(image to it) }.onFailure { skipped++ }
        }
        val remaining = perceptual.toMutableList()
        val similar = mutableListOf<List<FileEntry>>()
        while (remaining.isNotEmpty()) {
            if (shouldCancel()) throw CancellationException("Storage scan cancelled")
            val seed = remaining.removeAt(0)
            val group = remaining.filter { java.lang.Long.bitCount(seed.second xor it.second) <= 6 }
            if (group.isNotEmpty()) {
                remaining.removeAll(group.toSet())
                similar.add(listOf(seed.first) + group.map { it.first })
            }
        }
        val yearAgo = System.currentTimeMillis() - YEAR_MILLIS
        return StorageReport(
            scannedFiles = files.size,
            totalBytes = files.sumOf { it.size.coerceAtLeast(0) },
            categoryBytes = categories,
            largestFiles = files.sortedByDescending { it.size }.take(50),
            duplicateGroups = duplicates,
            skippedFiles = skipped,
            emptyFolders = emptyFolders.take(200),
            oldFiles = files.filter { it.lastModified in 1 until yearAgo }.sortedBy { it.lastModified }.take(100),
            similarImageGroups = similar,
            typeCounts = files.groupingBy { it.name.substringAfterLast('.', "(no extension)").lowercase() }.eachCount().toList().sortedByDescending { it.second }.take(50).toMap()
        )
    }

    private fun isImage(file: FileEntry): Boolean = file.mimeType.orEmpty().startsWith("image/") || file.name.substringAfterLast('.', "").lowercase() in setOf("jpg", "jpeg", "png", "webp", "bmp", "gif", "heic")
    private fun category(file: FileEntry): String {
        val mime = file.mimeType.orEmpty()
        return when {
            mime.startsWith("image/") -> "Images"
            mime.startsWith("video/") -> "Videos"
            mime.startsWith("audio/") -> "Audio"
            mime == "application/pdf" || mime.startsWith("text/") || file.name.substringAfterLast('.', "").lowercase() in setOf("doc", "docx", "odt", "rtf", "csv", "json", "xml") -> "Documents"
            file.name.substringAfterLast('.', "").lowercase() in setOf("zip", "rar", "7z", "gz", "tar", "apk", "jar") -> "Archives & packages"
            else -> "Other"
        }
    }

    companion object {
        private const val MAX_FILES = 10_000
        private const val MAX_SIMILAR_IMAGES = 500
        private const val YEAR_MILLIS = 365L * 24 * 60 * 60 * 1000
    }
}
