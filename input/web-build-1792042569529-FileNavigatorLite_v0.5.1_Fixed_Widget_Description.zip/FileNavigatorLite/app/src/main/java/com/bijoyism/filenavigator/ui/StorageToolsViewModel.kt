package com.bijoyism.filenavigator.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bijoyism.filenavigator.AppContainer
import com.bijoyism.filenavigator.security.VaultManager
import com.bijoyism.filenavigator.storage.StorageAnalyzer
import com.bijoyism.filenavigator.storage.StorageReport
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean

class StorageToolsViewModel(private val container: AppContainer) : ViewModel() {
    val queue = container.features.queue.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val _report = MutableStateFlow<StorageReport?>(null)
    val report: StateFlow<StorageReport?> = _report
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy
    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message
    private val _performanceSummary = MutableStateFlow<String?>(null)
    val performanceSummary: StateFlow<String?> = _performanceSummary
    private val _archiveEntries = MutableStateFlow<List<com.bijoyism.filenavigator.storage.SafStorage.ZipItem>>(emptyList())
    val archiveEntries: StateFlow<List<com.bijoyism.filenavigator.storage.SafStorage.ZipItem>> = _archiveEntries
    private val _vaultItems = MutableStateFlow<List<VaultManager.VaultItem>>(emptyList())
    val vaultItems: StateFlow<List<VaultManager.VaultItem>> = _vaultItems
    private val _vaultMessage = MutableStateFlow<String?>(null)
    val vaultMessage: StateFlow<String?> = _vaultMessage
    private var scanJob: Job? = null
    private val cancelScan = AtomicBoolean(false)

    fun retryQueue(id: String) { viewModelScope.launch { container.queue.retry(id) } }
    fun pauseQueue(id: String) { viewModelScope.launch { container.queue.pauseQueued(id) } }
    fun cancelQueue(id: String) { viewModelScope.launch { container.queue.cancel(id) } }
    fun clearQueueHistory() { viewModelScope.launch { container.features.clearFinishedQueue() } }

    fun analyze() {
        if (_busy.value) return
        cancelScan.set(false)
        scanJob = viewModelScope.launch {
            _busy.value = true
            _progress.value = 0f
            _message.value = null
            _performanceSummary.value = null
            val scanStartedAt = android.os.SystemClock.elapsedRealtime()
            val roots = container.storage.grantedRoots()
            if (roots.isEmpty()) _message.value = "Add a folder in Settings before scanning."
            else {
                try {
                    val prefs = container.features.currentPrefs()
                    val scanLimit = if (prefs.lowMemoryMode) 2_500 else 10_000
                    val data = withContext(Dispatchers.IO) {
                        StorageAnalyzer(container.storage).analyze(
                            roots, prefs.scanExclusions,
                            { cancelScan.get() },
                            { visited -> _progress.value = (visited / scanLimit.toFloat()).coerceIn(0f, 0.99f) },
                            scanLimit
                        )
                    }
                    _report.value = data
                    val elapsedMs = (android.os.SystemClock.elapsedRealtime() - scanStartedAt).coerceAtLeast(1L)
                    val filesPerSecond = (data.scannedFiles * 1000L / elapsedMs).coerceAtLeast(0L)
                    val runtime = Runtime.getRuntime()
                    val approximateHeapMb = ((runtime.totalMemory() - runtime.freeMemory()).coerceAtLeast(0L) / (1024L * 1024L))
                    _performanceSummary.value = "Scan diagnostics · ${elapsedMs / 1000.0}s · $filesPerSecond files/s · approx. JVM heap $approximateHeapMb MB"
                    _message.value = "Scan complete: ${data.scannedFiles} files analyzed."
                    _progress.value = 1f
                } catch (e: CancellationException) {
                    _message.value = "Storage scan cancelled."
                } catch (e: Exception) {
                    _message.value = "Scan failed: ${e.message ?: "unknown error"}"
                }
            }
            _busy.value = false
            scanJob = null
        }
    }

    fun cancelAnalysis() {
        cancelScan.set(true)
        // Analyzer checks the atomic flag between folders and expensive hashing passes.
    }

    fun exportReport(uri: Uri) {
        val data = _report.value ?: run { _message.value = "Run a scan first."; return }
        viewModelScope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    val csv = buildString {
                        appendLine("section,name,size_bytes,modified,uri")
                        data.largestFiles.forEach { appendLine("largest,\"${it.name.replace("\"", "\"\"")}\",${it.size},${it.lastModified},\"${it.uri}\"") }
                        data.oldFiles.forEach { appendLine("older_than_one_year,\"${it.name.replace("\"", "\"\"")}\",${it.size},${it.lastModified},\"${it.uri}\"") }
                        data.duplicateGroups.forEachIndexed { i, group -> group.files.forEach { appendLine("duplicate_group_${i + 1},\"${it.name.replace("\"", "\"\"")}\",${it.size},${it.lastModified},\"${it.uri}\"") } }
                        data.similarImageGroups.forEachIndexed { i, group -> group.forEach { appendLine("similar_image_group_${i + 1},\"${it.name.replace("\"", "\"\"")}\",${it.size},${it.lastModified},\"${it.uri}\"") } }
                    }
                    container.appContext.contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { it.write(csv) } ?: error("Cannot write report")
                }
            }.onSuccess { _message.value = "Storage report exported." }.onFailure { _message.value = "Report export failed: ${it.message}" }
        }
    }

    fun inspectArchive(uri: Uri) {
        viewModelScope.launch {
            _busy.value = true
            runCatching { withContext(Dispatchers.IO) { container.storage.listZipEntries(uri.toString()) } }
                .onSuccess { _archiveEntries.value = it; _message.value = "Archive inspected: ${it.size} entries." }
                .onFailure { _message.value = "Could not inspect archive: ${it.message}" }
            _busy.value = false
        }
    }

    fun createArchive(source: Uri, destination: Uri, name: String, compressionLevel: Int = 6) {
        runArchive("Creating ZIP archive…") {
            container.storage.grant(source); container.storage.grant(destination)
            container.storage.createZip(source.toString(), destination.toString(), name.ifBlank { "Archive.zip" }, compressionLevel)
            "ZIP archive created."
        }
    }

    fun extractArchive(archive: Uri, destination: Uri) {
        runArchive("Extracting ZIP archive…") {
            container.storage.grant(archive); container.storage.grant(destination)
            val count = container.storage.extractZip(archive.toString(), destination.toString())
            "Extracted $count file(s). Existing files are never overwritten."
        }
    }

    fun extractSelectedArchive(archive: Uri, destination: Uri, selected: Set<String>) {
        runArchive("Extracting selected entries…") {
            container.storage.grant(archive); container.storage.grant(destination)
            val count = container.storage.extractZipSelected(archive.toString(), destination.toString(), selected)
            "Extracted $count selected file(s)."
        }
    }

    fun createEncryptedZip(source: Uri, destination: Uri, name: String, password: CharArray) {
        runArchive("Creating AES-256 encrypted ZIP…") {
            container.storage.grant(source); container.storage.grant(destination)
            container.archives.createEncryptedZip(source.toString(), destination.toString(), name, password)
            "Encrypted ZIP archive created. Store the password somewhere safe; it cannot be recovered."
        }
    }

    fun extractEncryptedZip(archive: Uri, destination: Uri, password: CharArray) {
        runArchive("Extracting encrypted ZIP…") {
            container.storage.grant(archive); container.storage.grant(destination)
            val count = container.archives.extractEncryptedZip(archive.toString(), destination.toString(), password)
            "Encrypted archive extracted ($count entries). Existing files are protected by the output provider's conflict behavior."
        }
    }

    fun createGzip(source: Uri, destination: Uri, name: String) {
        runArchive("Creating GZIP…") {
            container.storage.grant(source); container.storage.grant(destination)
            container.archives.createGzip(source.toString(), destination.toString(), name)
            "GZIP archive created."
        }
    }

    fun extractGzip(source: Uri, destination: Uri, name: String) {
        runArchive("Extracting GZIP…") {
            container.storage.grant(source); container.storage.grant(destination)
            container.archives.extractGzip(source.toString(), destination.toString(), name)
            "GZIP file extracted."
        }
    }

    fun createTarGz(source: Uri, destination: Uri, name: String) {
        runArchive("Creating TAR.GZ…") {
            container.storage.grant(source); container.storage.grant(destination)
            container.archives.createTarGz(source.toString(), destination.toString(), name)
            "TAR.GZ archive created."
        }
    }

    fun extractTarGz(source: Uri, destination: Uri) {
        runArchive("Extracting TAR.GZ…") {
            container.storage.grant(source); container.storage.grant(destination)
            val count = container.archives.extractTarGz(source.toString(), destination.toString())
            "TAR.GZ extracted ($count files)."
        }
    }

    fun splitFile(source: Uri, destination: Uri, name: String, partSizeMb: Int) {
        runArchive("Splitting file…") {
            container.storage.grant(source); container.storage.grant(destination)
            val parts = container.archives.splitFile(source.toString(), destination.toString(), name, partSizeMb)
            "Created ${parts.size} part(s). Keep all parts together before joining."
        }
    }

    fun joinParts(parts: List<Uri>, destination: Uri, name: String) {
        runArchive("Joining file parts…") {
            parts.forEach(container.storage::grant); container.storage.grant(destination)
            container.archives.joinParts(parts.map(Uri::toString), destination.toString(), name)
            "Joined ${parts.size} part(s)."
        }
    }

    fun emptyTrash() {
        viewModelScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) {
                var removed = 0
                fun removeChildren(folderUri: String) {
                    container.storage.list(folderUri).forEach { child ->
                        if (child.isDirectory) removeChildren(child.uri)
                        container.storage.delete(child.uri)
                        removed++
                    }
                }
                container.storage.grantedRoots().forEach { root ->
                    container.storage.list(root).firstOrNull { it.isDirectory && it.name == ".FileNavigatorTrash" }?.let { trash ->
                        removeChildren(trash.uri)
                        container.storage.delete(trash.uri)
                    }
                }
                removed
            } }
            _message.value = result.fold({ "Permanently removed $it trashed item(s)." }, { "Could not empty recycle bin: ${it.message}" })
        }
    }

    fun refreshVault() {
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.IO) { container.vault.list() } }
                .onSuccess { _vaultItems.value = it }
                .onFailure { _vaultMessage.value = "Vault could not be opened: ${it.message}" }
        }
    }

    fun importVault(uri: Uri) {
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.IO) { container.vault.importFrom(uri) } }
                .onSuccess { _vaultMessage.value = "Encrypted copy added for ${it.name}. The original file was not deleted."; refreshVault() }
                .onFailure { _vaultMessage.value = "Vault import failed: ${it.message}" }
        }
    }

    fun exportVault(id: String, uri: Uri) {
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.IO) { container.vault.exportTo(id, uri) } }
                .onSuccess { _vaultMessage.value = "Decrypted file exported. Keep the exported copy private." }
                .onFailure { _vaultMessage.value = "Vault export failed: ${it.message}" }
        }
    }

    fun deleteVault(id: String) {
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.IO) { container.vault.delete(id) } }
                .onSuccess { _vaultMessage.value = "Vault item removed."; refreshVault() }
                .onFailure { _vaultMessage.value = "Could not remove vault item: ${it.message}" }
        }
    }

    private fun runArchive(startMessage: String, operation: suspend () -> String) {
        if (_busy.value) return
        viewModelScope.launch {
            _busy.value = true
            _message.value = startMessage
            runCatching { withContext(Dispatchers.IO) { operation() } }
                .onSuccess { _message.value = it }
                .onFailure { _message.value = "Operation failed: ${it.message ?: "unknown error"}" }
            _busy.value = false
        }
    }
}
