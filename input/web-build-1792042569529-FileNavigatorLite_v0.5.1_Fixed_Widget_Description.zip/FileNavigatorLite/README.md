# File Navigator Lite 0.5.0 — Expanded Feature Release

A lightweight Android file manager with rule-based automatic organization, a Material 3 theme system, storage analysis and ZIP tools.

- Kotlin, Jetpack Compose, Material 3, MVVM, DataStore, WorkManager and Storage Access Framework.
- Minimum Android version: Android 10 (API 29).
- Designed for lower-end ARM phones; no analytics, cloud sync or network permission is required.
- Package: `com.bijoyism.filenavigator`.

## Included features in v0.5.0

- Material 3 theme modes and palettes, custom accent selection, reduced motion, compact rows, haptic preference and customizable navigation order.
- SAF-based file browsing, search/filter/sort, favorites, bookmarks, recent URIs, tags/collections, grid/list presentation, file properties, file sharing/opening, multi-select and batch-rename planning.
- Rule-based background organization with periodic WorkManager checks (15 minutes minimum), templates, dry run, conflict handling, history, time windows and battery/network constraints.
- Persistent transfer queue with progress, retry/cancel controls, configurable 1–3 queue lanes, copy verification and background notifications. Running transfer pause/resume from a byte offset is not implemented; retry restarts the file.
- Native image, bounded text/code, PDF, audio and video previews using Android framework APIs; APK metadata; ZIP inspection; external-app fallback; lazy thumbnail cache.
- Storage analysis with category totals, large/old files, empty folders, SHA-256 duplicate groups, heuristic perceptual-image groups, scan cancellation, exclusions and CSV reports. Analysis is read-only.
- ZIP creation/extraction, selected ZIP extraction, AES-encrypted ZIP, GZIP and TAR.GZ operations, and raw-file split/join. RAR/7z and standard multi-volume ZIP are not supported.
- Android Keystore-backed encrypted vault, optional PIN app lock, recycle-bin workflow where supported, settings/rule/history backup with restore preview, scheduled local backups, dynamic app shortcuts and home-screen widget.
- Unit tests for file filtering, preview routing, naming/listing, rules, PIN security and transfer-slot assignment; GitHub Actions CI configured for unit tests, Android lint and APK assembly.

## Compatibility and limits

- Minimum Android version: Android 10 (API 29); designed for lower-end ARM phones.
- Uses Kotlin, Jetpack Compose, Material 3, MVVM, DataStore, WorkManager and Android's Storage Access Framework.
- No analytics, cloud sync, or app network permission is required by the app's core design.
- SAF providers differ. File-system watching is not uniformly available through SAF; scheduled WorkManager scans are the reliable fallback and may be delayed by Android power management.
- This archive has not been built with Gradle in the current environment because Gradle and the Android SDK are unavailable here. Use the CI workflow before installing. See `docs/FEATURE_COVERAGE.md` for the status of every selected feature and remaining work.

## Build APK without a PC

1. Upload the contents of this folder to your GitHub repository using the GitHub website or Termux.
2. Open **Actions → Build APK** and run the workflow.
3. The workflow runs JVM unit tests, Android lint and debug APK assembly.
4. Download the `FileNavigatorLite-debug` artifact. If the workflow fails, download the `reports` artifact and inspect the first Gradle/Kotlin error.

No Gradle wrapper is included; CI installs Gradle 8.9. Formatting is not a build gate; the workflow avoids an external formatter download dependency until the build is stable.

## Suggested device acceptance checks

1. Install on Android 10/API 29 and confirm the app opens and theme settings persist.
2. Grant a test folder and create a rule with a test file; verify dry-run preview before enabling automatic moves.
3. Confirm the 15-minute minimum schedule is shown and that WorkManager may defer execution.
4. Scan a folder containing known duplicates and confirm matching hashes group only identical content.
5. Create and extract a ZIP using test files, including an archive with `../` paths; confirm unsafe entries are rejected.
6. Export a backup, change settings, restore it, and verify auto-organization remains disabled.
7. Test file operations and undo using disposable files before trusting the app with important data.

See `docs/` for device notes, permissions, privacy and limitations.


## v0.3.0 milestone notes

- Added in-app image previews for common image formats and bounded plain-text/code previews (maximum 256 KB) through Android's Storage Access Framework.
- Added preview routing tests for images, text, PDF, audio, video, archives, APKs, and unsupported files.
- PDF, audio, video, archives, and APKs continue to use compatible external handlers or the existing archive tools; they are not claimed as fully native previews.
- Existing multi-file copy/move work is still executed as a sequential operation plan by the current engine; this release does not yet add pause/resume or a persistent transfer-queue screen.
- Storage analyzer already reports categories, largest files, exact duplicates, and skipped items; scan cancellation and incremental indexing remain future work.


## Version 0.4.0

See [release notes](docs/RELEASE_0.4.0.md) for actual changes and validation status, and [full implementation plan](docs/IMPLEMENTATION_PLAN_ALL_FEATURES.md) for the selected feature set. This package adds composable file filtering and a tested batch-rename planner; it does not claim every planned feature is implemented. Run the GitHub Actions workflow before installing.


## Version 0.5.0

See [feature coverage](docs/FEATURE_COVERAGE.md) for the status of every selected feature and [release notes](docs/RELEASE_0.5.0.md) for changes and validation details.
