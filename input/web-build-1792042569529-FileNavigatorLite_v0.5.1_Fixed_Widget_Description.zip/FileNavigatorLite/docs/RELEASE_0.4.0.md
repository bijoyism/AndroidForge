# File Navigator Lite 0.4.0 — expanded feature release

## Source inspected

Based on `FileNavigatorLite_v0.3.0_Native_Previews.zip`. The existing project uses Kotlin, Jetpack Compose, Material 3, MVVM-style ViewModels, DataStore, WorkManager and Android Storage Access Framework. `minSdk` remains 29 (Android 10). The CI workflow continues to run JVM tests, Android lint and `assembleDebug` and upload the APK artifact.

## Changes in this source package

- Version advanced to 0.4.0 / versionCode 5.
- Added pure `FileQuery` composition for text, extension, MIME prefix, size range, modification-time range and hidden-file filtering.
- Added `BatchRenamePlanner` for numbered rename and find/replace previews. It rejects path separators in prefix/suffix/replacement and requires non-empty search text. This is a planner only; UI integration and collision resolution remain required before executing a batch rename.
- Added JVM tests for filter composition, hidden files and batch-rename planning.
- Preserved the existing source files and build workflow.

## Existing functionality confirmed by source inspection

- SAF folder grants and browsing; paginated file list; search; name/size/date/type sorting; grid/list toggle; multi-select; create folder; rename; delete; copy/move through the rule engine; operation history.
- Automation rules with extension, MIME, keyword, size and conflict matching; WorkManager-based periodic reconciliation; preview-before-run flow; notifications and history.
- Storage category totals, large-file reporting, exact duplicate hashing and ZIP create/extract paths.
- In-app image and text preview paths; unsupported preview types are routed to external apps.
- Material 3 themes/settings and DataStore-backed application data.

## Not implemented by this release

This is not a claim that all 130+ selected feature ideas are complete. The following require additional UI, persistence, dependency selection and device testing: persistent transfer queue with durable per-file progress/pause/resume/cancellation; native PDF/audio/video playback; image gallery and waveform; encrypted ZIP password handling and extra archive formats; similar-image detection; recycle bin; encrypted vault and biometric app lock; scheduled backups; widgets/shortcuts; drag-and-drop; full time-window/battery/network automation policies; robust SAF recovery and external USB handling; broad accessibility/performance benchmarking. The batch rename planner is not yet connected to a UI or storage executor. Do not treat these as shipped features.

## Validation status

- ZIP structure/integrity: must be checked after packaging.
- Gradle compile, unit tests, lint and APK build: not run in the authoring environment (no Gradle executable/wrapper available here).
- Device tests: not run.

Run the included GitHub Actions workflow before installing. Treat CI as the source of truth for compiler/test failures. On AndroidForge, upload the extracted project source ZIP and inspect its build log.

## Safety design constraints for subsequent work

- Never silently delete files or replace existing data by default.
- Keep duplicate scans read-only and require explicit user action for cleanup.
- SAF access is limited to granted folders; filesystem paths are not universally available.
- WorkManager periodic work is inexact and Android may defer execution.
- Vault encryption must use vetted Android cryptography and Android Keystore; do not implement a home-grown cipher.
- Pause/resume must only be offered for operations that can actually resume safely.
