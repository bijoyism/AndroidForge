# File Navigator Lite 0.5.0 — Expanded Feature Release

## Highlights

- Extended file queries and batch rename planning, including path-separator safety checks.
- Persistent WorkManager transfer queue with per-file and aggregate progress, copy hash verification, notifications, retry/cancel controls, and adjustable 1–3 concurrency lanes. The concurrency lane count is applied to newly scheduled work; changing it does not migrate already-enqueued items.
- Native image gallery, bounded text/code viewer, PDF rendering, audio/video playback, APK metadata and ZIP entry inspection.
- ZIP creation/extraction and selective ZIP extraction, AES-encrypted ZIP, GZIP/TAR.GZ, and raw-file split/join utilities.
- Storage scan cancellation, categorized usage, largest/old/empty results, exact duplicate hashes, heuristic perceptual image grouping and CSV report export.
- Favorites/bookmarks/recents, tags/collections, smart folders, file URI/name clipboard actions, dynamic shortcuts, home widget, local encrypted vault and PIN lock.
- Settings and rule backup/restore preview, local scheduled configuration backup, export warning, regression tests and per-feature coverage matrix.

## Validation status

- Source ZIP integrity: checked after packaging with `unzip -t` (passed).
- Kotlin syntax scan: run without Android/Compose/Zip4j classpaths; only syntax/parser diagnostics can be meaningfully interpreted, not type-checking.
- Gradle compile/tests/lint/device test: **not run in the authoring environment** because Gradle, Android SDK and Android dependencies are not installed. Run the included GitHub Actions workflow before installing the APK.

## Important partial/deferred work

See `FEATURE_COVERAGE.md` for each selected ID. In particular, transfer pause is only available for queued jobs and is not byte-offset resumable; there is no audio waveform renderer, RAR/7z support, standard multi-volume archive format, full tablet split-pane UX, Room database, full diagnostic bundle or benchmark suite. Some SAF providers do not support every operation.

## Safety

- Automatic organization requires explicit user-enabled rules and authorized folders.
- Storage duplicate analysis never automatically deletes files.
- Archive extraction includes path validation and size/entry limits; only test untrusted archives first.
- Settings backups do not contain vault files or app PIN, but may contain URI references and user activity history; export dialog warns about this.
- WorkManager schedules can be deferred by the operating system.
