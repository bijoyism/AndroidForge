# Selected feature coverage — v0.5.0

This matrix is intentionally explicit: it distinguishes integrated features from partial implementations and deferred work. ‘Implemented’ means source/UI path exists; it does **not** imply that APK compilation or device behavior has been verified. The local environment used to package this release did not have Gradle or Android SDK tooling available.

Coverage summary: 123 feature entries are tracked in this matrix — 82 marked implemented, 39 partial, and 2 deferred. The selected feature set is represented here, but items marked partial/deferred are not being claimed as complete.

## File management essentials

| ID | Feature | Status | Notes |
|---|---|---|---|
| `fm_browse` | Advanced file browser | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `fm_search` | Powerful search | **Partial** | Search works in current/authorized areas and virtual searches have bounded scan limits; it is not a fully indexed system-wide search engine. |
| `fm_filter` | Advanced filtering | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `fm_sort` | Sorting options | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `fm_views` | Grid, list and compact views | **Partial** | Grid/list modes and compact rows exist; there is no full responsive two-pane tablet layout. |
| `fm_multi` | Bulk operations | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `fm_rename` | Bulk rename tool | **Partial** | Batch rename has preview/planning and safety checks; provider-side multi-rename failure recovery is limited. |
| `fm_clipboard` | Clipboard and drag-and-drop | **Partial** | Copy-to-clipboard actions exist for file name/URI and Android share intents; general clipboard queueing and drag-and-drop are not complete. |
| `fm_fav` | Favorites and recent files | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `fm_hidden` | Hidden files | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `fm_properties` | Detailed file properties | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `fm_share` | Sharing and Send to | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |

## Automatic file organizer

| ID | Feature | Status | Notes |
|---|---|---|---|
| `auto_interval` | Configurable check interval | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `auto_rules` | Advanced rule builder | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `auto_templates` | Prebuilt organization rules | **Partial** | Some built-in rule templates exist, but template export/import and broad preset customization are incomplete. |
| `auto_multi` | Multiple independent rules | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `auto_preview` | Dry-run preview | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `auto_watch` | Faster change detection | **Deferred** | SAF does not offer a consistent cross-provider file observer; reliable periodic WorkManager scans remain the supported fallback. |
| `auto_conflict` | Conflict policies | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `auto_logs` | Automation history | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `auto_notify` | Summary notifications | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `auto_windows` | Time windows | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `auto_battery` | Battery and network policies | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `auto_recovery` | Recover failed operations | **Partial** | WorkManager retries and manual retry exist; automatic per-error recovery and permission recovery flows are limited. |

## Transfer queue and file operations

| ID | Feature | Status | Notes |
|---|---|---|---|
| `q_queue` | Persistent transfer queue | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `q_progress` | Per-file and overall progress | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `q_cancel` | Cancel and retry | **Partial** | Queued tasks can be cancelled and failed tasks retried. Cancelling a running transfer depends on WorkManager/provider cancellation behavior and needs device verification. |
| `q_pause` | Pause and resume | **Partial** | Queued tasks can be paused; exact byte-offset pause/resume for a running provider stream is not implemented. |
| `q_parallel` | Transfer concurrency controls | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `q_verify` | Integrity verification | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `q_undo` | Undo and recovery | **Partial** | Undo is supported for eligible moves/trash operations recorded in history; arbitrary copies/deletes cannot always be reversed. |
| `q_conflicts` | Interactive conflict resolution | **Partial** | Safe rename/skip behavior exists in background queue, but a fully interactive conflict-resolution sheet for every worker conflict is not implemented. |
| `q_notifications` | Background transfer notifications | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `q_safe` | Safe replacement | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |

## Native file previews

| ID | Feature | Status | Notes |
|---|---|---|---|
| `pv_image` | Image viewer | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pv_gallery` | Image gallery | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pv_text` | Text and code viewer | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pv_pdf` | PDF viewer | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pv_audio` | Audio preview | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pv_video` | Video player | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pv_audio_wave` | Audio waveform | **Deferred** | No waveform renderer is included. |
| `pv_docs` | Document previews | **Partial** | Common text-like formats such as JSON/XML/CSV/Markdown can use the bounded text preview; rich formatted office-document renderers are not included. |
| `pv_apk` | APK information | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pv_archive` | Archive browser | **Partial** | ZIP entries can be inspected and selected for extraction; generic archive browsing for all formats is not implemented. |
| `pv_thumbs` | Thumbnail generation | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pv_external` | Open externally fallback | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |

## Archive and compression tools

| ID | Feature | Status | Notes |
|---|---|---|---|
| `arc_zip` | Create ZIP archives | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `arc_extract` | Extract archives | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `arc_browse` | Browse before extraction | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `arc_password` | Encrypted ZIP support | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `arc_formats` | More archive formats | **Partial** | ZIP, AES-encrypted ZIP, GZIP and TAR.GZ operations are included. RAR/7z and general TAR support are not included. |
| `arc_select` | Selective extraction | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `arc_split` | Split large archives | **Partial** | The app can split/join raw files. It does not create a standard multi-volume ZIP/7z archive. |
| `arc_compress` | Compression settings | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |

## Storage analyzer and cleanup

| ID | Feature | Status | Notes |
|---|---|---|---|
| `st_overview` | Storage dashboard | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `st_largest` | Large-file finder | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `st_duplicate` | Exact duplicate finder | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `st_similar` | Similar-image finder | **Partial** | Uses perceptual hash grouping as a heuristic; review results before acting because false positives are possible. |
| `st_empty` | Empty-folder finder | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `st_old` | Old-file finder | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `st_categories` | Category breakdown | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `st_scan` | Cancellable scans | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `st_exclude` | Scan exclusions | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `st_report` | Export storage reports | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `st_cleanup` | Safe cleanup assistant | **Partial** | Deletion uses a recycle-bin folder and empty-bin confirmation; cleanup candidates are suggestions, not automatically removed. |

## Material 3 Expressive UI

| ID | Feature | Status | Notes |
|---|---|---|---|
| `ui_dynamic` | Dynamic Material You colours | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `ui_themes` | Multiple themes | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `ui_motion` | Smooth animations | **Partial** | Partially integrated; additional behavior or device validation is required. |
| `ui_reduce` | Reduced-motion setting | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `ui_adaptive` | Adaptive layouts | **Partial** | Layout can scroll and adapt to phone orientation; a purpose-built tablet/multi-pane UX is not complete. |
| `ui_bottom` | Customizable navigation | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `ui_toolbar` | Expressive toolbars | **Partial** | Partially integrated; additional behavior or device validation is required. |
| `ui_haptics` | Haptic feedback | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `ui_accent` | Custom accent colours | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `ui_density` | Compact mode | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `ui_a11y` | Accessibility improvements | **Partial** | Material components provide baseline semantics; a full TalkBack/scalable-font/accessibility audit has not been performed. |

## Privacy and security

| ID | Feature | Status | Notes |
|---|---|---|---|
| `sec_vault` | Encrypted private vault | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `sec_lock` | App lock | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `sec_hide` | Private-folder exclusions | **Partial** | Hidden files and scan exclusions are available; a separate virtual private-folder policy across every screen is incomplete. |
| `sec_trash` | Recycle bin | **Partial** | Deletion routes to a hidden trash folder where supported; not every SAF provider permits reliable recycle/restore semantics. |
| `sec_permissions` | Permission dashboard | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `sec_confirm` | Destructive-action safeguards | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `sec_integrity` | File integrity checker | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `sec_audit` | Security and operation log | **Partial** | Activity history records file operations; it is not a tamper-proof security audit log. |
| `sec_timeout` | Automatic vault lock | **Partial** | App PIN locks on startup/foreground transitions; biometric unlock and exhaustive idle/Doze behavior require device tests. |
| `sec_export` | Protected exports | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |

## Backup, restore and customization

| ID | Feature | Status | Notes |
|---|---|---|---|
| `bk_settings` | Settings backup | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `bk_rules` | Automation-rule backup | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `bk_restore` | Restore preview | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `bk_version` | Versioned backup format | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `bk_schedule` | Scheduled configuration backups | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `bk_layout` | Home dashboard customization | **Implemented** | Home dashboard sections can be shown/hidden and the quick-action set is configurable; arbitrary drag-reordering of cards is not included. |
| `bk_actions` | Quick-action customization | **Implemented** | Users can show/hide the Browse files, Rules and Storage quick actions; arbitrary shortcut reassignment is not included. |
| `bk_presets` | Import and export presets | **Partial** | Rule templates exist; a polished preset interchange UI is not complete. |

## Search, intelligence and productivity

| ID | Feature | Status | Notes |
|---|---|---|---|
| `pr_smart` | Smart folders | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pr_tags` | Custom tags | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pr_collections` | Collections | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pr_duplicate` | Duplicate-aware browsing | **Partial** | Duplicates are grouped in Storage Tools; inline duplicate badges in every file view are not implemented. |
| `pr_recent` | Recent activity feed | **Partial** | Recent URIs are available; a complete event-based activity feed for every operation is not implemented. |
| `pr_rulesuggest` | Rule suggestions | **Partial** | Preset templates provide starting points; automatic behavioral rule suggestions are not implemented. |
| `pr_batch` | Batch file naming templates | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pr_hash` | Checksum tools | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pr_compare` | File comparison | **Partial** | SHA-256 and file-comparison helpers exist, but a rich side-by-side text diff UI is not included. |
| `pr_bookmarks` | Folder bookmarks | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |

## Advanced Android integration

| ID | Feature | Status | Notes |
|---|---|---|---|
| `an_intents` | Android document integration | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `an_downloads` | Downloads integration | **Partial** | Users can authorize Downloads or another folder with SAF; the app does not bypass Android's storage permission model. |
| `an_shortcuts` | Home-screen shortcuts | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `an_widget` | Home-screen widget | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `an_notification` | Notification controls | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `an_battery` | Battery-aware scheduling | **Partial** | WorkManager battery constraints are configurable; the app does not guarantee exemption from OEM battery restrictions. |
| `an_saf` | SAF permission recovery | **Partial** | The app reports revoked folder access and allows reauthorization; automated permission repair is not possible. |
| `an_reboot` | Reboot recovery | **Partial** | WorkManager persists eligible work across process/device restarts by design; reboot behavior has not been device-tested. |
| `an_storage` | External storage support | **Partial** | SD/USB access depends on the selected document provider and granted tree URI. |

## Performance and reliability

| ID | Feature | Status | Notes |
|---|---|---|---|
| `pf_lowram` | Low-memory mode | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pf_lazy` | Lazy file lists | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pf_cache` | Configurable cache | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pf_db` | Efficient local database | **Partial** | Metadata/settings/queue use DataStore JSON; Room/SQLite indexing has not been introduced. |
| `pf_errors` | Clear error explanations | **Partial** | Common errors have human-readable messages; diagnostics are not yet comprehensive across providers. |
| `pf_tests` | Automated regression tests | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pf_ci` | Build and CI checks | **Implemented** | Integrated into the source project; see UI and code path for platform-specific limitations. |
| `pf_logs` | Diagnostic export | **Partial** | Storage reports can export CSV; a privacy-scrubbed full diagnostic bundle is incomplete. |
| `pf_crash` | Crash recovery | **Partial** | WorkManager re-enqueues durable work, but interrupted running transfers restart from the beginning on retry. |
| `pf_bench` | Performance diagnostics | **Partial** | Storage scans report elapsed time, files/second and approximate JVM heap usage; this is a lightweight diagnostic, not a controlled benchmark suite. |

## Required validation before calling the release complete

1. Run `gradle testDebugUnitTest`, `gradle lintDebug`, and `gradle assembleDebug` in AndroidForge/GitHub Actions.
2. Install on Android 10/API 29 and test SAF reads/writes with small test files before using personal files.
3. Test queue cancellation, concurrency, permission revocation, low storage, encrypted ZIP passwords, malformed ZIP/TAR.GZ inputs, and backup restore.
4. Inspect the CI test/lint reports and fix each reported failure before publishing.

## Release guardrails

- Automatic organization only acts on rules the user enables and folders the user authorizes.
- Duplicate scans are read-only; no duplicate is automatically deleted.
- Settings backups do not include file contents, vault items, or the app PIN; backup export warns that URI references/history may be sensitive.
- WorkManager periodic intervals are best-effort and may be delayed by Android power management.
- Password-protected ZIP uses Zip4j AES encryption. The local vault is separate and uses Android Keystore-backed encryption.
