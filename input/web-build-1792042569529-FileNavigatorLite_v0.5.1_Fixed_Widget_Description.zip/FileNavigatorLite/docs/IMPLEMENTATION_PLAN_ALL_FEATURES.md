# Full selected-feature implementation plan

The user selected all listed features and prefers a single major release with balanced performance. Because this selection spans a full file manager, background scheduler, transfer engine, media player, archive suite, encrypted vault, widgets and security features, a single untested code drop would be unsafe. Keep one release branch, but implement and validate feature groups in dependency order before calling it complete.

## Milestone gates

1. **File UX and domain layer** — advanced query/filter model, sorting, hidden-file preference, bookmarks/favorites/recent activity, multi-operation planning, batch rename preview, file metadata, share/open intents. Gate: pure unit tests and SAF permission tests.
2. **Durable operations engine** — Room/SQLite-backed queue state, worker orchestration, per-item states, retry/cancel, honest pause/resume semantics, conflict policy, verification and undo metadata. Gate: restart/reboot recovery tests and simulated provider failures.
3. **Preview and archives** — image viewer/gallery, bounded text/code viewer, PDF implementation selected after dependency review, Media3 audio/video, archive browser, ZIP/TAR/GZIP and password support only through vetted libraries, thumbnail cache. Gate: malformed/oversized input tests and low-memory device tests.
4. **Storage intelligence** — cancellable scans, exclusions, category totals, largest/old files, exact duplicate hashes, optional perceptual image matching, export report and reviewed cleanup. Gate: never delete automatically; scan cancellation and SAF errors tested.
5. **Automation policies** — rule templates, multiple rules, dry run, priority, time windows, battery/network constraints, notifications, retry/backoff and access recovery. File-system observers are best effort and periodic WorkManager remains fallback; exact intervals are not guaranteed.
6. **Material 3 Expressive and adaptive UI** — dynamic/fixed palettes, system/light/dark/AMOLED, motion reduction, compact mode, responsive layouts, accessible labels and haptics. Gate: screenshots at small screen sizes, TalkBack and animation-off tests.
7. **Privacy, backup and Android integration** — encrypted vault with Keystore-backed key management, app lock, timeout, recycle bin semantics, protected export, versioned backup/restore preview, shortcuts/widgets and SAF recovery. Gate: security review and no plaintext key storage.
8. **Release hardening** — diagnostic export with redaction, crash recovery, low-RAM limits, benchmark fixtures, CI unit tests/lint/build, APK artifact and manual Android 10+ tests.

## Release acceptance checklist

- All supported file operations handle missing permission, provider failures, full storage and filename conflicts without crashing.
- No destructive operation is silently triggered by a scan or rule suggestion.
- Large file lists use paging/lazy rendering; hashes and media decoding run off the main thread and are cancellable where possible.
- User settings and queue state survive process death; imported backups are validated and versioned.
- CI builds APK, unit tests pass, lint findings are reviewed, and an Android 10+ low-memory device is tested.
- The release notes distinguish implemented, partially implemented and deferred items.
