# File Navigator Lite 0.3.0 milestone

## Implemented in source
- In-app image preview for common image MIME types/extensions. Images are decoded with downsampling to reduce memory pressure on low-end devices.
- In-app UTF-8 text/code preview, capped at 256 KiB to avoid loading huge files into memory.
- "Open with…" action delegates to installed Android handlers.
- Preview type routing and JVM unit tests for image, text, PDF, audio, video, archive, APK and unknown file types.
- Storage analyzer screen continues to expose category totals, largest files, exact duplicates and skipped-item counts.
- Existing multi-file copy/move uses the existing sequential operation plan and activity history.

## Not yet implemented
- A persistent, user-visible transfer queue with per-item progress, pause/resume and cancel.
- Native PDF rendering, native audio/video playback, archive browsing preview, and APK metadata preview. Those types use existing tools or Android external handlers.
- Storage scan cancellation and incremental indexing.

## Validation status
- Source ZIP integrity checked after packaging.
- Android compilation, lint, JVM tests, and device testing have not been run in this environment. Run the included GitHub Actions workflow before installing.
