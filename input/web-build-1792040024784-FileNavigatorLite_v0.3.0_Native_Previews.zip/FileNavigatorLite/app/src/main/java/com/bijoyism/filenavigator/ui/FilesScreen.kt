package com.bijoyism.filenavigator.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Dialog
import androidx.compose.material3.Surface
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bijoyism.filenavigator.domain.FileEntry
import com.bijoyism.filenavigator.domain.Rule
import com.bijoyism.filenavigator.domain.SortKey
import com.bijoyism.filenavigator.domain.filterAndSort
import com.bijoyism.filenavigator.util.formatDate
import com.bijoyism.filenavigator.util.formatSize
import com.bijoyism.filenavigator.util.openFile
import com.bijoyism.filenavigator.util.shareFiles
import com.bijoyism.filenavigator.preview.PreviewType
import com.bijoyism.filenavigator.preview.previewType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private sealed interface FileDialog {
    object NewFolder : FileDialog
    object ConfirmDelete : FileDialog
    object ApplyRule : FileDialog
    class Rename(val entry: FileEntry) : FileDialog
    class Details(val entry: FileEntry) : FileDialog
}

private fun iconFor(entry: FileEntry): String {
    val mime = entry.mimeType.orEmpty()
    return when {
        entry.isDirectory -> "📁"
        mime.startsWith("image/") -> "🖼"
        mime.startsWith("video/") -> "🎞"
        mime.startsWith("audio/") -> "🎵"
        mime == "application/pdf" -> "📕"
        entry.name.endsWith(".apk", ignoreCase = true) -> "📦"
        mime.contains("zip") || mime.contains("compressed") -> "🗜"
        mime.startsWith("text/") -> "📄"
        else -> "📃"
    }
}

private fun subtitle(context: Context, entry: FileEntry): String {
    if (entry.isDirectory) return "Folder"
    val parts = mutableListOf<String>()
    if (entry.size >= 0) parts.add(formatSize(context, entry.size))
    if (entry.lastModified > 0) parts.add(formatDate(entry.lastModified))
    return parts.joinToString(" · ")
}

@Composable
fun FilesScreen(vm: FilesViewModel, rules: List<Rule>) {
    val s by vm.state.collectAsState()
    val context = LocalContext.current
    var query by rememberSaveable { mutableStateOf("") }
    var moving by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<FileDialog?>(null) }
    var previewEntry by remember { mutableStateOf<FileEntry?>(null) }
    val addFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) vm.grant(uri) }
    val pickDestination = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) vm.grantAndTransfer(uri, moving) }
    BackHandler(enabled = s.stack.isNotEmpty()) { vm.up() }

    val sorted = remember(s.entries, s.query, s.sort) { s.entries.filterAndSort(s.query, s.sort) }
    val shown = sorted.take(s.shown)

    fun open(entry: FileEntry) {
        when {
            s.selecting -> vm.toggle(entry.uri)
            entry.isDirectory -> vm.enter(entry)
            previewType(entry.name, entry.mimeType) in setOf(PreviewType.IMAGE, PreviewType.TEXT) -> previewEntry = entry
            !openFile(context, entry) -> Toast.makeText(context, "No app can open this file", Toast.LENGTH_SHORT).show()
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (s.stack.isEmpty()) {
            RootsView(s.roots, vm::labelOf, vm::openRoot) { addFolder.launch(null) }
        } else {
            Column(Modifier.fillMaxSize()) {
                Breadcrumbs(s.stack.map { it.name }, vm::navigateTo)
                OutlinedTextField(
                    value = query,
                    onValueChange = {
                        query = it
                        vm.setQuery(it)
                    },
                    label = { Text("Search this folder") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                )
                Toolbar(s.sort, s.grid, s.selecting, vm) { dialog = FileDialog.NewFolder }
                if (s.selecting) {
                    SelectionBar(
                        count = s.selected.size,
                        single = s.selected.size == 1,
                        onSelectAll = { vm.selectAll(shown.map { it.uri }) },
                        onCopy = {
                            moving = false
                            pickDestination.launch(null)
                        },
                        onMove = {
                            moving = true
                            pickDestination.launch(null)
                        },
                        onDelete = { dialog = FileDialog.ConfirmDelete },
                        onRename = { vm.selectedEntries().firstOrNull()?.let { dialog = FileDialog.Rename(it) } },
                        onDetails = { vm.selectedEntries().firstOrNull()?.let { dialog = FileDialog.Details(it) } },
                        onShare = {
                            if (!shareFiles(context, vm.selectedEntries())) Toast.makeText(context, "Select at least one file to share", Toast.LENGTH_SHORT).show()
                        },
                        onApplyRule = { dialog = FileDialog.ApplyRule }
                    )
                }
                when {
                    s.error != null -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(s.error.orEmpty(), color = MaterialTheme.colorScheme.error)
                        Button(onClick = { vm.reload() }) { Text("Retry") }
                    }
                    !s.loading && s.entries.isEmpty() -> CenterMessage("This folder is empty.")
                    !s.loading && sorted.isEmpty() -> CenterMessage("No files match your search.")
                    s.grid -> LazyVerticalGrid(columns = GridCells.Adaptive(104.dp), modifier = Modifier.fillMaxSize()) {
                        items(shown, key = { it.uri }) { e ->
                            Column(
                                Modifier.clickable { open(e) }.padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                if (s.selecting) Checkbox(checked = e.uri in s.selected, onCheckedChange = { vm.toggle(e.uri) })
                                Text(iconFor(e), fontSize = 32.sp)
                                Text(e.name, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        if (sorted.size > shown.size) {
                            item(span = { GridItemSpan(maxLineSpan) }) {
                                TextButton(onClick = { vm.loadMore() }) { Text("Load more (${sorted.size - shown.size} more)") }
                            }
                        }
                    }
                    else -> LazyColumn(Modifier.fillMaxSize()) {
                        items(shown, key = { it.uri }) { e ->
                            Row(
                                Modifier.fillMaxWidth().heightIn(min = 56.dp).clickable { open(e) }.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (s.selecting) Checkbox(checked = e.uri in s.selected, onCheckedChange = { vm.toggle(e.uri) })
                                Text(iconFor(e), fontSize = 24.sp)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(e.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                                    Text(subtitle(context, e), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                        if (sorted.size > shown.size) {
                            item { TextButton(onClick = { vm.loadMore() }) { Text("Load more (${sorted.size - shown.size} more)") } }
                        }
                    }
                }
            }
        }
        if (s.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
    }

    previewEntry?.let { entry ->
        FilePreviewDialog(entry = entry, onDismiss = { previewEntry = null }, onOpenExternally = {
            previewEntry = null
            if (!openFile(context, entry)) Toast.makeText(context, "No app can open this file", Toast.LENGTH_SHORT).show()
        })
    }

    when (val d = dialog) {
        null -> Unit
        FileDialog.NewFolder -> NameDialog(
            title = "New folder",
            initial = "",
            confirmLabel = "Create",
            onConfirm = {
                vm.createFolder(it)
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        FileDialog.ConfirmDelete -> ConfirmDialog(
            title = "Delete ${s.selected.size} item(s)?",
            text = "Deleted items cannot be recovered by this app.",
            confirmLabel = "Delete",
            onConfirm = {
                vm.deleteSelected()
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        FileDialog.ApplyRule -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Apply a rule to selected files") },
            text = {
                Column {
                    if (rules.isEmpty()) Text("Create a rule in the Automation tab first.")
                    rules.forEach { r ->
                        TextButton(onClick = {
                            vm.applyRule(r)
                            dialog = null
                        }) { Text(r.name) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("Cancel") } }
        )
        is FileDialog.Rename -> NameDialog(
            title = "Rename",
            initial = d.entry.name,
            confirmLabel = "Rename",
            onConfirm = {
                vm.rename(d.entry, it)
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        is FileDialog.Details -> MessageDialog(
            "Details",
            "Name: ${d.entry.name}\nSize: ${if (d.entry.size >= 0) formatSize(context, d.entry.size) else "unknown"}\nType: ${d.entry.mimeType ?: "unknown"}\nModified: ${if (d.entry.lastModified > 0) formatDate(d.entry.lastModified) else "unknown"}"
        ) { dialog = null }
    }
    s.message?.let { MessageDialog("Result", it) { vm.dismissMessage() } }
}

@Composable
private fun RootsView(roots: List<String>, label: (String) -> String, onOpen: (String) -> Unit, onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Files", style = MaterialTheme.typography.headlineSmall)
        if (roots.isEmpty()) {
            Text("Android 10 only lets apps use folders you pick. Choose a folder (for example Download) to browse and organize it.", style = MaterialTheme.typography.bodyMedium)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(roots, key = { it }) { root ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(root) }) {
                    Text("📁  ${label(root)}", Modifier.padding(16.dp), style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
        Button(onClick = onAdd) { Text("Add folder") }
    }
}

@Composable
private fun Breadcrumbs(names: List<String>, onClick: (Int) -> Unit) {
    LazyRow(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
        itemsIndexed(names) { index, name ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { onClick(index) }) { Text(name, maxLines = 1) }
                if (index < names.lastIndex) Text("›")
            }
        }
    }
}

@Composable
private fun Toolbar(sort: SortKey, grid: Boolean, selecting: Boolean, vm: FilesViewModel, onNewFolder: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box {
            TextButton(onClick = { menu = true }) { Text("Sort: ${sort.name.lowercase()}") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                SortKey.entries.forEach { key ->
                    DropdownMenuItem(
                        text = { Text(key.name.lowercase()) },
                        onClick = {
                            vm.setSort(key)
                            menu = false
                        }
                    )
                }
            }
        }
        TextButton(onClick = { vm.toggleGrid() }) { Text(if (grid) "List view" else "Grid view") }
        TextButton(onClick = { vm.toggleSelecting() }) { Text(if (selecting) "Cancel select" else "Select") }
        TextButton(onClick = onNewFolder) { Text("New folder") }
        TextButton(onClick = { vm.reload() }) { Text("Refresh") }
    }
}

@Composable
private fun SelectionBar(
    count: Int,
    single: Boolean,
    onSelectAll: () -> Unit,
    onCopy: () -> Unit,
    onMove: () -> Unit,
    onDelete: () -> Unit,
    onRename: () -> Unit,
    onDetails: () -> Unit,
    onShare: () -> Unit,
    onApplyRule: () -> Unit
) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("$count selected", Modifier.padding(horizontal = 8.dp), style = MaterialTheme.typography.labelLarge)
        TextButton(onClick = onSelectAll) { Text("All") }
        TextButton(onClick = onCopy, enabled = count > 0) { Text("Copy to…") }
        TextButton(onClick = onMove, enabled = count > 0) { Text("Move to…") }
        TextButton(onClick = onDelete, enabled = count > 0) { Text("Delete") }
        TextButton(onClick = onRename, enabled = single) { Text("Rename") }
        TextButton(onClick = onDetails, enabled = single) { Text("Details") }
        TextButton(onClick = onShare, enabled = count > 0) { Text("Share") }
        TextButton(onClick = onApplyRule, enabled = count > 0) { Text("Apply rule") }
    }
}


@Composable
private fun FilePreviewDialog(entry: FileEntry, onDismiss: () -> Unit, onOpenExternally: () -> Unit) {
    val context = LocalContext.current
    val type = previewType(entry.name, entry.mimeType)
    var textContent by remember(entry.uri) { mutableStateOf<String?>(null) }
    var imageBitmap by remember(entry.uri) { mutableStateOf<android.graphics.Bitmap?>(null) }
    var loadError by remember(entry.uri) { mutableStateOf<String?>(null) }

    LaunchedEffect(entry.uri, type) {
        withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openInputStream(Uri.parse(entry.uri))?.use { stream ->
                    when (type) {
                        PreviewType.TEXT -> {
                            val bytes = ByteArray(256 * 1024 + 1)
                            val count = stream.read(bytes).coerceAtLeast(0)
                            String(bytes, 0, count.coerceAtMost(256 * 1024), Charsets.UTF_8)
                        }
                        PreviewType.IMAGE -> {
                            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            BitmapFactory.decodeStream(stream, null, bounds)
                            val sample = maxOf(1, maxOf(bounds.outWidth, bounds.outHeight) / 1600)
                            val options = BitmapFactory.Options().apply { inSampleSize = sample }
                            context.contentResolver.openInputStream(Uri.parse(entry.uri))?.use { imageStream ->
                                BitmapFactory.decodeStream(imageStream, null, options)
                            }
                        }
                        else -> null
                    }
                } ?: error("The file could not be read")
            }.onSuccess { value ->
                when (value) {
                    is String -> textContent = value
                    is android.graphics.Bitmap -> imageBitmap = value
                    else -> loadError = "No preview is available for this file."
                }
            }.onFailure { loadError = it.message ?: "Unable to preview this file." }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = MaterialTheme.shapes.extraLarge, tonalElevation = 6.dp, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(entry.name, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${formatSize(context, entry.size)} · ${type.name.lowercase().replaceFirstChar { it.uppercase() }} preview", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                when (type) {
                    PreviewType.IMAGE -> {
                        val bitmap = imageBitmap
                        if (bitmap != null) Image(bitmap.asImageBitmap(), contentDescription = entry.name, modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp), contentScale = ContentScale.Fit)
                        else if (loadError == null) LinearProgressIndicator(Modifier.fillMaxWidth())
                    }
                    PreviewType.TEXT -> {
                        val content = textContent
                        if (content != null) Text(content, modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp).verticalScroll(rememberScrollState()), fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
                        else if (loadError == null) LinearProgressIndicator(Modifier.fillMaxWidth())
                    }
                    else -> Unit
                }
                loadError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (type == PreviewType.TEXT && (textContent?.length ?: 0) >= 256 * 1024) Text("Preview limited to the first 256 KB.", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = onDismiss) { Text("Close") }
                    Spacer(Modifier.weight(1f))
                    Button(onClick = onOpenExternally) { Text("Open with…") }
                }
            }
        }
    }
}
