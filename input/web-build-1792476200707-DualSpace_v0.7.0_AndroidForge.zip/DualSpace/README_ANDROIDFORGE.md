# DualSpace v0.7.0 — AndroidForge source project

## Version
- App: DualSpace
- Version: 0.7.0 (versionCode 7)
- Package: `com.jo.dualspace`
- Kotlin + XML
- minSdk 26 (Android 8.0+), targetSdk 29

## v0.7.0 changes
- Home edit mode with a visible Edit/Done control.
- Reorder apps using long-press drag-and-drop or edit-mode tap-to-move.
- Orientation-specific app order remains stored separately.
- Added a reset app order option for the current orientation.
- Keeps the uploaded DualSpace icon, searchable grid app drawer, separate wallpapers/favourites, folders, built-in battery/date cards and minute-updating clock.

## Build
Import the ZIP into AndroidForge as an Android/Gradle project, select the `app` module, and build a debug APK. Install and test on the target phone before setting it as the default launcher.

## Notes
This is a source project, not a precompiled APK. It has not been compiled or runtime-tested in this environment. Native drag-and-drop and touch timing may need adjustment after testing on the actual AndroidForge toolchain and Redmi 9i. Built-in cards are in-app widgets, not third-party AppWidgetHost widgets.
