package com.jo.dualspace

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipDescription
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.View.DragEvent
import android.view.animation.AlphaAnimation
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var wallpaper: ImageView
    private lateinit var appGrid: GridLayout
    private lateinit var dock: LinearLayout
    private lateinit var widgetStrip: LinearLayout
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var greeting: TextView
    private lateinit var sectionTitle: TextView
    private lateinit var searchInput: EditText
    private val clockHandler = Handler(Looper.getMainLooper())
    private val clockTick = object : Runnable { override fun run() { if (::clock.isInitialized) updateClockAndDate(); clockHandler.postDelayed(this, 60_000L) } }
    private var downX = 0f
    private var downY = 0f
    private var drawerDialog: AlertDialog? = null
    private val prefs by lazy { getSharedPreferences("dualspace_settings", MODE_PRIVATE) }
    private val isLandscape: Boolean
        get() = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    private data class Folder(val id: String, var name: String, val packages: MutableList<String>)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        wallpaper = findViewById(R.id.wallpaper)
        appGrid = findViewById(R.id.appGrid)
        dock = findViewById(R.id.dock)
        widgetStrip = findViewById(R.id.widgetStrip)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        greeting = findViewById(R.id.greeting)
        sectionTitle = findViewById(R.id.sectionTitle)
        searchInput = findViewById(R.id.searchInput)

        updateClockAndDate()
        clockHandler.postDelayed(clockTick, 60_000L)
        applyProfile()
        renderHome()
        setupGestures()
        findViewById<View>(R.id.root).setOnLongClickListener { showSettings(); true }
        findViewById<View>(R.id.searchBar).setOnClickListener { showDrawer(searchInput.text.toString()) }
        findViewById<View>(R.id.manageApps).setOnClickListener { showHomeEditor() }
        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                showDrawer(searchInput.text.toString())
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(searchInput.windowToken, 0)
                true
            } else false
        }
        searchInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderHome() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    override fun onResume() {
        super.onResume()
        if (::clock.isInitialized) updateClockAndDate()
        if (::appGrid.isInitialized) renderHome()
    }

    override fun onDestroy() {
        clockHandler.removeCallbacks(clockTick)
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        applyProfile()
        renderHome()
    }

    private fun key(name: String) = "${if (isLandscape) "landscape" else "portrait"}_$name"

    private fun updateClockAndDate() {
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        date.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)
    }

    private fun applyProfile() {
        greeting.text = if (isLandscape) "LANDSCAPE SPACE" else "PORTRAIT SPACE"
        appGrid.columnCount = if (isLandscape) 6 else 4
        sectionTitle.text = if (isLandscape) "Quick launch" else "Favourites"
        val uriText = prefs.getString(key("wallpaper"), null)
        if (uriText != null) {
            try { wallpaper.setImageURI(Uri.parse(uriText)) } catch (_: Exception) { wallpaper.setImageDrawable(null) }
        } else {
            wallpaper.setImageDrawable(null)
            wallpaper.setBackgroundColor(if (isLandscape) Color.rgb(228, 237, 250) else Color.rgb(247, 248, 252))
        }
        findViewById<View>(R.id.content).startAnimation(AlphaAnimation(0.9f, 1f).apply { duration = 180 })
    }

    private fun allApps(): List<ResolveInfo> {
        val pm = packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase(Locale.getDefault()) }
    }

    private fun favourites(): MutableList<String> =
        prefs.getString(key("favourites"), "")!!.split("|").filter { it.isNotBlank() }.toMutableList()

    private fun saveOrder(order: List<String>) {
        prefs.edit().putString(key("order"), order.joinToString("|")).apply()
    }

    private fun appOrder(apps: List<ResolveInfo>): List<ResolveInfo> {
        val saved = prefs.getString(key("order"), "")!!.split("|").filter { it.isNotBlank() }
        val map = apps.associateBy { it.activityInfo.packageName }
        val ordered = saved.mapNotNull { map[it] }
        return ordered + apps.filter { it.activityInfo.packageName !in saved }
    }

    private fun folders(): MutableList<Folder> {
        val json = prefs.getString(key("folders"), "[]") ?: "[]"
        val result = mutableListOf<Folder>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                val packages = mutableListOf<String>()
                val p = o.optJSONArray("packages") ?: JSONArray()
                for (j in 0 until p.length()) packages.add(p.optString(j))
                result.add(Folder(o.optString("id"), o.optString("name", "Folder"), packages))
            }
        } catch (_: Exception) {}
        return result
    }

    private fun saveFolders(folders: List<Folder>) {
        val array = JSONArray()
        folders.forEach { folder ->
            val o = JSONObject()
            o.put("id", folder.id)
            o.put("name", folder.name)
            val packages = JSONArray()
            folder.packages.forEach { packages.put(it) }
            o.put("packages", packages)
            array.put(o)
        }
        prefs.edit().putString(key("folders"), array.toString()).apply()
    }

    private fun renderHome() {
        appGrid.removeAllViews()
        dock.removeAllViews()
        renderWidgets()
        val all = appOrder(allApps())
        val query = searchInput.text.toString().trim()
        val folderPackages = folders().flatMap { it.packages }.toSet()
        val selected: List<ResolveInfo> = if (query.isNotEmpty()) {
            all.filter { it.loadLabel(packageManager).toString().contains(query, true) }.take(24)
        } else {
            val favs = favourites().filter { pkg -> all.any { it.activityInfo.packageName == pkg } }
            val base = if (favs.isEmpty()) all.take(if (isLandscape) 12 else 8)
                       else favs.mapNotNull { pkg -> all.firstOrNull { it.activityInfo.packageName == pkg } }
            base.filter { it.activityInfo.packageName !in folderPackages }
        }
        sectionTitle.text = if (query.isNotEmpty()) "Search results" else if (isLandscape) "Quick launch" else "Favourites"

        if (query.isEmpty()) {
            folders().forEach { folder ->
                val tile = folderTile(folder)
                tile.layoutParams = tileLayoutParams()
                appGrid.addView(tile)
            }
        }
        selected.take(24).forEach { info ->
            val pkg = info.activityInfo.packageName
            val tile = appTile(info) {
                packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
            }
            tile.layoutParams = tileLayoutParams()
            tile.setOnLongClickListener { showAppActions(info); true }
            tile.setOnTouchListener { view, event ->
                if (event.action == MotionEvent.ACTION_DOWN) {
                    view.tag = System.currentTimeMillis()
                } else if (event.action == MotionEvent.ACTION_UP) {
                    val held = System.currentTimeMillis() - (view.tag as? Long ?: System.currentTimeMillis())
                    if (held > 450) {
                        val data = ClipData.newPlainText("dualspace-package", pkg)
                        view.startDragAndDrop(data, View.DragShadowBuilder(view), pkg, 0)
                        true
                    } else false
                } else if (event.action == MotionEvent.ACTION_CANCEL) false else true
            }
            appGrid.addView(tile)
        }
        appGrid.setOnDragListener { target, event ->
            when (event.action) {
                DragEvent.ACTION_DRAG_STARTED -> event.clipDescription?.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN) == true
                DragEvent.ACTION_DROP -> {
                    val fromPkg = event.localState as? String ?: event.clipData?.getItemAt(0)?.text?.toString()
                    if (fromPkg != null) {
                        val order = appOrder(allApps()).map { it.activityInfo.packageName }.toMutableList()
                        order.remove(fromPkg)
                        val targetView = target as? GridLayout
                        val index = targetView?.childCount ?: order.size
                        order.add(index.coerceIn(0, order.size), fromPkg)
                        saveOrder(order)
                        renderHome()
                        Toast.makeText(this, "Home order saved for this orientation", Toast.LENGTH_SHORT).show()
                    }
                    true
                }
                else -> true
            }
        }
        listOf("All apps", "Wallpaper", "Settings").forEach { label ->
            dock.addView(Button(this).apply {
                text = label
                textSize = 11f
                isAllCaps = false
                setTextColor(Color.rgb(48, 55, 70))
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener {
                    when (label) {
                        "All apps" -> showDrawer("")
                        "Wallpaper" -> chooseWallpaper()
                        else -> showSettings()
                    }
                }
            }, LinearLayout.LayoutParams(0, dp(42), 1f))
        }
    }

    private fun tileLayoutParams() = GridLayout.LayoutParams().apply {
        width = 0
        height = if (isLandscape) dp(76) else dp(86)
        columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
        setMargins(dp(2), dp(2), dp(2), dp(2))
    }

    private fun appTile(info: ResolveInfo, click: () -> Unit): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(4), dp(3), dp(4))
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
            addView(ImageView(this@MainActivity).apply {
                setImageDrawable(info.loadIcon(packageManager))
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = info.loadLabel(packageManager).toString()
            }, LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(TextView(this@MainActivity).apply {
                text = info.loadLabel(packageManager).toString()
                setTextColor(Color.rgb(48, 55, 70))
                textSize = 10f
                gravity = Gravity.CENTER
                maxLines = 2
                typeface = Typeface.create("sans", Typeface.NORMAL)
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(30)))
        }
    }

    private fun folderTile(folder: Folder): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(4), dp(3), dp(4))
            isClickable = true
            setOnClickListener { openFolder(folder) }
            addView(TextView(this@MainActivity).apply {
                text = "▦"
                textSize = 34f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(52, 120, 246))
            }, LinearLayout.LayoutParams(dp(42), dp(42)))
            addView(TextView(this@MainActivity).apply {
                text = folder.name
                setTextColor(Color.rgb(48, 55, 70))
                textSize = 10f
                gravity = Gravity.CENTER
                maxLines = 2
            }, LinearLayout.LayoutParams(-1, dp(30)))
            setOnLongClickListener { showFolderActions(folder); true }
        }
    }

    private fun openFolder(folder: Folder) {
        val apps = allApps().filter { it.activityInfo.packageName in folder.packages }
        AlertDialog.Builder(this).setTitle(folder.name)
            .setItems(apps.map { it.loadLabel(packageManager).toString() }.toTypedArray()) { _, which ->
                if (which in apps.indices) packageManager.getLaunchIntentForPackage(apps[which].activityInfo.packageName)?.let { startActivity(it) }
            }.setPositiveButton("Manage") { _, _ -> showFolderActions(folder) }
            .setNegativeButton("Close", null).show()
    }

    private fun showFolderActions(folder: Folder) {
        val options = arrayOf("Rename folder", "Add apps", "Delete folder")
        AlertDialog.Builder(this).setTitle(folder.name).setItems(options) { _, which ->
            when (which) {
                0 -> {
                    val input = EditText(this).apply { setText(folder.name) }
                    AlertDialog.Builder(this).setTitle("Rename folder").setView(input)
                        .setPositiveButton("Save") { _, _ ->
                            folder.name = input.text.toString().ifBlank { "Folder" }
                            saveFolders(folders().map { if (it.id == folder.id) folder else it })
                            renderHome()
                        }.setNegativeButton("Cancel", null).show()
                }
                1 -> addAppsToFolder(folder)
                2 -> {
                    saveFolders(folders().filterNot { it.id == folder.id })
                    renderHome()
                }
            }
        }.show()
    }

    private fun createFolderWithApp(info: ResolveInfo) {
        val input = EditText(this).apply { hint = "Folder name"; setText("New folder") }
        AlertDialog.Builder(this).setTitle("Create folder").setMessage("Create a folder containing ${info.loadLabel(packageManager)}.")
            .setView(input).setPositiveButton("Create") { _, _ ->
                val folder = Folder("folder_${System.currentTimeMillis()}", input.text.toString().ifBlank { "Folder" },
                    mutableListOf(info.activityInfo.packageName))
                val updated = folders()
                updated.add(folder)
                saveFolders(updated)
                val favs = favourites()
                favs.remove(info.activityInfo.packageName)
                prefs.edit().putString(key("favourites"), favs.joinToString("|")).apply()
                renderHome()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun addAppsToFolder(folder: Folder) {
        val apps = allApps()
        val checked = BooleanArray(apps.size) { apps[it].activityInfo.packageName in folder.packages }
        AlertDialog.Builder(this).setTitle("Apps in ${folder.name}")
            .setMultiChoiceItems(apps.map { it.loadLabel(packageManager).toString() }.toTypedArray(), checked) { _, which, value ->
                checked[which] = value
            }.setPositiveButton("Save") { _, _ ->
                folder.packages.clear()
                apps.indices.filter { checked[it] }.forEach { folder.packages.add(apps[it].activityInfo.packageName) }
                saveFolders(folders().map { if (it.id == folder.id) folder else it })
                val favs = favourites().filterNot { it in folder.packages }
                prefs.edit().putString(key("favourites"), favs.joinToString("|")).apply()
                renderHome()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showAppActions(info: ResolveInfo) {
        val pkg = info.activityInfo.packageName
        val current = favourites()
        val isFav = current.contains(pkg)
        val options = arrayOf(if (isFav) "Remove from favourites" else "Add to favourites", "Create folder with app", "App info", "Launch")
        AlertDialog.Builder(this).setTitle(info.loadLabel(packageManager).toString())
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        if (isFav) current.remove(pkg) else current.add(pkg)
                        prefs.edit().putString(key("favourites"), current.joinToString("|")).apply()
                        renderHome()
                    }
                    1 -> createFolderWithApp(info)
                    2 -> startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
                    3 -> packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
                }
            }.show()
    }

    private fun renderWidgets() {
        widgetStrip.removeAllViews()
        val enabled = prefs.getString(key("widgets"), "battery|agenda")!!.split("|").filter { it.isNotBlank() }
        if (enabled.isEmpty()) {
            widgetStrip.visibility = View.GONE
            return
        }
        widgetStrip.visibility = View.VISIBLE
        enabled.forEach { widget ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(8), dp(12), dp(8))
                background = getDrawable(R.drawable.widget_card_bg)
            }
            val title = TextView(this).apply {
                textSize = 10f
                setTextColor(Color.rgb(100, 110, 130))
            }
            val value = TextView(this).apply {
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(35, 42, 58))
            }
            if (widget == "battery") {
                title.text = "BATTERY"
                val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
                value.text = "${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%"
            } else {
                title.text = "TODAY"
                value.text = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date())
            }
            card.addView(title)
            card.addView(value)
            val lp = LinearLayout.LayoutParams(0, dp(58), 1f)
            lp.setMargins(dp(3), 0, dp(3), 0)
            widgetStrip.addView(card, lp)
        }
    }


    private fun showDrawer(initialQuery: String) {
        val apps = appOrder(allApps())
        val input = EditText(this).apply {
            hint = "Search installed apps"
            setText(initialQuery)
            setSingleLine(true)
            textSize = 15f
        }
        val grid = GridLayout(this).apply {
            columnCount = if (isLandscape) 6 else 4
            useDefaultMargins = false
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        val scroll = android.widget.ScrollView(this).apply {
            isFillViewport = true
            addView(grid)
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(4))
            addView(input, LinearLayout.LayoutParams(-1, dp(48)))
            addView(scroll, LinearLayout.LayoutParams(-1, dp(400)))
        }
        var filtered: List<ResolveInfo> = apps
        fun refresh(q: String) {
            grid.removeAllViews()
            filtered = apps.filter { it.loadLabel(packageManager).toString().contains(q, true) }
            filtered.forEach { info ->
                val tile = appTile(info) {
                    packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)?.let { startActivity(it) }
                    drawerDialog?.dismiss()
                }
                tile.layoutParams = tileLayoutParams()
                tile.setOnLongClickListener { showAppActions(info); true }
                grid.addView(tile)
            }
        }
        refresh(initialQuery)
        drawerDialog = AlertDialog.Builder(this)
            .setTitle("All apps")
            .setView(container)
            .setNegativeButton("Close", null)
            .create()
        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { refresh(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        drawerDialog?.show()
    }

    private fun showHomeEditor() {
        val options = arrayOf("Choose favourite apps", "Manage folders", "Choose built-in widgets")
        AlertDialog.Builder(this).setTitle("Edit home screen").setItems(options) { _, which ->
            when (which) {
                0 -> showFavouritePicker()
                1 -> manageFolders()
                2 -> chooseWidgets()
            }
        }.show()
    }

    private fun showFavouritePicker() {
        val apps = appOrder(allApps())
        val favs = favourites().toSet()
        val labels = apps.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        val checked = BooleanArray(apps.size) { apps[it].activityInfo.packageName in favs }
        AlertDialog.Builder(this).setTitle("Choose home apps")
            .setMultiChoiceItems(labels, checked) { _, which, value -> checked[which] = value }
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString(key("favourites"), apps.indices.filter { checked[it] }
                    .map { apps[it].activityInfo.packageName }.joinToString("|")).apply()
                renderHome()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun manageFolders() {
        val existing = folders()
        val options = arrayOf("Create a folder from an app", "Manage existing folders")
        AlertDialog.Builder(this).setTitle("Folders").setItems(options) { _, which ->
            if (which == 0) {
                val apps = allApps()
                AlertDialog.Builder(this).setTitle("Choose first app")
                    .setItems(apps.map { it.loadLabel(packageManager).toString() }.toTypedArray()) { _, index ->
                        if (index in apps.indices) createFolderWithApp(apps[index])
                    }.show()
            } else if (existing.isEmpty()) {
                Toast.makeText(this, "No folders created yet", Toast.LENGTH_SHORT).show()
            } else {
                AlertDialog.Builder(this).setTitle("Choose folder")
                    .setItems(existing.map { it.name }.toTypedArray()) { _, index ->
                        if (index in existing.indices) showFolderActions(existing[index])
                    }.show()
            }
        }.show()
    }

    private fun chooseWidgets() {
        val options = arrayOf("Battery widget", "Today widget")
        val current = prefs.getString(key("widgets"), "battery|agenda")!!.split("|").toMutableSet()
        val checked = BooleanArray(2) { (if (it == 0) "battery" else "agenda") in current }
        AlertDialog.Builder(this).setTitle("Built-in widgets")
            .setMultiChoiceItems(options, checked) { _, which, value -> checked[which] = value }
            .setPositiveButton("Save") { _, _ ->
                val selected = mutableListOf<String>()
                if (checked[0]) selected.add("battery")
                if (checked[1]) selected.add("agenda")
                prefs.edit().putString(key("widgets"), selected.joinToString("|")).apply()
                renderWidgets()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun chooseWallpaper() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }, REQUEST_WALLPAPER)
    }

    @Deprecated("Compatibility with target Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_WALLPAPER && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.edit().putString(key("wallpaper"), uri.toString()).apply()
            applyProfile()
            Toast.makeText(this, "Wallpaper saved for this orientation", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSettings() {
        val options = arrayOf("Set wallpaper for this orientation", "Edit home screen", "About DualSpace")
        AlertDialog.Builder(this).setTitle("Home settings").setItems(options) { _, which ->
            when (which) {
                0 -> chooseWallpaper()
                1 -> showHomeEditor()
                2 -> AlertDialog.Builder(this).setTitle("DualSpace 0.5.0")
                    .setMessage("Orientation-aware launcher with saved app ordering, folders and built-in widgets.")
                    .setPositiveButton("OK", null).show()
            }
        }.setNegativeButton("Close", null).show()
    }

    private fun setupGestures() {
        findViewById<View>(R.id.root).setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.x; downY = event.y; true }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    if (abs(dy) > dp(90) && abs(dy) > abs(dx) * 1.2f) {
                        if (dy < 0) showDrawer("") else showSettings()
                        true
                    } else if (abs(dx) > dp(100) && abs(dx) > abs(dy) * 1.2f) {
                        if (dx < 0) showSettings() else showDrawer("")
                        true
                    } else false
                }
                else -> false
            }
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    companion object { private const val REQUEST_WALLPAPER = 410 }
}
