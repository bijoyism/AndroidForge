package com.jo.dualspace

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.app.SearchManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.text.format.DateFormat
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

internal enum class Cat(val title: String, val icon: Int) {
    ALL("All apps", R.drawable.ic_apps),
    GAMES("Games", R.drawable.ic_games),
    SOCIAL("Social", R.drawable.ic_social),
    INTERNET("Internet", R.drawable.ic_public),
    MEDIA("Multimedia", R.drawable.ic_media),
    PRODUCTIVITY("Productivity", R.drawable.ic_work),
    TOOLS("Tools", R.drawable.ic_tools),
    SETTINGS("Settings", R.drawable.ic_tune),
    OTHER("Other", R.drawable.ic_more)
}

internal class AppEntry(
    val pkg: String,
    val label: String,
    val icon: Drawable,
    val component: ComponentName,
    val cat: Cat,
    val system: Boolean
)

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var wallpaper: ImageView
    private lateinit var scrimTop: View
    private lateinit var scrimBottom: View
    private lateinit var content: LinearLayout
    private lateinit var searchBar: LinearLayout
    private lateinit var micButton: ImageView
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var battery: TextView
    private lateinit var appGrid: GridLayout
    private lateinit var handle: ImageView
    private lateinit var dock: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var categoryTitle: TextView
    private lateinit var appList: GridView
    private lateinit var categoryBar: LinearLayout
    private lateinit var homeDetector: GestureDetector
    private lateinit var drawerDetector: GestureDetector

    private val adapter = AppAdapter()
    private var apps: List<AppEntry> = emptyList()
    private var currentCat = Cat.ALL
    private var topInset = 0
    private var bottomInset = 0

    private val prefs by lazy { getSharedPreferences("dualspace_settings", MODE_PRIVATE) }
    private val isLandscape: Boolean
        get() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    private val timeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { updateClock() }
    }
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { loadAppsAsync() }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        root = findViewById(R.id.root)
        wallpaper = findViewById(R.id.wallpaper)
        scrimTop = findViewById(R.id.scrimTop)
        scrimBottom = findViewById(R.id.scrimBottom)
        content = findViewById(R.id.content)
        searchBar = findViewById(R.id.searchBar)
        micButton = findViewById(R.id.micButton)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        battery = findViewById(R.id.battery)
        appGrid = findViewById(R.id.appGrid)
        handle = findViewById(R.id.handle)
        dock = findViewById(R.id.dock)
        drawer = findViewById(R.id.drawer)
        searchInput = findViewById(R.id.searchInput)
        categoryTitle = findViewById(R.id.categoryTitle)
        appList = findViewById(R.id.appList)
        categoryBar = findViewById(R.id.categoryBar)

        clock.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        date.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        battery.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)

        appList.adapter = adapter
        buildCategoryBar()
        setupInsets()
        setupInteractions()
        applyProfile()
        loadAppsAsync()

        registerReceiver(packageReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        })
    }

    override fun onResume() {
        super.onResume()
        updateClock()
        registerReceiver(timeReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        })
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(timeReceiver) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(packageReceiver) } catch (_: Exception) {}
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) closeDrawer()
    }

    override fun onBackPressed() {
        if (drawer.visibility == View.VISIBLE) closeDrawer()
        // A launcher never finishes on Back.
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyProfile()
        root.requestApplyInsets()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        homeDetector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ------------------------------------------------------------------ setup

    @Suppress("DEPRECATION")
    private fun setupInsets() {
        root.setOnApplyWindowInsetsListener { _, insets ->
            topInset = insets.systemWindowInsetTop
            bottomInset = insets.systemWindowInsetBottom
            applyInsets()
            insets
        }
        root.requestApplyInsets()
    }

    private fun applyInsets() {
        content.setPadding(0, topInset, 0, bottomInset + dp(8))
        drawer.setPadding(0, topInset, 0, bottomInset)
        scrimTop.layoutParams = scrimTop.layoutParams.also { it.height = topInset + dp(170) }
        scrimBottom.layoutParams = scrimBottom.layoutParams.also { it.height = bottomInset + dp(240) }
    }

    private fun setupInteractions() {
        homeDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (drawer.visibility == View.VISIBLE || e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(dy) > dp(80) && abs(dy) > abs(dx) * 1.3f) {
                    if (dy < 0) openDrawer(false) else expandNotifications()
                    return true
                }
                return false
            }
        }).apply { setIsLongpressEnabled(false) }

        drawerDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (searchInput.hasFocus()) hideKeyboard()
                return false
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (abs(velocityX) > abs(velocityY) * 1.5f && abs(velocityX) > 900f) {
                    if (searchInput.text.isNullOrEmpty()) shiftCategory(if (velocityX < 0) 1 else -1)
                    return true
                }
                if (velocityY > 2200f && gridAtTop()) {
                    closeDrawer()
                    return true
                }
                return false
            }
        })

        root.setOnLongClickListener { showSettings(); true }
        searchBar.setOnClickListener { openDrawer(true) }
        micButton.setOnClickListener {
            try {
                startActivity(Intent(RecognizerIntent.ACTION_WEB_SEARCH).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
                Toast.makeText(this, "Voice search isn't available", Toast.LENGTH_SHORT).show()
            }
        }
        handle.setOnClickListener { openDrawer(false) }
        clock.setOnClickListener {
            try {
                startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
        }

        appList.setOnTouchListener { _, event -> drawerDetector.onTouchEvent(event); false }
        appList.setOnItemClickListener { view, _, position, _ ->
            launch(adapter.items[position], view)
            closeDrawer()
        }
        appList.setOnItemLongClickListener { _, _, position, _ ->
            showAppMenu(adapter.items[position]); true
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { refreshDrawer() }
        })
        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_GO) {
                val q = searchInput.text.toString().trim()
                if (q.isNotEmpty()) {
                    val first = adapter.items.firstOrNull()
                    if (first != null) { launch(first, null); closeDrawer() } else webSearch(q)
                }
                true
            } else false
        }
    }

    private fun buildCategoryBar() {
        Cat.values().forEach { cat ->
            val iv = ImageView(this).apply {
                setImageResource(cat.icon)
                setColorFilter(Color.WHITE)
                setPadding(dp(9), dp(9), dp(9), dp(9))
                contentDescription = cat.title
                setOnClickListener { selectCategory(cat) }
            }
            categoryBar.addView(iv, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                setMargins(dp(3), 0, dp(3), 0)
            })
        }
    }

    // ------------------------------------------------------------------ apps

    private fun loadAppsAsync() {
        Thread {
            val list = queryApps()
            runOnUiThread {
                if (!isDestroyed) {
                    apps = list
                    renderHome()
                    refreshDrawer()
                }
            }
        }.start()
    }

    private fun queryApps(): List<AppEntry> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { ri ->
                val ai = ri.activityInfo
                val label = ri.loadLabel(pm).toString()
                val app = ai.applicationInfo
                AppEntry(
                    ai.packageName, label, ri.loadIcon(pm),
                    ComponentName(ai.packageName, ai.name),
                    classify(app, label),
                    (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                )
            }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    @Suppress("DEPRECATION")
    private fun classify(ai: ApplicationInfo, label: String): Cat {
        val key = (ai.packageName + " " + label).lowercase(Locale.US)
        fun has(vararg words: String) = words.any { key.contains(it) }

        if (ai.packageName == "com.android.settings" || has("settings")) return Cat.SETTINGS
        if ((ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0 || ai.category == ApplicationInfo.CATEGORY_GAME) return Cat.GAMES
        when (ai.category) {
            ApplicationInfo.CATEGORY_SOCIAL -> return Cat.SOCIAL
            ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> return Cat.MEDIA
            ApplicationInfo.CATEGORY_NEWS -> return Cat.INTERNET
            ApplicationInfo.CATEGORY_MAPS -> return Cat.TOOLS
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> return Cat.PRODUCTIVITY
        }
        return when {
            has("whatsapp", "facebook", "instagram", "telegram", "twitter", "snapchat", "messenger", "linkedin",
                "tiktok", "discord", "reddit", "signal", "mms", "messag", "dialer", "phone", "contacts", "sms") -> Cat.SOCIAL
            has("chrome", "browser", "firefox", "opera", "brave", "edge", "duckduckgo", "gmail", "email", "mail") -> Cat.INTERNET
            has("music", "youtube", "spotify", "video", "camera", "gallery", "photos", "player", "vlc", "netflix",
                "podcast", "radio") -> Cat.MEDIA
            has("docs", "sheets", "slides", "office", "excel", "powerpoint", "drive", "calendar", "notes", "keep",
                "notion", "onedrive", "pdf") -> Cat.PRODUCTIVITY
            has("calculator", "clock", "files", "filemanager", "documentsui", "maps", "translate", "flashlight",
                "recorder", "weather", "vpn", "cleaner", "torch", "compass") -> Cat.TOOLS
            else -> Cat.OTHER
        }
    }

    private fun find(pkg: String): AppEntry? = apps.firstOrNull { it.pkg == pkg }

    private fun launch(e: AppEntry, src: View?) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(e.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            val opts = if (src != null && src.width > 0)
                ActivityOptions.makeScaleUpAnimation(src, 0, 0, src.width, src.height).toBundle() else null
            startActivity(intent, opts)
        } catch (_: Exception) {
            Toast.makeText(this, "Can't open ${e.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun webSearch(q: String) {
        try {
            startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
        }
    }

    // ------------------------------------------------------------------ prefs helpers

    private fun key(name: String) = "${if (isLandscape) "landscape" else "portrait"}_$name"

    private fun getList(k: String): List<String> =
        prefs.getString(k, "")!!.split("|").filter { it.isNotBlank() }

    private fun putList(k: String, list: List<String>) {
        prefs.edit().putString(k, list.joinToString("|")).apply()
    }

    private fun darkText() = prefs.getBoolean(key("dark_text"), false)

    private fun favouritePkgs(): List<String> {
        if (!prefs.contains(key("favourites"))) {
            val inDock = dockPkgs().toSet()
            return apps.filter { it.pkg !in inDock }.take(if (isLandscape) 6 else 4).map { it.pkg }
        }
        return getList(key("favourites"))
    }

    private fun dockPkgs(): List<String> {
        if (!prefs.contains(key("dock"))) return defaultDock()
        return getList(key("dock"))
    }

    private fun defaultDock(): List<String> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER),
            Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CONTACTS)
        )
        val known = apps.map { it.pkg }.toSet()
        return intents
            .mapNotNull { packageManager.resolveActivity(it, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
            .filter { it in known }
            .distinct()
            .take(5)
    }

    private fun setFavourite(pkg: String, add: Boolean) {
        val list = favouritePkgs().toMutableList()
        if (add) { if (pkg !in list) list.add(pkg) } else list.remove(pkg)
        putList(key("favourites"), list)
        renderHome()
    }

    private fun setDock(pkg: String, add: Boolean) {
        val list = dockPkgs().toMutableList()
        if (add) {
            if (list.size >= 5 && pkg !in list) {
                Toast.makeText(this, "Dock is full (5 apps)", Toast.LENGTH_SHORT).show()
                return
            }
            if (pkg !in list) list.add(pkg)
        } else list.remove(pkg)
        putList(key("dock"), list)
        renderHome()
    }

    // ------------------------------------------------------------------ home

    private fun textColor() = if (darkText()) Color.rgb(20, 24, 32) else Color.WHITE

    private fun styleText(tv: TextView) {
        tv.setTextColor(textColor())
        if (darkText()) tv.setShadowLayer(0f, 0f, 0f, 0)
        else tv.setShadowLayer(6f, 0f, 1f, Color.argb(130, 0, 0, 0))
    }

    private fun applyProfile() {
        val uri = prefs.getString(key("wallpaper"), null)
        if (uri != null) {
            try { wallpaper.setImageURI(Uri.parse(uri)) } catch (_: Exception) { wallpaper.setImageDrawable(null) }
        } else {
            wallpaper.setImageDrawable(null)
        }
        val dark = darkText()
        val top = if (dark) Color.argb(110, 255, 255, 255) else Color.argb(115, 0, 0, 0)
        val bottom = if (dark) Color.argb(110, 255, 255, 255) else Color.argb(140, 0, 0, 0)
        scrimTop.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, 0))
        scrimBottom.background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(bottom, 0))

        clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (isLandscape) 52f else 78f)
        (clock.parent as View).setPadding(0, dp(if (isLandscape) 8 else 36), 0, 0)
        handle.visibility = if (isLandscape) View.GONE else View.VISIBLE
        handle.setColorFilter(textColor())
        styleText(clock); styleText(date); styleText(battery)

        renderHome()
        refreshDrawer()
    }

    private fun renderHome() {
        appGrid.removeAllViews()
        appGrid.columnCount = if (isLandscape) 6 else 4
        favouritePkgs().mapNotNull { find(it) }.take(if (isLandscape) 12 else 8).forEach { e ->
            val tile = buildTile(52, true)
            bindTile(tile, e, textColor(), !darkText())
            tile.isClickable = true
            tile.setOnClickListener { launch(e, tile) }
            tile.setOnLongClickListener { showAppMenu(e); true }
            tile.layoutParams = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            }
            appGrid.addView(tile)
        }

        dock.removeAllViews()
        dockPkgs().mapNotNull { find(it) }.take(5).forEach { e ->
            val tile = buildTile(if (isLandscape) 48 else 56, false)
            bindTile(tile, e, Color.WHITE, false)
            tile.setPadding(dp(2), dp(10), dp(2), dp(10))
            tile.isClickable = true
            tile.setOnClickListener { launch(e, tile) }
            tile.setOnLongClickListener { showAppMenu(e); true }
            dock.addView(tile, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
    }

    private fun updateClock() {
        val now = Date()
        val pattern = if (DateFormat.is24HourFormat(this)) "HH:mm" else "h:mm"
        clock.text = SimpleDateFormat(pattern, Locale.getDefault()).format(now)
        date.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)

        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        battery.text = if (level >= 0 && scale > 0)
            "${level * 100 / scale}%" + if (charging) " · Charging" else "" else ""
    }

    // ------------------------------------------------------------------ tiles

    private fun buildTile(iconDp: Int, showLabel: Boolean): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(2), dp(8), dp(2), dp(8))
        }
        box.addView(ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER },
            LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)))
        if (showLabel) {
            box.addView(TextView(this).apply {
                textSize = 11f
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(5) })
        }
        return box
    }

    private fun bindTile(box: View, e: AppEntry, color: Int, shadow: Boolean) {
        val group = box as ViewGroup
        val drawable = e.icon.constantState?.newDrawable()?.mutate() ?: e.icon
        (group.getChildAt(0) as ImageView).setImageDrawable(drawable)
        box.contentDescription = e.label
        if (group.childCount > 1) {
            val label = group.getChildAt(1) as TextView
            label.text = e.label
            label.setTextColor(color)
            if (shadow) label.setShadowLayer(4f, 0f, 1f, Color.argb(170, 0, 0, 0))
            else label.setShadowLayer(0f, 0f, 0f, 0)
        }
    }

    private inner class AppAdapter : BaseAdapter() {
        var items: List<AppEntry> = emptyList()
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val tile = convertView ?: buildTile(52, true)
            bindTile(tile, items[position], Color.WHITE, true)
            return tile
        }
    }

    // ------------------------------------------------------------------ drawer

    private fun openDrawer(focusSearch: Boolean) {
        if (drawer.visibility == View.VISIBLE) {
            if (focusSearch) focusSearchInput()
            return
        }
        drawer.animate().cancel()
        searchInput.setText("")
        currentCat = Cat.ALL
        refreshDrawer()
        appList.setSelection(0)
        drawer.alpha = 0f
        drawer.translationY = dp(48).toFloat()
        drawer.visibility = View.VISIBLE
        drawer.animate().alpha(1f).translationY(0f).setDuration(220).start()
        content.animate().alpha(0f).setDuration(180).start()
        if (focusSearch) focusSearchInput()
    }

    private fun closeDrawer() {
        if (drawer.visibility != View.VISIBLE) return
        hideKeyboard()
        content.animate().alpha(1f).setDuration(200).start()
        drawer.animate().alpha(0f).translationY(dp(48).toFloat()).setDuration(180).withEndAction {
            drawer.visibility = View.GONE
            searchInput.setText("")
            searchInput.clearFocus()
        }.start()
    }

    private fun focusSearchInput() {
        searchInput.requestFocus()
        drawer.post {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(drawer.windowToken, 0)
    }

    private fun gridAtTop(): Boolean =
        appList.firstVisiblePosition == 0 &&
            (appList.childCount == 0 || appList.getChildAt(0).top >= appList.paddingTop)

    private fun selectCategory(cat: Cat) {
        currentCat = cat
        if (searchInput.text.isNullOrEmpty()) refreshDrawer() else searchInput.setText("")
        appList.setSelection(0)
    }

    private fun shiftCategory(dir: Int) {
        val all = Cat.values()
        val next = (currentCat.ordinal + dir).coerceIn(0, all.size - 1)
        if (next != currentCat.ordinal) selectCategory(all[next])
    }

    private fun refreshDrawer() {
        val q = searchInput.text.toString().trim()
        val list: List<AppEntry>
        if (q.isNotEmpty()) {
            list = apps.filter { it.label.contains(q, true) }
                .sortedBy { if (it.label.startsWith(q, true)) 0 else 1 }
            categoryTitle.text = if (list.isEmpty()) "NO APPS FOUND · PRESS SEARCH FOR THE WEB" else "RESULTS"
        } else {
            list = if (currentCat == Cat.ALL) apps else apps.filter { it.cat == currentCat }
            categoryTitle.text = currentCat.title.uppercase(Locale.getDefault())
        }
        appList.numColumns = if (isLandscape) 7 else 4
        adapter.items = list
        adapter.notifyDataSetChanged()
        for (i in 0 until categoryBar.childCount) {
            val selected = q.isEmpty() && i == currentCat.ordinal
            val iv = categoryBar.getChildAt(i)
            iv.setBackgroundResource(if (selected) R.drawable.cat_selected_bg else 0)
            iv.alpha = if (selected) 1f else 0.55f
        }
    }

    // ------------------------------------------------------------------ dialogs

    private fun dialog() = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)

    private fun showAppMenu(e: AppEntry) {
        val inFav = e.pkg in favouritePkgs()
        val inDock = e.pkg in dockPkgs()
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()

        labels.add("Open"); actions.add { launch(e, null); closeDrawer() }
        if (inFav) { labels.add("Remove from home"); actions.add { setFavourite(e.pkg, false) } }
        else { labels.add("Add to home"); actions.add { setFavourite(e.pkg, true) } }
        if (inDock) { labels.add("Remove from dock"); actions.add { setDock(e.pkg, false) } }
        else { labels.add("Add to dock"); actions.add { setDock(e.pkg, true) } }
        labels.add("App info")
        actions.add {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${e.pkg}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        if (!e.system) {
            labels.add("Uninstall")
            actions.add { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${e.pkg}"))) }
        }
        dialog().setTitle(e.label)
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .show()
    }

    private fun showSettings() {
        val options = arrayOf(
            "Change wallpaper (this orientation)",
            "Use system wallpaper (this orientation)",
            "System wallpaper picker",
            if (darkText()) "Use light text" else "Use dark text",
            "Reset home & dock (this orientation)",
            "About DualSpace"
        )
        dialog().setTitle("Home settings")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> chooseWallpaper()
                    1 -> { prefs.edit().remove(key("wallpaper")).apply(); applyProfile() }
                    2 -> try {
                        startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
                    } catch (_: Exception) {}
                    3 -> { prefs.edit().putBoolean(key("dark_text"), !darkText()).apply(); applyProfile() }
                    4 -> { prefs.edit().remove(key("favourites")).remove(key("dock")).apply(); renderHome() }
                    5 -> dialog().setTitle("DualSpace 0.4")
                        .setMessage("A category-based launcher with separate portrait and landscape home spaces.")
                        .setPositiveButton("OK", null).show()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun chooseWallpaper() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }, REQUEST_WALLPAPER)
    }

    @Deprecated("Compatible with the starter Android API level")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_WALLPAPER && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            prefs.edit().putString(key("wallpaper"), uri.toString()).apply()
            applyProfile()
            Toast.makeText(this, "Wallpaper saved for this orientation", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------------ misc

    @SuppressLint("WrongConstant")
    private fun expandNotifications() {
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
        } catch (_: Exception) {}
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object { private const val REQUEST_WALLPAPER = 410 }
}
