# DualSpace 0.4 (Smart Launcher-style UI)

Standard Android Gradle project (Kotlin + XML), application ID `com.jo.dualspace`, minSdk 26, targetSdk 29.

## What changed in 0.4
- Transparent home over your system wallpaper (or a per-orientation custom wallpaper) with top/bottom scrims
- Pill search bar with mic, large thin centred clock, date and battery line
- Favourites grid with shadowed labels, 5-icon label-less dock, drawer handle
- Full-screen translucent app drawer: search field, category title, 4-column grid (7 in landscape)
- Bottom category bar: All, Games, Social, Internet, Multimedia, Productivity, Tools, Settings, Other
  (swipe left/right on the grid to switch categories, swipe down at the top to close)
- Swipe up on home = drawer, swipe down = notification shade, long-press = home settings
- Long-press any app: open, add/remove home, add/remove dock, app info, uninstall
- Search filters apps live; the keyboard Search key opens the first match or falls back to a web search
- Live clock/battery, auto-refresh when apps are installed or removed, portrait and landscape profiles kept separate

## Import
Import the ZIP as an Android/Gradle project, build a debug APK, install it and choose DualSpace as the Home app.

## Notes
Inspired by Smart Launcher's layout and interaction style, with original code, icons and name. Source has not been compiled in this environment.
