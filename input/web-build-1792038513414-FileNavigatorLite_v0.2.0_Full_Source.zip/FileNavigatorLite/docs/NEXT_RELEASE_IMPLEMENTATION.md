# Next release implementation notes

## Architecture

- `ui/`: Compose screens and view models. The new Storage & Tools screen is isolated in `StorageToolsScreen` and `StorageToolsViewModel`.
- `storage/`: SAF operations. `StorageAnalyzer` traverses only authorized roots and calculates SHA-256 for same-size candidates.
- `data/`: DataStore metadata. JSON backup is versioned and restores rules, history and appearance settings.
- `automation/` and `worker/`: rule matching, conflict handling and periodic WorkManager execution.

## Safety invariants

- Storage analysis is read-only; no duplicate cleanup action exists.
- Backup restore intentionally disables automatic organization. Review restored rules and enable automation manually.
- Folder grants are OS-level capabilities and are not included in JSON backups.
- ZIP extraction rejects absolute and parent-traversal paths and refuses existing file names instead of overwriting them.
- Automatic scheduling is periodic, not real-time. Android battery policy, Doze and force-stop can delay or stop work.

## Current boundaries

- The storage analyzer scans at most 10,000 files per run. Provider errors are counted as skipped items.
- Exact duplicate detection hashes all same-size candidate files and can take time on large or slow storage devices.
- Built-in document rendering is not included; files open through installed Android handlers.
- ZIP is supported; RAR/7z extraction, encryption, cloud storage and biometric app lock are not included.
- The source archive still requires a successful GitHub Actions build and device test before it should be treated as a release APK.

## Phone-only workflow

1. Upload the extracted project contents to the existing GitHub repository.
2. Run **Actions → Build APK**.
3. If it fails, download the `reports` artifact or open the failed step and share the first Kotlin compiler error.
4. Fix one failure at a time and rerun CI; install only after the workflow succeeds.
