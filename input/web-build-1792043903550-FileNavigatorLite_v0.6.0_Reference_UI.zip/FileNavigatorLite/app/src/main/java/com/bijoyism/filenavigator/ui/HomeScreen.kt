package com.bijoyism.filenavigator.ui

import android.content.Context
import android.os.StatFs
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.bijoyism.filenavigator.history.route
import com.bijoyism.filenavigator.navigation.Destination
import com.bijoyism.filenavigator.util.formatSize

private fun storageSummary(context: Context): Pair<Long, Long>? {
    val dir = context.getExternalFilesDir(null) ?: return null
    return runCatching {
        val stat = StatFs(dir.path)
        stat.totalBytes to stat.availableBytes
    }.getOrNull()
}

@Composable
fun HomeScreen(vm: AppViewModel, onOpen: (Destination) -> Unit) {
    val context = LocalContext.current
    val rules by vm.rules.collectAsState()
    val history by vm.history.collectAsState()
    val scanning by vm.scanning.collectAsState()
    val scanText by vm.scanText.collectAsState()
    val featurePrefs by vm.featurePrefs.collectAsState()
    val appSettings by vm.settings.collectAsState()
    val storage = remember { storageSummary(context) }
    val enabled = rules.count { it.enabled }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(54.dp)
            ) {
                androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Menu, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(30.dp))
                }
            }
            Column(Modifier.weight(1f)) {
                Text("File Navigator", style = MaterialTheme.typography.headlineSmall)
                Text("Lite · private, on-device organization", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(28.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Filled.Refresh, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                    Text("Navigator: ${if (appSettings.autoOrganize) "Active" else "Paused"}", style = MaterialTheme.typography.titleLarge)
                }
                Text(
                    if (appSettings.autoOrganize) "Automatic organization is enabled. Matching files are checked in the background; Android may delay scheduled work."
                    else "Automatic organization is paused. Start it when you're ready to organize files using your enabled rules.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = { vm.setAutoOrganize(!appSettings.autoOrganize) },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(28.dp)
                ) {
                    Icon(if (appSettings.autoOrganize) Icons.Filled.Info else Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.size(8.dp))
                    Text(if (appSettings.autoOrganize) "Stop navigator" else "Start navigator")
                }
            }
        }

        SectionCard("Move History") {
            Text("Recent file activity", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (history.isEmpty()) {
                Text("No file moves yet. Completed file actions will appear here.", style = MaterialTheme.typography.bodyMedium)
            } else {
                history.take(5).forEach { entry ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(12.dp)) {
                            Icon(Icons.Filled.Info, contentDescription = null, modifier = Modifier.padding(10.dp), tint = MaterialTheme.colorScheme.onSecondaryContainer)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(entry.name, style = MaterialTheme.typography.bodyLarge, maxLines = 2)
                            Text(entry.route(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                        }
                        Text(entry.type.lowercase().replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
                TextButton(onClick = { onOpen(Destination.Activity) }) { Text("View all activity") }
            }
        }

        if (featurePrefs.quickActions.isNotEmpty()) SectionCard("Quick actions") {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                featurePrefs.quickActions.forEach { action ->
                    TextButton(onClick = { onOpen(when (action) {
                        "files" -> Destination.Files
                        "automation" -> Destination.Automation
                        else -> Destination.Storage
                    }) }, modifier = Modifier.weight(1f)) {
                        Text(when (action) { "files" -> "Browse files"; "automation" -> "Rules"; else -> "Storage" }, maxLines = 1)
                    }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            MetricCard("Active rules", enabled.toString(), "of ${rules.size} total", Modifier.weight(1f))
            MetricCard("Recent actions", history.size.toString(), "saved in history", Modifier.weight(1f))
        }

        if ("automation" in featurePrefs.homeCards) SectionCard("Automation") {
            Text(
                "Background checks run periodically. Android may delay them to save battery; folder access must be granted once in the system folder picker.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            TextButton(onClick = { onOpen(Destination.Automation) }) { Text("Manage rules") }
        }

        if ("storage" in featurePrefs.homeCards) SectionCard("Storage") {
            if (storage == null) {
                Text("Storage information is not available on this device.")
            } else {
                val (total, free) = storage
                val used = (total - free).coerceAtLeast(0)
                LinearProgressIndicator(progress = { if (total > 0) used.toFloat() / total else 0f }, modifier = Modifier.fillMaxWidth())
                Text("${formatSize(context, used)} used of ${formatSize(context, total)} · ${formatSize(context, free)} free")
            }
        }

        if ("tools" in featurePrefs.homeCards) SectionCard("Storage tools") {
            Text("Analyze storage, find exact duplicates and create or extract ZIP archives.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            TextButton(onClick = { onOpen(Destination.Storage) }) { Text("Open storage tools") }
        }

        if ("activity" in featurePrefs.homeCards) SectionCard("Recent activity") {
            if (history.isEmpty()) {
                Text("Nothing yet. File actions will appear here.")
            } else {
                history.take(5).forEach { e ->
                    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Filled.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${e.type.lowercase().replaceFirstChar { it.uppercase() }} · ${e.name}", style = MaterialTheme.typography.bodyMedium)
                            Text(e.route(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                TextButton(onClick = { onOpen(Destination.Activity) }) { Text("View activity") }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, subtitle: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.headlineMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
