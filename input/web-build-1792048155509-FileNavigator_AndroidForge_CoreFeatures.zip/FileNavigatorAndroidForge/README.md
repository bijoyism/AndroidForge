# File Navigator — AndroidForge source project

Kotlin + Jetpack Compose Android application. Package: `com.bijoyism.filenavigator`. Minimum Android version: Android 8.0 (API 26).

## Core features implemented in this package

- Screenshot-inspired monochrome Home, Navigator Settings, and App Settings screens.
- Persisted category/source rules with Notify and Auto modes.
- Android Storage Access Framework folder selection for a monitored source folder and per-rule destination folders.
- User-visible foreground service with an ongoing status notification and Stop action.
- Periodic scanning of the user-selected SAF tree; first scan establishes a baseline so existing files are not intentionally moved.
- Best-effort file classification by MIME type/extension and source path (Camera, Screenshot, Download, Other App).
- Notify-mode notifications with a real Move action.
- Auto-mode copy/verify/delete workflow with collision-safe names; failed operations are recorded as failures rather than successes.
- Persisted move history and clear-history confirmation.
- Saved theme, storage-path preference, and source-rule settings.

## Build

Use JDK 17 and Android Gradle Plugin 8.7.3 / Gradle 8.9. In Android Studio, open this folder and run `:app:assembleDebug`. AndroidForge can also use the included GitHub Actions workflow to build the debug APK. This archive intentionally does not include the binary Gradle wrapper JAR; use AndroidForge's Gradle bootstrap or the included CI workflow if required.

## Important Android limitations

- The app only scans the directory tree the user explicitly grants through Android's folder picker. It cannot silently monitor all device storage or other apps' private directories.
- Android may delay or stop background work because of battery management or OS restrictions; continuous instant detection is not guaranteed. Use Scan now for a manual scan.
- Camera, screenshot, and download source attribution is best-effort and inferred from names/paths. Arbitrary creator-app identity cannot be reliably determined by a normal third-party app.
- SAF providers differ. Some providers do not permit deleting a source document or copying between certain locations; those operations are recorded as failed. Verify important files after testing with your own storage provider.
- Notification permission is controlled by Android on Android 13+. The app's notification visibility depends on the device's permission settings.
- This is a core-feature implementation, not a claim of exhaustive production certification. Run a Gradle build and test file operations on the target device before relying on automatic organization.

## Safety notes

The initial scan creates a baseline. Newly discovered files are handled after a subsequent scan. Auto mode requires a destination folder to be selected for that rule. File moves use copy, verify, then delete; if source deletion fails, the copied target is removed where possible and the operation is reported as failed. Existing destination filenames are preserved by choosing a unique name.
