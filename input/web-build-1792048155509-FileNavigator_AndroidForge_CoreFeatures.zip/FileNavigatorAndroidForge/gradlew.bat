@echo off
set VERSION=8.9
set DIST=%USERPROFILE%\.gradle\wrapper\dists\file-navigator-gradle-%VERSION%
set GRADLE=%DIST%\gradle-%VERSION%\bin\gradle.bat
if not exist "%GRADLE%" (
  echo Gradle 8.9 is not installed. Run this project on AndroidForge or use the GitHub Actions workflow.
  exit /b 1
)
call "%GRADLE%" %*
