package com.bijoyism.filenavigator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

/** User-visible SAF-folder monitor. Android may still throttle or stop background work. */
class FileNavigatorService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var scanJob: Job? = null
    private val prefs by lazy { getSharedPreferences("navigator", MODE_PRIVATE) }
    private val processed = mutableSetOf<String>()

    override fun onCreate() {
        super.onCreate()
        createChannels()
        startForeground(NOTIFICATION_ID, ongoingNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_SCAN -> scope.launch {
                scanSafRoot()
                if (intent.getBooleanExtra(EXTRA_ONE_SHOT, false)) stopSelf()
            }
            ACTION_MOVE -> scope.launch {
                movePending(intent.getStringExtra(EXTRA_SOURCE), intent.getStringExtra(EXTRA_DEST), intent.getStringExtra(EXTRA_NAME))
            }
            else -> {
                isRunning = true
                if (scanJob == null) scanJob = scope.launch {
                    while (isActive) { scanSafRoot(); delay(15_000) }
                }
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isRunning = false
        scanJob?.cancel()
        scope.cancel()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(NOTIFICATION_ID)
        super.onDestroy()
    }

    private fun scanSafRoot() {
        val rootUri = prefs.getString("watch_uri", null)?.let(Uri::parse) ?: return
        val root = DocumentFile.fromTreeUri(this, rootUri) ?: return
        if (!root.canRead()) return
        val rules = readRules()
        val baseline = !prefs.getBoolean("baseline_complete", false)
        walk(root, root.name.orEmpty(), rules, 0, baseline)
        if (baseline) prefs.edit().putBoolean("baseline_complete", true).apply()
    }

    private fun walk(dir: DocumentFile, relative: String, rules: List<Rule>, depth: Int, baseline: Boolean) {
        if (depth > 12) return
        val destinationUris = rules.map { it.destinationUri }.filter { it.isNotBlank() }.toSet()
        if (dir.uri.toString() in destinationUris) return
        val children = try { dir.listFiles() } catch (_: Exception) { return }
        for (file in children) {
            if (file.isDirectory) {
                walk(file, listOf(relative, file.name.orEmpty()).filter { it.isNotBlank() }.joinToString("/"), rules, depth + 1, baseline)
                continue
            }
            if (!file.isFile) continue
            val uri = file.uri.toString()
            if (uri in processed || wasProcessed(uri)) continue
            // First scan establishes a baseline; later scans handle only newly discovered files.
            if (baseline) { markSeen(uri); continue }
            if (markSeen(uri)) continue
            val name = file.name ?: continue
            val category = classify(name, file.type)
            val source = classifySource(relative, name)
            val rule = rules.firstOrNull { it.enabled && it.category.equals(category, true) && it.source.equals(source, true) }
                ?: rules.firstOrNull { it.enabled && it.category.equals(category, true) && it.source == "Other App" }
                ?: continue
            val destUri = rule.destinationUri
            if (destUri.isBlank()) {
                postError("Destination missing", "Choose a destination folder for ${rule.category} / ${rule.source}.")
                continue
            }
            if (rule.auto) {
                val ok = moveFile(uri, destUri, name)
                addHistory(name, relative, rule.destination, category, if (ok) "Moved" else "Failed", true)
                if (ok) postResult("File organized", "$name → ${rule.destination}")
                else postError("Could not move file", "Check folder permissions and destination access for $name.")
            } else {
                postPending(name, uri, destUri, relative, rule.destination)
            }
        }
    }

    private fun readRules(): List<Rule> = try {
        val arr = JSONArray(prefs.getString("rules", "[]"))
        (0 until arr.length()).map { i -> arr.getJSONObject(i).let { o -> Rule(o.optString("category"), o.optString("source"), o.optString("destination"), o.optBoolean("enabled", true), o.optBoolean("auto", false), o.optString("destinationUri")) } }
    } catch (_: Exception) { emptyList() }

    private fun classify(name: String, mime: String?): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when {
            mime?.startsWith("image/") == true || ext in setOf("jpg","jpeg","png","webp","gif","heic","bmp") -> "Pictures"
            mime?.startsWith("video/") == true || ext in setOf("mp4","mkv","webm","mov","3gp","avi") -> "Videos"
            mime?.startsWith("audio/") == true || ext in setOf("mp3","wav","aac","flac","ogg","m4a") -> "Audio"
            ext == "apk" -> "APKs"
            ext in setOf("zip","rar","7z","tar","gz","bz2") -> "Archives"
            ext in setOf("pdf","txt","doc","docx","xls","xlsx","ppt","pptx","csv","rtf","odt") -> "Documents"
            else -> "Other"
        }
    }

    private fun classifySource(path: String, name: String): String {
        val lower = (path + "/" + name).lowercase()
        return when {
            "screenshot" in lower || "screenshots" in lower -> "Screenshot"
            "/dcim/camera" in lower || "/camera/" in lower || path.lowercase().contains("dcim") -> "Camera"
            "download" in path.lowercase() -> "Download"
            else -> "Other App"
        }
    }

    /** SAF tree traversal cannot always move across providers; use create/copy/delete with verification. */
    private fun moveFile(sourceText: String, destinationText: String, name: String): Boolean {
        return try {
            val sourceUri = Uri.parse(sourceText)
            val destinationUri = Uri.parse(destinationText)
            val source = DocumentFile.fromSingleUri(this, sourceUri) ?: return false
            val destination = DocumentFile.fromTreeUri(this, destinationUri) ?: DocumentFile.fromSingleUri(this, destinationUri) ?: return false
            if (!source.exists() || !destination.isDirectory || !destination.canWrite()) return false
            val safeName = uniqueName(destination, name)
            val target = destination.createFile(source.type ?: mimeFromName(name), safeName) ?: return false
            val input = contentResolver.openInputStream(sourceUri) ?: run { target.delete(); return false }
            val output = contentResolver.openOutputStream(target.uri, "w") ?: run { input.close(); target.delete(); return false }
            input.use { ins -> output.use { out -> ins.copyTo(out) } }
            val verified = target.exists() && target.length() > 0L || source.length() == 0L && target.exists()
            if (!verified) { target.delete(); return false }
            val deleted = if (Build.VERSION.SDK_INT >= 24) source.delete() else false
            // SAF providers can reject delete after a successful copy; don't report a move in that case.
            if (!deleted) { target.delete(); return false }
            processed.add(sourceText)
            prefs.edit().putStringSet("processed", processed + sourceText).apply()
            true
        } catch (_: Exception) { false }
    }

    private fun uniqueName(folder: DocumentFile, name: String): String {
        if (folder.findFile(name) == null) return name
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        var n = 1
        while (n < 10000) {
            val candidate = if (ext.isBlank()) "$base ($n)" else "$base ($n).$ext"
            if (folder.findFile(candidate) == null) return candidate
            n++
        }
        return "${System.currentTimeMillis()}_$name"
    }

    private fun mimeFromName(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"; "png" -> "image/png"; "pdf" -> "application/pdf"; "mp4" -> "video/mp4"; "apk" -> "application/vnd.android.package-archive"; "zip" -> "application/zip"; else -> "application/octet-stream"
    }

    private fun wasProcessed(uri: String) = prefs.getStringSet("processed", emptySet())?.contains(uri) == true
    private fun markSeen(uri: String): Boolean {
        val seen = prefs.getStringSet("seen", emptySet())?.toMutableSet() ?: mutableSetOf()
        if (uri in seen) return false
        seen.add(uri)
        if (seen.size > 4000) seen.clear().also { seen.add(uri) }
        prefs.edit().putStringSet("seen", seen).apply()
        return true
    }

    private fun movePending(source: String?, dest: String?, name: String?) {
        if (source.isNullOrBlank() || dest.isNullOrBlank() || name.isNullOrBlank()) return
        val ok = moveFile(source, dest, name)
        addHistory(name, "Pending notification", "Selected destination", classify(name, null), if (ok) "Moved" else "Failed", false)
        if (ok) postResult("File moved", name) else postError("Move failed", "Permission or destination unavailable for $name")
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(source.hashCode())
    }

    private fun addHistory(name: String, from: String, to: String, category: String, status: String, automatic: Boolean) {
        val arr = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        arr.put(0, JSONObject().put("id", System.currentTimeMillis()).put("name", name).put("from", from).put("to", to).put("category", category).put("status", status).put("automatic", automatic).put("time", System.currentTimeMillis()))
        while (arr.length() > 100) arr.remove(arr.length() - 1)
        prefs.edit().putString("history", arr.toString()).apply()
    }

    private fun postPending(name: String, source: String, dest: String, from: String, to: String) {
        val moveIntent = Intent(this, FileNavigatorService::class.java).setAction(ACTION_MOVE)
            .putExtra(EXTRA_SOURCE, source).putExtra(EXTRA_DEST, dest).putExtra(EXTRA_NAME, name)
        val movePending = PendingIntent.getService(this, source.hashCode(), moveIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, ALERT_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_upload).setContentTitle("Navigate ${classify(name, null).removeSuffix("s")}")
            .setContentText(name).setStyle(NotificationCompat.BigTextStyle().bigText("$name\nFrom: $from\nDestination: $to"))
            .addAction(0, "Move", movePending).setAutoCancel(true).build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(source.hashCode(), notification)
    }

    private fun postResult(title: String, text: String) {
        val n = NotificationCompat.Builder(this, ALERT_CHANNEL).setSmallIcon(android.R.drawable.ic_menu_upload).setContentTitle(title).setContentText(text).setAutoCancel(true).build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
    }
    private fun postError(title: String, text: String) = postResult(title, text)

    private fun ongoingNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, FileNavigatorService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, STATUS_CHANNEL).setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("File Navigator is running").setContentText("Monitoring your selected folder")
            .setContentIntent(open).setOngoing(true).addAction(0, "Stop", stop).build()
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel(STATUS_CHANNEL, "Navigator status", NotificationManager.IMPORTANCE_LOW))
            manager.createNotificationChannel(NotificationChannel(ALERT_CHANNEL, "File actions", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    data class Rule(val category: String, val source: String, val destination: String, val enabled: Boolean, val auto: Boolean, val destinationUri: String)

    companion object {
        const val ACTION_STOP = "com.bijoyism.filenavigator.STOP"
        const val ACTION_SCAN = "com.bijoyism.filenavigator.SCAN"
        const val ACTION_MOVE = "com.bijoyism.filenavigator.MOVE"
        const val EXTRA_SOURCE = "source_uri"
        const val EXTRA_DEST = "destination_uri"
        const val EXTRA_NAME = "file_name"
        const val EXTRA_ONE_SHOT = "one_shot_scan"
        private const val STATUS_CHANNEL = "navigator_status"
        private const val ALERT_CHANNEL = "file_actions"
        private const val NOTIFICATION_ID = 7321
        @Volatile var isRunning = false
        fun start(context: Context) {
            val intent = Intent(context, FileNavigatorService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        }
        fun stop(context: Context) { context.startService(Intent(context, FileNavigatorService::class.java).setAction(ACTION_STOP)) }
        fun requestScan(context: Context) {
            val intent = Intent(context, FileNavigatorService::class.java).setAction(ACTION_SCAN)
                .putExtra(EXTRA_ONE_SHOT, !isRunning)
            if (Build.VERSION.SDK_INT >= 26 && !isRunning) context.startForegroundService(intent)
            else context.startService(intent)
        }
    }
}
