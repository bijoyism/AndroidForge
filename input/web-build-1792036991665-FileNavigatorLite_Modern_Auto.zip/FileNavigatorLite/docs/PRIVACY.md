# Permissions and privacy

- Permissions: `POST_NOTIFICATIONS` (API 33+ only, asked when enabling notifications). No storage, network or account permissions.
- File access: only through folders you pick; you can revoke them in Settings.
- Stored on device: rules, a history of up to 200 operations (type, file name, folder names, time, result, error), settings, and the URIs of files already seen by scans. No file contents are stored.
- Nothing is uploaded; the app has no network permission and no ads or analytics.
- Clear history: Activity tab. Uninstalling removes all data.
