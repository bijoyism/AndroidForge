# Android 10 (API 29) compatibility notes

The app uses only the Storage Access Framework (`DocumentsContract`, persisted tree URIs). It requests no storage permission and does not use MANAGE_EXTERNAL_STORAGE or raw file paths.

| Operation | Android 10 behavior |
|---|---|
| Browse | Only folders the user picks with "Add folder". |
| Copy | Stream copy into a new document, size-verified, partial copy deleted on failure. |
| Move | Provider-side `moveDocument` when the name is unchanged, otherwise copy + verify + delete original. If the original cannot be deleted the copy is removed and the file is left untouched. |
| Rename / delete / create folder | `DocumentsContract` calls; the provider may refuse. Errors are shown and logged. |
| Open / share | `ACTION_VIEW` / Sharesheet with temporary read grants. |
| Revoked folder | Operations fail with a clear message; rules show an error until the folder is chosen again. |
| Dynamic color | API 31+ only, static colors on 29 and 30. |
| Notification permission | Requested only on API 33+, when the user turns notifications on. |

Some providers (and the root of internal storage on newer Android) cannot be granted as trees. Android 10 allows most folders, including Download.
