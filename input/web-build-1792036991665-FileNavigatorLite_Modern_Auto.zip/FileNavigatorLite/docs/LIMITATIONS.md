# Known limitations

- Not compiled, run or tested on a device yet (see README).
- New-file detection is periodic (WorkManager, about every 30 minutes, battery-not-low) plus the Scan Now button. There is no instant detection: `FileObserver` does not work with SAF URIs and MediaStore observation needs a storage permission this app deliberately does not request. Android may delay or skip background work on low-RAM devices and aggressive vendor battery savers.
- The first scan of a folder only records a baseline and sends no notification.
- Notification actions: Organize now, Review, Dismiss. "Open file" is available in the Files tab, not the notification.
- Not implemented: favorites, recently opened files, archive creation/extraction, separate suggested-destination review screen beyond the rule preview.
- Listing is loaded fully and shown in pages of 200; very large folders (tens of thousands of files) will be slow on low-end phones.
- Undo works for plain moves while the folders are still authorized; not for copies, deletes or replaced files.
- Rule history writes rewrite one JSON value (max 200 entries); huge batches are slower than necessary.
- No instrumented (on-device) tests: SAF behavior, revoked permissions and API 29 specifics are covered only by unit tests against a fake storage.
- Formatting rules were relaxed in `.editorconfig` (import order, wrapping) to reduce false failures.
