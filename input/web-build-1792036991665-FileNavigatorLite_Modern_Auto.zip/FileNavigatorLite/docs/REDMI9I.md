# Installing and testing on a Redmi 9i

1. Download the `FileNavigatorLite-debug` artifact on the phone, unzip, tap `app-debug.apk`, allow "install unknown apps" for your browser/file app.
2. Open the app > Files > **Add folder** > pick **Download** > "Use this folder" > Allow.
3. Create a test file set: put a few `.apk`, `.zip`, `.pdf` files and a duplicate name in Download.
4. Automation > New rule > preset **APKs**, source Download, destination a new folder (create it with the picker's "New folder") > Save > **Test** (dry run) > confirm Move.
5. Activity tab: check the entries, try **Undo move**. Try the duplicate-name case with each conflict option.
6. Settings > turn on notifications (allow if asked), add a file to Download, then Home > **Scan now** twice: the first run records a baseline, the second reports new files.
7. Revoke the folder in Settings and confirm the rule shows a clear error.
8. MIUI: allow autostart / disable battery restrictions for the app, or background scans may not run.
