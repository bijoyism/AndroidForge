package com.bijoyism.filenavigator

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.bijoyism.filenavigator.navigation.Destination
import com.bijoyism.filenavigator.ui.AppScaffold
import com.bijoyism.filenavigator.ui.theme.FileNavigatorTheme

class MainActivity : ComponentActivity() {
    private var requested by mutableStateOf<Destination?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requested = parse(intent)
        setContent {
            FileNavigatorTheme {
                AppScaffold(requested = requested, onRequestHandled = { requested = null })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        requested = parse(intent)
    }

    private fun parse(intent: Intent?): Destination? = Destination.entries.firstOrNull { it.name == intent?.getStringExtra(EXTRA_OPEN) }

    companion object {
        const val EXTRA_OPEN = "open"
    }
}
