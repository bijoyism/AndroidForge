package com.bijoyism.filenavigator.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bijoyism.filenavigator.history.canUndo
import com.bijoyism.filenavigator.history.route
import com.bijoyism.filenavigator.util.formatDate

@Composable
fun ActivityScreen(vm: AppViewModel) {
    val history by vm.history.collectAsState()
    val notice by vm.notice.collectAsState()
    var confirmClear by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Activity", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            TextButton(onClick = { confirmClear = true }, enabled = history.isNotEmpty()) { Text("Clear history") }
        }
        if (history.isEmpty()) {
            CenterMessage("No operations yet. Moves, copies, renames and deletes are listed here.")
        } else {
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(history, key = { it.id }) { e ->
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                        Text("${if (e.success) "✓" else "✗"} ${e.type} · ${e.name}", style = MaterialTheme.typography.titleSmall)
                        Text(e.route(), style = MaterialTheme.typography.bodySmall)
                        Text(formatDate(e.time), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        e.error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                        if (e.undone) Text("Undone", style = MaterialTheme.typography.bodySmall)
                        if (e.canUndo()) TextButton(onClick = { vm.undo(e) }) { Text("Undo move") }
                    }
                }
            }
        }
    }

    if (confirmClear) {
        ConfirmDialog(
            title = "Clear history?",
            text = "This removes the list of past operations. Your files are not affected, and undo will no longer be possible.",
            confirmLabel = "Clear",
            onConfirm = {
                vm.clearHistory()
                confirmClear = false
            },
            onDismiss = { confirmClear = false }
        )
    }
    notice?.let { MessageDialog("Undo", it, vm::dismissNotice) }
}
