package com.bijoyism.filenavigator.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsState()
    val grants by vm.grants.collectAsState()
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> vm.setNotifications(granted) }
    val addFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) vm.grant(uri) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)

        SectionCard("Notifications") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Notify about new matching files", Modifier.weight(1f))
                Switch(
                    checked = settings.notifications,
                    onCheckedChange = { on ->
                        val needsPermission = on && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        if (needsPermission) permission.launch(Manifest.permission.POST_NOTIFICATIONS) else vm.setNotifications(on)
                    }
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Quiet mode (scan silently, no notifications)", Modifier.weight(1f))
                Switch(checked = settings.quiet, onCheckedChange = { vm.setQuiet(it) })
            }
        }

        SectionCard("Authorized folders") {
            if (grants.isEmpty()) Text("No folders authorized yet.")
            grants.forEach { uri ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text(vm.label(uri), Modifier.weight(1f))
                    TextButton(onClick = { vm.revoke(uri) }) { Text("Revoke") }
                }
            }
            OutlinedButton(onClick = { addFolder.launch(null) }) { Text("Add folder") }
        }

        SectionCard("About") {
            Text("Version 0.1.0. The app only reads folders you authorize and stores rule and history metadata on this device. Nothing is uploaded.", style = MaterialTheme.typography.bodyMedium)
        }
    }
}
