package com.bijoyism.filenavigator.domain

import java.util.UUID

enum class ConflictPolicy { RENAME, SKIP, REPLACE }

data class Rule(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val enabled: Boolean = true,
    val sourceUri: String,
    val destUri: String,
    val extensions: List<String> = emptyList(),
    val mimeTypes: List<String> = emptyList(),
    val keywords: List<String> = emptyList(),
    val minSizeBytes: Long? = null,
    val maxSizeBytes: Long? = null,
    val conflict: ConflictPolicy = ConflictPolicy.RENAME,
    val lastStatus: String? = null
)

data class FileEntry(
    val uri: String,
    val name: String,
    val size: Long,
    val mimeType: String?,
    val lastModified: Long,
    val isDirectory: Boolean
)

data class HistoryEntry(
    val id: String = UUID.randomUUID().toString(),
    val time: Long = System.currentTimeMillis(),
    val type: String,
    val name: String,
    val from: String,
    val to: String,
    val success: Boolean,
    val error: String? = null,
    val srcFolderUri: String? = null,
    val destFolderUri: String? = null,
    val resultUri: String? = null,
    val undone: Boolean = false
)

interface HistoryLog {
    suspend fun add(entry: HistoryEntry)
}

class StorageException(message: String, cause: Throwable? = null) : Exception(message, cause)

interface StorageGateway {
    fun hasAccess(folderUri: String): Boolean
    fun sameFolder(a: String, b: String): Boolean
    fun list(folderUri: String): List<FileEntry>
    fun copy(fileUri: String, destFolderUri: String, name: String): String
    fun move(fileUri: String, srcFolderUri: String, destFolderUri: String, name: String): String
    fun delete(uri: String)
    fun rename(uri: String, newName: String): String
    fun createFolder(parentUri: String, name: String): String
    fun label(folderUri: String): String
}
