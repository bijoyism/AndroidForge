package com.bijoyism.filenavigator.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bijoyism.filenavigator.AppContainer
import com.bijoyism.filenavigator.automation.PlannedMove
import com.bijoyism.filenavigator.automation.summarize
import com.bijoyism.filenavigator.domain.ConflictPolicy
import com.bijoyism.filenavigator.domain.FileEntry
import com.bijoyism.filenavigator.domain.HistoryEntry
import com.bijoyism.filenavigator.domain.Rule
import com.bijoyism.filenavigator.domain.SortKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

const val PAGE_SIZE = 200

data class Crumb(val name: String, val uri: String)

data class FilesState(
    val roots: List<String> = emptyList(),
    val stack: List<Crumb> = emptyList(),
    val entries: List<FileEntry> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
    val query: String = "",
    val sort: SortKey = SortKey.NAME,
    val grid: Boolean = false,
    val selecting: Boolean = false,
    val selected: Set<String> = emptySet(),
    val shown: Int = PAGE_SIZE,
    val message: String? = null
)

@OptIn(FlowPreview::class)
class FilesViewModel(private val c: AppContainer) : ViewModel() {
    private val _state = MutableStateFlow(FilesState(roots = c.storage.grantedRoots()))
    val state: StateFlow<FilesState> = _state

    private val queryFlow = MutableStateFlow("")

    init {
        viewModelScope.launch {
            queryFlow.debounce(300).collect { q -> _state.update { it.copy(query = q, shown = PAGE_SIZE) } }
        }
    }

    fun labelOf(uri: String): String = c.storage.label(uri)

    fun setQuery(text: String) {
        queryFlow.value = text
    }

    fun setSort(key: SortKey) = _state.update { it.copy(sort = key) }

    fun toggleGrid() = _state.update { it.copy(grid = !it.grid) }

    fun loadMore() = _state.update { it.copy(shown = it.shown + PAGE_SIZE) }

    fun dismissMessage() = _state.update { it.copy(message = null) }

    fun refreshRoots() = _state.update { it.copy(roots = c.storage.grantedRoots()) }

    fun grant(uri: Uri) {
        c.storage.grant(uri)
        refreshRoots()
    }

    fun openRoot(uri: String) {
        _state.update { it.copy(stack = listOf(Crumb(c.storage.label(uri), uri))) }
        load()
    }

    fun enter(entry: FileEntry) {
        _state.update { it.copy(stack = it.stack + Crumb(entry.name, entry.uri)) }
        load()
    }

    fun navigateTo(index: Int) {
        _state.update { it.copy(stack = it.stack.take(index + 1)) }
        load()
    }

    fun up() {
        val size = _state.value.stack.size
        if (size > 1) {
            navigateTo(size - 2)
        } else {
            _state.update { it.copy(stack = emptyList(), entries = emptyList(), error = null, selected = emptySet(), selecting = false) }
            refreshRoots()
        }
    }

    fun toggleSelecting() = _state.update { it.copy(selecting = !it.selecting, selected = emptySet()) }

    fun toggle(uri: String) = _state.update { it.copy(selected = if (uri in it.selected) it.selected - uri else it.selected + uri) }

    fun selectAll(uris: List<String>) = _state.update { it.copy(selected = uris.toSet()) }

    fun selectedEntries(): List<FileEntry> = _state.value.entries.filter { it.uri in _state.value.selected }

    private fun currentFolder(): String? = _state.value.stack.lastOrNull()?.uri

    fun reload() = load()

    private fun load() {
        val folder = currentFolder() ?: return
        _state.update { it.copy(loading = true, error = null, selected = emptySet(), selecting = false, shown = PAGE_SIZE) }
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { c.storage.list(folder) } }
            _state.update { s ->
                result.fold(
                    { s.copy(entries = it, loading = false) },
                    { s.copy(entries = emptyList(), loading = false, error = it.message ?: "Cannot read this folder") }
                )
            }
        }
    }

    private fun launchOp(block: suspend () -> String) {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val message = withContext(Dispatchers.IO) { runCatching { block() }.getOrElse { "Failed: ${it.message}" } }
            _state.update { it.copy(message = message) }
            load()
        }
    }

    private suspend fun tracked(type: String, name: String, from: String, to: String, block: () -> Unit) {
        try {
            block()
            c.data.add(HistoryEntry(type = type, name = name, from = from, to = to, success = true))
        } catch (e: Exception) {
            c.data.add(HistoryEntry(type = type, name = name, from = from, to = to, success = false, error = e.message))
            throw e
        }
    }

    fun deleteSelected() {
        val items = selectedEntries()
        val folder = currentFolder() ?: return
        launchOp {
            var done = 0
            val errors = mutableListOf<String>()
            val label = c.storage.label(folder)
            for (e in items) {
                try {
                    tracked("DELETE", e.name, label, "") { c.storage.delete(e.uri) }
                    done++
                } catch (ex: Exception) {
                    errors.add("${e.name}: ${ex.message}")
                }
            }
            buildString {
                append("$done deleted")
                if (errors.isNotEmpty()) append(", ${errors.size} failed")
                errors.forEach { append("\n• $it") }
            }
        }
    }

    fun rename(entry: FileEntry, newName: String) {
        val name = newName.trim()
        val folder = currentFolder() ?: return
        if (name.isEmpty() || name.contains('/')) {
            _state.update { it.copy(message = "Invalid name") }
            return
        }
        if (_state.value.entries.any { it.name == name }) {
            _state.update { it.copy(message = "\"$name\" already exists here") }
            return
        }
        launchOp {
            tracked("RENAME", entry.name, entry.name, name) { c.storage.rename(entry.uri, name) }
            "Renamed to $name (in ${c.storage.label(folder)})"
        }
    }

    fun createFolder(newName: String) {
        val name = newName.trim()
        val folder = currentFolder() ?: return
        if (name.isEmpty() || name.contains('/')) {
            _state.update { it.copy(message = "Invalid name") }
            return
        }
        if (_state.value.entries.any { it.name == name }) {
            _state.update { it.copy(message = "\"$name\" already exists here") }
            return
        }
        launchOp {
            tracked("MKDIR", name, c.storage.label(folder), "") { c.storage.createFolder(folder, name) }
            "Created folder $name"
        }
    }

    fun grantAndTransfer(destination: Uri, move: Boolean) {
        c.storage.grant(destination)
        refreshRoots()
        val items = selectedEntries()
        val folder = currentFolder() ?: return
        launchOp {
            val plan = items.map { PlannedMove("", "Manual", it, folder, destination.toString(), ConflictPolicy.RENAME, copy = !move) }
            summarize(c.engine.execute(plan))
        }
    }

    fun applyRule(rule: Rule) {
        val items = selectedEntries().filter { !it.isDirectory }
        val folder = currentFolder() ?: return
        launchOp {
            val plan = items.map { PlannedMove(rule.id, rule.name, it, folder, rule.destUri, rule.conflict) }
            summarize(c.automation.run(plan))
        }
    }
}
