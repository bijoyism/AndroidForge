package com.bijoyism.filenavigator.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bijoyism.filenavigator.AppContainer
import com.bijoyism.filenavigator.automation.ItemResult
import com.bijoyism.filenavigator.automation.PlannedMove
import com.bijoyism.filenavigator.automation.RuleProblem
import com.bijoyism.filenavigator.domain.Rule
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class PreviewUi(
    val title: String,
    val moves: List<PlannedMove> = emptyList(),
    val problems: List<RuleProblem> = emptyList(),
    val loading: Boolean = true,
    val results: List<ItemResult>? = null
)

class AutomationViewModel(private val c: AppContainer) : ViewModel() {
    val rules: StateFlow<List<Rule>> = c.data.rules.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _preview = MutableStateFlow<PreviewUi?>(null)
    val preview: StateFlow<PreviewUi?> = _preview

    fun label(uri: String): String = c.storage.label(uri)

    fun grant(uri: Uri) = c.storage.grant(uri)

    fun save(rule: Rule) {
        viewModelScope.launch {
            c.data.updateRules { list -> if (list.any { it.id == rule.id }) list.map { if (it.id == rule.id) rule else it } else list + rule }
        }
    }

    fun delete(id: String) {
        viewModelScope.launch { c.data.updateRules { list -> list.filter { it.id != id } } }
    }

    fun setEnabled(id: String, enabled: Boolean) {
        viewModelScope.launch { c.data.updateRules { list -> list.map { if (it.id == id) it.copy(enabled = enabled) else it } } }
    }

    /** Rules are checked in list order, so moving a rule up gives it higher precedence. */
    fun moveUp(id: String) {
        viewModelScope.launch {
            c.data.updateRules { list ->
                val i = list.indexOfFirst { it.id == id }
                if (i <= 0) {
                    list
                } else {
                    val copy = list.toMutableList()
                    copy[i] = list[i - 1]
                    copy[i - 1] = list[i]
                    copy
                }
            }
        }
    }

    fun preview(rule: Rule?) {
        val title = rule?.name ?: "All enabled rules"
        _preview.value = PreviewUi(title)
        viewModelScope.launch {
            val list = if (rule != null) listOf(rule.copy(enabled = true)) else rules.value
            val result = c.automation.preview(list)
            _preview.value = PreviewUi(title, result.moves, result.problems, loading = false)
        }
    }

    fun runPreview() {
        val current = _preview.value ?: return
        _preview.value = current.copy(loading = true)
        viewModelScope.launch {
            val results = c.automation.run(current.moves)
            _preview.value = current.copy(loading = false, results = results)
        }
    }

    fun closePreview() {
        _preview.value = null
    }
}
