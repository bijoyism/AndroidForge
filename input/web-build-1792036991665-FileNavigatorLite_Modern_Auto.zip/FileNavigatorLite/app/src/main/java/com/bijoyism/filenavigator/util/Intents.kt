package com.bijoyism.filenavigator.util

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.format.Formatter
import com.bijoyism.filenavigator.domain.FileEntry
import java.text.DateFormat
import java.util.Date

fun openFile(context: Context, entry: FileEntry): Boolean {
    val intent = Intent(Intent.ACTION_VIEW)
        .setDataAndType(Uri.parse(entry.uri), entry.mimeType ?: "*/*")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    return try {
        context.startActivity(intent)
        true
    } catch (e: ActivityNotFoundException) {
        false
    }
}

fun shareFiles(context: Context, entries: List<FileEntry>): Boolean {
    val files = entries.filter { !it.isDirectory }
    if (files.isEmpty()) return false
    val uris = ArrayList(files.map { Uri.parse(it.uri) })
    val intent = if (uris.size == 1) {
        Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
    }
    intent.type = if (files.size == 1) files[0].mimeType ?: "*/*" else "*/*"
    val clip = ClipData.newRawUri("files", uris[0])
    uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
    intent.clipData = clip
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    return try {
        context.startActivity(Intent.createChooser(intent, "Share"))
        true
    } catch (e: ActivityNotFoundException) {
        false
    }
}

fun formatSize(context: Context, bytes: Long): String = Formatter.formatShortFileSize(context, bytes)

fun formatDate(millis: Long): String = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(millis))
