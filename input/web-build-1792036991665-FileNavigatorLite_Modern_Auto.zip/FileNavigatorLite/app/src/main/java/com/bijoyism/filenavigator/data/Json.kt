package com.bijoyism.filenavigator.data

import com.bijoyism.filenavigator.domain.ConflictPolicy
import com.bijoyism.filenavigator.domain.HistoryEntry
import com.bijoyism.filenavigator.domain.Rule
import org.json.JSONArray
import org.json.JSONObject

private fun JSONObject.optNonEmpty(key: String): String? = optString(key, "").takeIf { it.isNotEmpty() }

private fun JSONObject.strings(key: String): List<String> {
    val array = optJSONArray(key) ?: return emptyList()
    return (0 until array.length()).map { array.getString(it) }
}

object RuleJson {
    fun encode(rules: List<Rule>): String {
        val array = JSONArray()
        rules.forEach { r ->
            array.put(
                JSONObject().apply {
                    put("id", r.id)
                    put("name", r.name)
                    put("enabled", r.enabled)
                    put("src", r.sourceUri)
                    put("dst", r.destUri)
                    put("ext", JSONArray(r.extensions))
                    put("mime", JSONArray(r.mimeTypes))
                    put("kw", JSONArray(r.keywords))
                    put("conflict", r.conflict.name)
                    r.minSizeBytes?.let { put("min", it) }
                    r.maxSizeBytes?.let { put("max", it) }
                    r.lastStatus?.let { put("status", it) }
                }
            )
        }
        return array.toString()
    }

    fun decode(text: String): List<Rule> = runCatching {
        val array = JSONArray(text)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Rule(
                id = o.getString("id"),
                name = o.getString("name"),
                enabled = o.optBoolean("enabled", true),
                sourceUri = o.getString("src"),
                destUri = o.getString("dst"),
                extensions = o.strings("ext"),
                mimeTypes = o.strings("mime"),
                keywords = o.strings("kw"),
                minSizeBytes = if (o.has("min")) o.getLong("min") else null,
                maxSizeBytes = if (o.has("max")) o.getLong("max") else null,
                conflict = runCatching { ConflictPolicy.valueOf(o.optString("conflict")) }.getOrDefault(ConflictPolicy.RENAME),
                lastStatus = o.optNonEmpty("status")
            )
        }
    }.getOrDefault(emptyList())
}

object HistoryJson {
    fun encode(list: List<HistoryEntry>): String {
        val array = JSONArray()
        list.forEach { e ->
            array.put(
                JSONObject().apply {
                    put("id", e.id)
                    put("time", e.time)
                    put("type", e.type)
                    put("name", e.name)
                    put("from", e.from)
                    put("to", e.to)
                    put("ok", e.success)
                    put("undone", e.undone)
                    e.error?.let { put("error", it) }
                    e.srcFolderUri?.let { put("src", it) }
                    e.destFolderUri?.let { put("dst", it) }
                    e.resultUri?.let { put("res", it) }
                }
            )
        }
        return array.toString()
    }

    fun decode(text: String): List<HistoryEntry> = runCatching {
        val array = JSONArray(text)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            HistoryEntry(
                id = o.getString("id"),
                time = o.getLong("time"),
                type = o.getString("type"),
                name = o.getString("name"),
                from = o.optString("from"),
                to = o.optString("to"),
                success = o.getBoolean("ok"),
                error = o.optNonEmpty("error"),
                srcFolderUri = o.optNonEmpty("src"),
                destFolderUri = o.optNonEmpty("dst"),
                resultUri = o.optNonEmpty("res"),
                undone = o.optBoolean("undone", false)
            )
        }
    }.getOrDefault(emptyList())
}
