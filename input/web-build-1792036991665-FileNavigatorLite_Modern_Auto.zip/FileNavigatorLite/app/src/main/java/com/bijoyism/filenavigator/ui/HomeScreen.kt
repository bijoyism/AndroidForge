package com.bijoyism.filenavigator.ui

import android.content.Context
import android.os.StatFs
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.bijoyism.filenavigator.history.route
import com.bijoyism.filenavigator.navigation.Destination
import com.bijoyism.filenavigator.util.formatSize

private fun storageSummary(context: Context): Pair<Long, Long>? {
    val dir = context.getExternalFilesDir(null) ?: return null
    return runCatching {
        val stat = StatFs(dir.path)
        stat.totalBytes to stat.availableBytes
    }.getOrNull()
}

@Composable
fun HomeScreen(vm: AppViewModel, onOpen: (Destination) -> Unit) {
    val context = LocalContext.current
    val rules by vm.rules.collectAsState()
    val history by vm.history.collectAsState()
    val scanning by vm.scanning.collectAsState()
    val scanText by vm.scanText.collectAsState()
    val storage = remember { storageSummary(context) }
    val enabled = rules.count { it.enabled }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(54.dp)
            ) {
                androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Menu, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(30.dp))
                }
            }
            Column(Modifier.weight(1f)) {
                Text("File Navigator", style = MaterialTheme.typography.headlineSmall)
                Text("Lite · private, on-device organization", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(30.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Filled.Refresh, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(30.dp))
                Text("Your files, organized automatically", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text(
                    if (enabled > 0) "$enabled active rule(s). Matching files can be sorted in the background while the app is closed."
                    else "Create a rule once, choose the folders, and enable it to start automatic sorting.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Button(
                    onClick = { if (enabled > 0) vm.scanNow() else onOpen(Destination.Automation) },
                    enabled = !scanning,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.size(8.dp))
                    Text(if (scanning) "Working…" else if (enabled > 0) "Scan now" else "Set up automation")
                }
                if (scanning) LinearProgressIndicator(Modifier.fillMaxWidth())
                scanText?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer) }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            MetricCard("Active rules", enabled.toString(), "of ${rules.size} total", Modifier.weight(1f))
            MetricCard("Recent actions", history.size.toString(), "saved in history", Modifier.weight(1f))
        }

        SectionCard("Automation") {
            Text(
                "Background checks run periodically. Android may delay them to save battery; folder access must be granted once in the system folder picker.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            TextButton(onClick = { onOpen(Destination.Automation) }) { Text("Manage rules") }
        }

        SectionCard("Storage") {
            if (storage == null) {
                Text("Storage information is not available on this device.")
            } else {
                val (total, free) = storage
                val used = (total - free).coerceAtLeast(0)
                LinearProgressIndicator(progress = { if (total > 0) used.toFloat() / total else 0f }, modifier = Modifier.fillMaxWidth())
                Text("${formatSize(context, used)} used of ${formatSize(context, total)} · ${formatSize(context, free)} free")
            }
        }

        SectionCard("Recent activity") {
            if (history.isEmpty()) {
                Text("Nothing yet. File actions will appear here.")
            } else {
                history.take(5).forEach { e ->
                    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Filled.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${e.type.lowercase().replaceFirstChar { it.uppercase() }} · ${e.name}", style = MaterialTheme.typography.bodyMedium)
                            Text(e.route(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                TextButton(onClick = { onOpen(Destination.Activity) }) { Text("View activity") }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, subtitle: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.headlineMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
