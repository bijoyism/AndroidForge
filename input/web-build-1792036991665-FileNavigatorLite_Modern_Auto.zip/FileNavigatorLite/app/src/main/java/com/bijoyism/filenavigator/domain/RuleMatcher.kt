package com.bijoyism.filenavigator.domain

object RuleMatcher {
    fun matches(rule: Rule, file: FileEntry): Boolean {
        if (file.isDirectory) return false
        val ext = file.name.substringAfterLast('.', "").lowercase()
        if (rule.extensions.isNotEmpty() || rule.mimeTypes.isNotEmpty()) {
            val byExt = ext.isNotEmpty() && rule.extensions.any { it.trimStart('.').equals(ext, ignoreCase = true) }
            val byMime = file.mimeType != null && rule.mimeTypes.any { mimeMatches(it, file.mimeType) }
            if (!byExt && !byMime) return false
        }
        if (rule.keywords.isNotEmpty() && rule.keywords.none { file.name.contains(it, ignoreCase = true) }) return false
        if (rule.minSizeBytes != null && (file.size < 0 || file.size < rule.minSizeBytes)) return false
        if (rule.maxSizeBytes != null && (file.size < 0 || file.size > rule.maxSizeBytes)) return false
        return true
    }

    /** Rule precedence is list order: the first enabled matching rule wins. */
    fun firstMatch(rules: List<Rule>, file: FileEntry): Rule? = rules.firstOrNull { it.enabled && matches(it, file) }

    fun mimeMatches(pattern: String, actual: String): Boolean = if (pattern.endsWith("/*")) {
        actual.startsWith(pattern.dropLast(1), ignoreCase = true)
    } else {
        pattern.equals(actual, ignoreCase = true)
    }
}

fun parseTokens(text: String): List<String> = text.split(',', ' ', ';', '\n').map { it.trim() }.filter { it.isNotEmpty() }

fun parseExtensions(text: String): List<String> = parseTokens(text).map { it.trimStart('.').lowercase() }.filter { it.isNotEmpty() }
