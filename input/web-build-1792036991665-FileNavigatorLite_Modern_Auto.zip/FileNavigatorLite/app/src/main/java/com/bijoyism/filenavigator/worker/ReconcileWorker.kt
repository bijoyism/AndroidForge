package com.bijoyism.filenavigator.worker

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.bijoyism.filenavigator.FileNavigatorApp
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

/**
 * Runs rule-based organization while the app UI is closed.
 *
 * Android schedules periodic work opportunistically (not at an exact minute).
 * The user must first grant access to source/destination folders and enable a rule.
 */
class ReconcileWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val container = (applicationContext as FileNavigatorApp).container
        return try {
            val enabledRules = container.data.rules.first().filter { it.enabled }
            if (enabledRules.isEmpty()) {
                Result.success()
            } else {
                // Preview and execute in the background: no confirmation dialog is needed
                // after the user has explicitly configured and enabled their rules.
                val plan = container.automation.preview(enabledRules).moves
                if (plan.isNotEmpty()) container.automation.run(plan)
                Result.success()
            }
        } catch (e: SecurityException) {
            Log.w("FileNavigator", "Background organization lacks folder access; reopen Settings and re-authorize the folder.", e)
            Result.retry()
        } catch (e: Exception) {
            Log.w("FileNavigator", "Background organization failed; WorkManager will retry.", e)
            Result.retry()
        }
    }
}

object ReconcileScheduler {
    private const val WORK_NAME = "automatic_file_organization"

    fun schedule(context: Context) {
        val request = PeriodicWorkRequestBuilder<ReconcileWorker>(30, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }
}
