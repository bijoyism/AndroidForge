package com.bijoyism.filenavigator.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.bijoyism.filenavigator.automation.summarize
import com.bijoyism.filenavigator.domain.ConflictPolicy
import com.bijoyism.filenavigator.domain.Rule
import com.bijoyism.filenavigator.domain.parseExtensions
import com.bijoyism.filenavigator.domain.parseTokens
import java.util.UUID

private class Preset(val name: String, val extensions: String, val mimes: String, val keywords: String)

private val PRESETS = listOf(
    Preset("APKs", "apk", "", ""),
    Preset("Screenshots", "", "image/*", "Screenshot"),
    Preset("Audio", "", "audio/*", ""),
    Preset("ZIP archives", "zip, rar, 7z", "", ""),
    Preset("PDFs", "pdf", "", "")
)

private const val MB = 1024L * 1024L

@Composable
fun AutomationScreen(vm: AutomationViewModel) {
    val rules by vm.rules.collectAsState()
    val preview by vm.preview.collectAsState()
    var editing by remember { mutableStateOf<Rule?>(null) }
    var creating by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Automation", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            OutlinedButton(onClick = { vm.preview(null) }, enabled = rules.any { it.enabled }) { Text("Run all") }
            Button(onClick = { creating = true }) { Text("New rule") }
        }
        androidx.compose.material3.Surface(
            color = MaterialTheme.colorScheme.secondaryContainer,
            shape = MaterialTheme.shapes.large,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        ) {
            Text(
                "Enabled rules run automatically in the background about every 30 minutes. Choose folders once; matching files are moved without asking again. Android may delay background work.",
                modifier = Modifier.padding(16.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
        }
        if (rules.isEmpty()) {
            CenterMessage("No rules yet. Tap New rule and start from a preset such as APKs or Screenshots.")
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(rules, key = { it.id }) { rule ->
                    SectionCard(rule.name) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${vm.label(rule.sourceUri)} → ${vm.label(rule.destUri)}", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = rule.enabled, onCheckedChange = { vm.setEnabled(rule.id, it) })
                        }
                        Text(filterSummary(rule), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        rule.lastStatus?.let {
                            val bad = it.startsWith("Error") || it.contains("failed")
                            Text(it, style = MaterialTheme.typography.bodySmall, color = if (bad) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState())) {
                            TextButton(onClick = { vm.preview(rule) }) { Text("Test") }
                            TextButton(onClick = { editing = rule }) { Text("Edit") }
                            TextButton(onClick = { vm.moveUp(rule.id) }) { Text("Higher priority") }
                            TextButton(onClick = { vm.delete(rule.id) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }

    if (creating || editing != null) {
        RuleEditor(
            initial = editing,
            vm = vm,
            onSave = {
                vm.save(it)
                creating = false
                editing = null
            },
            onClose = {
                creating = false
                editing = null
            }
        )
    }

    preview?.let { p ->
        val replacing = p.moves.any { it.conflict == ConflictPolicy.REPLACE }
        AlertDialog(
            onDismissRequest = { if (!p.loading) vm.closePreview() },
            title = { Text("Preview: ${p.title}") },
            text = {
                Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (p.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                    val results = p.results
                    if (results != null) {
                        Text(summarize(results))
                    } else if (!p.loading) {
                        Text("Dry run: no files are changed until you confirm.", style = MaterialTheme.typography.bodySmall)
                        p.problems.forEach { Text("⚠ ${it.ruleName}: ${it.message}", color = MaterialTheme.colorScheme.error) }
                        if (p.moves.isEmpty() && p.problems.isEmpty()) Text("No files match.")
                        p.moves.take(60).forEach { Text("${it.file.name} → ${vm.label(it.destFolder)}") }
                        if (p.moves.size > 60) Text("…and ${p.moves.size - 60} more")
                        if (replacing) Text("Some rules replace existing files with the same name.", color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                if (p.results == null && !p.loading && p.moves.isNotEmpty()) {
                    TextButton(onClick = { vm.runPreview() }) { Text("Move ${p.moves.size} file(s)") }
                } else if (p.results != null) {
                    TextButton(onClick = { vm.closePreview() }) { Text("Done") }
                }
            },
            dismissButton = {
                if (p.results == null && !p.loading) TextButton(onClick = { vm.closePreview() }) { Text("Close") }
            }
        )
    }
}

private fun filterSummary(rule: Rule): String {
    val parts = mutableListOf<String>()
    if (rule.extensions.isNotEmpty()) parts.add("ext: " + rule.extensions.joinToString(", "))
    if (rule.mimeTypes.isNotEmpty()) parts.add("type: " + rule.mimeTypes.joinToString(", "))
    if (rule.keywords.isNotEmpty()) parts.add("name has: " + rule.keywords.joinToString(", "))
    rule.minSizeBytes?.let { parts.add("min ${it / MB} MB") }
    rule.maxSizeBytes?.let { parts.add("max ${it / MB} MB") }
    parts.add("conflicts: " + rule.conflict.name.lowercase())
    return parts.joinToString(" · ")
}

@Composable
private fun RuleEditor(initial: Rule?, vm: AutomationViewModel, onSave: (Rule) -> Unit, onClose: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    var source by remember { mutableStateOf(initial?.sourceUri) }
    var dest by remember { mutableStateOf(initial?.destUri) }
    var extensions by remember { mutableStateOf(initial?.extensions?.joinToString(", ").orEmpty()) }
    var mimes by remember { mutableStateOf(initial?.mimeTypes?.joinToString(", ").orEmpty()) }
    var keywords by remember { mutableStateOf(initial?.keywords?.joinToString(", ").orEmpty()) }
    var minMb by remember { mutableStateOf(initial?.minSizeBytes?.let { (it / MB).toString() }.orEmpty()) }
    var maxMb by remember { mutableStateOf(initial?.maxSizeBytes?.let { (it / MB).toString() }.orEmpty()) }
    var conflict by remember { mutableStateOf(initial?.conflict ?: ConflictPolicy.RENAME) }
    var error by remember { mutableStateOf<String?>(null) }

    val pickSource = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            vm.grant(uri)
            source = uri.toString()
        }
    }
    val pickDest = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            vm.grant(uri)
            dest = uri.toString()
        }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (initial == null) "New rule" else "Edit rule", style = MaterialTheme.typography.headlineSmall)
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    PRESETS.forEach { p ->
                        TextButton(onClick = {
                            name = p.name
                            extensions = p.extensions
                            mimes = p.mimes
                            keywords = p.keywords
                        }) { Text(p.name) }
                    }
                }
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Rule name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedButton(onClick = { pickSource.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Source: " + (source?.let { vm.label(it) } ?: "choose folder"))
                }
                OutlinedButton(onClick = { pickDest.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Destination: " + (dest?.let { vm.label(it) } ?: "choose folder"))
                }
                OutlinedTextField(value = extensions, onValueChange = { extensions = it }, label = { Text("Extensions (apk, zip)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = mimes, onValueChange = { mimes = it }, label = { Text("MIME types (image/*, audio/*)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = keywords, onValueChange = { keywords = it }, label = { Text("Filename keywords (optional)") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = minMb, onValueChange = { minMb = it }, label = { Text("Min MB") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = maxMb, onValueChange = { maxMb = it }, label = { Text("Max MB") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Text("If a file with the same name exists:", style = MaterialTheme.typography.titleSmall)
                ConflictPolicy.entries.forEach { policy ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = conflict == policy, onClick = { conflict = policy })
                        Text(
                            when (policy) {
                                ConflictPolicy.RENAME -> "Keep both (add a number)"
                                ConflictPolicy.SKIP -> "Skip the file"
                                ConflictPolicy.REPLACE -> "Replace the existing file"
                            }
                        )
                    }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onClose) { Text("Cancel") }
                    Button(onClick = {
                        val src = source
                        val dst = dest
                        val ext = parseExtensions(extensions)
                        val mime = parseTokens(mimes)
                        val kw = parseTokens(keywords)
                        val min = minMb.toDoubleOrNull()?.let { (it * MB).toLong() }
                        val max = maxMb.toDoubleOrNull()?.let { (it * MB).toLong() }
                        error = when {
                            name.isBlank() -> "Enter a rule name"
                            src == null -> "Choose a source folder"
                            dst == null -> "Choose a destination folder"
                            src == dst -> "Source and destination must differ"
                            ext.isEmpty() && mime.isEmpty() && kw.isEmpty() && min == null && max == null -> "Add at least one filter so the rule does not match every file"
                            min != null && max != null && min > max -> "Min size cannot exceed max size"
                            else -> null
                        }
                        if (error == null && src != null && dst != null) {
                            onSave(
                                Rule(
                                    id = initial?.id ?: UUID.randomUUID().toString(),
                                    name = name.trim(),
                                    enabled = initial?.enabled ?: true,
                                    sourceUri = src,
                                    destUri = dst,
                                    extensions = ext,
                                    mimeTypes = mime,
                                    keywords = kw,
                                    minSizeBytes = min,
                                    maxSizeBytes = max,
                                    conflict = conflict,
                                    lastStatus = initial?.lastStatus
                                )
                            )
                        }
                    }) { Text("Save") }
                }
            }
        }
    }
}
