package com.bijoyism.filenavigator.automation

import com.bijoyism.filenavigator.data.AppData
import com.bijoyism.filenavigator.domain.NewFileDetector
import com.bijoyism.filenavigator.domain.Rule
import com.bijoyism.filenavigator.notifications.Notifier
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.flow.first

/** Glue between the rule engine and persisted rule status. */
class Automation(private val engine: RuleEngine, private val data: AppData) {

    suspend fun preview(rules: List<Rule>): PreviewResult {
        val result = engine.preview(rules)
        if (result.problems.isNotEmpty()) {
            val byId = result.problems.associateBy { it.ruleId }
            data.updateRules { list -> list.map { r -> byId[r.id]?.let { r.copy(lastStatus = "Error: ${it.message}") } ?: r } }
        }
        return result
    }

    suspend fun run(plan: List<PlannedMove>): List<ItemResult> {
        val results = engine.execute(plan)
        val stamp = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date())
        val byRule = results.filter { it.ruleId.isNotEmpty() }.groupBy { it.ruleId }
        if (byRule.isNotEmpty()) {
            data.updateRules { list -> list.map { r -> byRule[r.id]?.let { rs -> r.copy(lastStatus = status(stamp, rs)) } ?: r } }
        }
        return results
    }

    suspend fun organizeNow(): List<ItemResult> = run(preview(data.rules.first()).moves)

    private fun status(stamp: String, results: List<ItemResult>): String {
        val done = results.count { it.status == ItemStatus.DONE }
        val skipped = results.count { it.status == ItemStatus.SKIPPED }
        val failed = results.count { it.status == ItemStatus.FAILED }
        val firstError = results.firstOrNull { it.status == ItemStatus.FAILED }?.message
        return buildString {
            append("$stamp: $done moved")
            if (skipped > 0) append(", $skipped skipped")
            if (failed > 0) {
                append(", $failed failed")
                if (firstError != null) append(" ($firstError)")
            }
        }
    }
}

data class ScanResult(val matching: Int, val newMatches: Int, val problems: List<RuleProblem>, val notified: Boolean)

/** Looks for new files matching enabled rules. Used by Scan Now and the periodic worker. */
class Scanner(
    private val engine: RuleEngine,
    private val data: AppData,
    private val notifier: Notifier
) {
    suspend fun scan(): ScanResult {
        val preview = engine.preview(data.rules.first())
        var fresh = 0
        for (source in preview.scannedSources) {
            val current = preview.moves.filter { it.srcFolder == source }.map { it.file.uri }.toSet()
            fresh += NewFileDetector.newFiles(current, data.seen(source)).size
            data.setSeen(source, current)
        }
        val settings = data.settings.first()
        val notify = fresh > 0 && settings.notifications && !settings.quiet
        if (notify) notifier.notifyNewFiles(fresh)
        return ScanResult(preview.moves.size, fresh, preview.problems, notify)
    }
}
