package com.bijoyism.filenavigator.domain

enum class SortKey { NAME, SIZE, DATE, TYPE }

fun List<FileEntry>.filterAndSort(query: String, sort: SortKey): List<FileEntry> {
    val q = query.trim()
    val filtered = if (q.isEmpty()) this else filter { it.name.contains(q, ignoreCase = true) }
    val comparator: Comparator<FileEntry> = when (sort) {
        SortKey.NAME -> compareBy<FileEntry> { it.name.lowercase() }
        SortKey.SIZE -> compareByDescending<FileEntry> { it.size }
        SortKey.DATE -> compareByDescending<FileEntry> { it.lastModified }
        SortKey.TYPE -> compareBy<FileEntry> { it.name.substringAfterLast('.', "").lowercase() }.thenBy { it.name.lowercase() }
    }
    return filtered.sortedWith(compareByDescending<FileEntry> { it.isDirectory }.then(comparator))
}
