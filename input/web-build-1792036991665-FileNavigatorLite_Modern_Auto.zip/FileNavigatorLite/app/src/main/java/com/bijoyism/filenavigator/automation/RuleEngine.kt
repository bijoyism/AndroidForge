package com.bijoyism.filenavigator.automation

import com.bijoyism.filenavigator.domain.ConflictPolicy
import com.bijoyism.filenavigator.domain.FileEntry
import com.bijoyism.filenavigator.domain.HistoryEntry
import com.bijoyism.filenavigator.domain.HistoryLog
import com.bijoyism.filenavigator.domain.Names
import com.bijoyism.filenavigator.domain.Rule
import com.bijoyism.filenavigator.domain.RuleMatcher
import com.bijoyism.filenavigator.domain.StorageException
import com.bijoyism.filenavigator.domain.StorageGateway
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class PlannedMove(
    val ruleId: String,
    val ruleName: String,
    val file: FileEntry,
    val srcFolder: String,
    val destFolder: String,
    val conflict: ConflictPolicy,
    val copy: Boolean = false
)

data class RuleProblem(val ruleId: String, val ruleName: String, val message: String)

data class PreviewResult(val moves: List<PlannedMove>, val problems: List<RuleProblem>, val scannedSources: Set<String>)

enum class ItemStatus { DONE, SKIPPED, FAILED }

data class ItemResult(val ruleId: String, val name: String, val status: ItemStatus, val message: String?)

data class OpResult(val ok: Boolean, val message: String)

fun summarize(results: List<ItemResult>): String {
    val done = results.count { it.status == ItemStatus.DONE }
    val skipped = results.count { it.status == ItemStatus.SKIPPED }
    val failed = results.count { it.status == ItemStatus.FAILED }
    return buildString {
        append("$done done")
        if (skipped > 0) append(", $skipped skipped")
        if (failed > 0) append(", $failed failed")
        results.filter { it.message != null }.forEach { append("\n• ${it.name}: ${it.message}") }
    }
}

class RuleEngine(private val storage: StorageGateway, private val log: HistoryLog) {

    /** Dry run: lists what would happen. Never changes any file. */
    suspend fun preview(rules: List<Rule>): PreviewResult = withContext(Dispatchers.IO) {
        val moves = mutableListOf<PlannedMove>()
        val problems = mutableListOf<RuleProblem>()
        val scanned = mutableSetOf<String>()
        val usable = mutableListOf<Rule>()
        for (rule in rules.filter { it.enabled }) {
            val problem = validate(rule)
            if (problem == null) usable.add(rule) else problems.add(RuleProblem(rule.id, rule.name, problem))
        }
        for ((source, group) in usable.groupBy { it.sourceUri }) {
            val files = try {
                storage.list(source)
            } catch (e: StorageException) {
                group.forEach { problems.add(RuleProblem(it.id, it.name, e.message ?: "Cannot read source folder")) }
                continue
            }
            scanned.add(source)
            for (file in files) {
                val rule = RuleMatcher.firstMatch(group, file) ?: continue
                moves.add(PlannedMove(rule.id, rule.name, file, source, rule.destUri, rule.conflict))
            }
        }
        PreviewResult(moves, problems, scanned)
    }

    private fun validate(rule: Rule): String? = when {
        storage.sameFolder(rule.sourceUri, rule.destUri) -> "Source and destination are the same folder"
        !storage.hasAccess(rule.sourceUri) -> "Source folder is not accessible. Choose it again to grant access."
        !storage.hasAccess(rule.destUri) -> "Destination folder is not accessible. Choose it again to grant access."
        else -> null
    }

    /** Runs every planned item; one failure never stops the batch. */
    suspend fun execute(plan: List<PlannedMove>): List<ItemResult> = withContext(Dispatchers.IO) {
        val namesByDest = HashMap<String, MutableMap<String, String>>()
        plan.map { runOne(it, namesByDest) }
    }

    private suspend fun runOne(m: PlannedMove, cache: MutableMap<String, MutableMap<String, String>>): ItemResult {
        val type = if (m.copy) "COPY" else "MOVE"
        return try {
            if (!storage.hasAccess(m.destFolder)) throw StorageException("Destination folder is not accessible")
            if (!m.copy && storage.sameFolder(m.srcFolder, m.destFolder)) throw StorageException("Source and destination are the same folder")
            val names = cache.getOrPut(m.destFolder) { storage.list(m.destFolder).associate { it.name to it.uri }.toMutableMap() }
            val existing = names[m.file.name]
            if (existing != null && m.conflict == ConflictPolicy.SKIP) {
                return ItemResult(m.ruleId, m.file.name, ItemStatus.SKIPPED, "Already exists in destination")
            }
            val finalName = if (existing == null) m.file.name else Names.unique(m.file.name) { it in names }
            var newUri = if (m.copy) {
                storage.copy(m.file.uri, m.destFolder, finalName)
            } else {
                storage.move(m.file.uri, m.srcFolder, m.destFolder, finalName)
            }
            names[finalName] = newUri
            var replaced = false
            if (existing != null && m.conflict == ConflictPolicy.REPLACE) {
                storage.delete(existing)
                newUri = storage.rename(newUri, m.file.name)
                names.remove(finalName)
                names[m.file.name] = newUri
                replaced = true
            }
            val undoable = !m.copy && !replaced
            log.add(
                HistoryEntry(
                    type = type,
                    name = m.file.name,
                    from = storage.label(m.srcFolder),
                    to = storage.label(m.destFolder),
                    success = true,
                    srcFolderUri = if (undoable) m.srcFolder else null,
                    destFolderUri = m.destFolder,
                    resultUri = newUri
                )
            )
            ItemResult(m.ruleId, m.file.name, ItemStatus.DONE, null)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val message = e.message ?: e.javaClass.simpleName
            log.add(HistoryEntry(type = type, name = m.file.name, from = storage.label(m.srcFolder), to = storage.label(m.destFolder), success = false, error = message))
            ItemResult(m.ruleId, m.file.name, ItemStatus.FAILED, message)
        }
    }

    /** Moves a previously moved file back, only when its history entry carries enough information. */
    suspend fun undo(entry: HistoryEntry): OpResult = withContext(Dispatchers.IO) {
        val src = entry.srcFolderUri
        val dest = entry.destFolderUri
        val result = entry.resultUri
        if (src == null || dest == null || result == null) {
            return@withContext OpResult(false, "This operation cannot be undone safely")
        }
        try {
            if (!storage.hasAccess(src) || !storage.hasAccess(dest)) throw StorageException("Folder access is missing")
            val taken = storage.list(src).map { it.name }.toSet()
            val finalName = Names.unique(entry.name) { it in taken }
            storage.move(result, dest, src, finalName)
            log.add(HistoryEntry(type = "UNDO", name = entry.name, from = storage.label(dest), to = storage.label(src), success = true))
            OpResult(true, "Moved ${entry.name} back to ${storage.label(src)}")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val message = e.message ?: e.javaClass.simpleName
            log.add(HistoryEntry(type = "UNDO", name = entry.name, from = storage.label(dest), to = storage.label(src), success = false, error = message))
            OpResult(false, "Undo failed: $message")
        }
    }
}
