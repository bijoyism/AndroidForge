package com.bijoyism.filenavigator.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.bijoyism.filenavigator.domain.HistoryEntry
import com.bijoyism.filenavigator.domain.HistoryLog
import com.bijoyism.filenavigator.domain.Rule
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.fileNavigatorStore: DataStore<Preferences> by preferencesDataStore(name = "file_navigator")

data class AppSettings(val notifications: Boolean = false, val quiet: Boolean = false)

/** Rules, history, settings and "seen files" in one small DataStore. Only metadata is kept, never file contents. */
class AppData(private val store: DataStore<Preferences>) : HistoryLog {

    val rules: Flow<List<Rule>> = store.data.map { RuleJson.decode(it[RULES] ?: "[]") }
    val history: Flow<List<HistoryEntry>> = store.data.map { HistoryJson.decode(it[HISTORY] ?: "[]") }
    val settings: Flow<AppSettings> = store.data.map { AppSettings(it[NOTIFICATIONS] ?: false, it[QUIET] ?: false) }

    suspend fun updateRules(transform: (List<Rule>) -> List<Rule>) {
        store.edit { p -> p[RULES] = RuleJson.encode(transform(RuleJson.decode(p[RULES] ?: "[]"))) }
    }

    override suspend fun add(entry: HistoryEntry) {
        store.edit { p ->
            val current = HistoryJson.decode(p[HISTORY] ?: "[]")
            p[HISTORY] = HistoryJson.encode((listOf(entry) + current).take(MAX_HISTORY))
        }
    }

    suspend fun markUndone(id: String) {
        store.edit { p ->
            val current = HistoryJson.decode(p[HISTORY] ?: "[]")
            p[HISTORY] = HistoryJson.encode(current.map { if (it.id == id) it.copy(undone = true) else it })
        }
    }

    suspend fun clearHistory() {
        store.edit { it[HISTORY] = "[]" }
    }

    suspend fun setNotifications(on: Boolean) {
        store.edit { it[NOTIFICATIONS] = on }
    }

    suspend fun setQuiet(on: Boolean) {
        store.edit { it[QUIET] = on }
    }

    suspend fun seen(source: String): Set<String>? = store.data.first()[seenKey(source)]

    suspend fun setSeen(source: String, files: Set<String>) {
        store.edit { it[seenKey(source)] = files }
    }

    private fun seenKey(source: String) = stringSetPreferencesKey("seen_" + source.hashCode())

    companion object {
        private const val MAX_HISTORY = 200
        private val RULES = stringPreferencesKey("rules")
        private val HISTORY = stringPreferencesKey("history")
        private val NOTIFICATIONS = booleanPreferencesKey("notifications")
        private val QUIET = booleanPreferencesKey("quiet")

        fun create(context: Context): AppData = AppData(context.applicationContext.fileNavigatorStore)
    }
}
