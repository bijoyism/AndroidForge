package com.bijoyism.filenavigator.domain

object Names {
    /** Returns [name] if free, otherwise "base (n).ext" for the first free n. */
    fun unique(name: String, exists: (String) -> Boolean): String {
        if (!exists(name)) return name
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (exists("$base ($i)$ext")) i++
        return "$base ($i)$ext"
    }
}

object NewFileDetector {
    /** Files in [current] that were not in [seen]. A null [seen] is a first scan: it only records a baseline. */
    fun newFiles(current: Set<String>, seen: Set<String>?): Set<String> = if (seen == null) emptySet() else current - seen
}
