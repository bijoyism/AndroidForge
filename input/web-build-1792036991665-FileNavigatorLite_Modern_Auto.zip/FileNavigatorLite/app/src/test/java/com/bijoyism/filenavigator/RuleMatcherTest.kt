package com.bijoyism.filenavigator

import com.bijoyism.filenavigator.domain.FileEntry
import com.bijoyism.filenavigator.domain.Rule
import com.bijoyism.filenavigator.domain.RuleMatcher
import com.bijoyism.filenavigator.domain.parseExtensions
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RuleMatcherTest {
    private fun file(name: String, size: Long = 100, mime: String? = null, dir: Boolean = false) = FileEntry("u/$name", name, size, mime, 0, dir)

    private fun rule(name: String = "r", ext: List<String> = emptyList(), mime: List<String> = emptyList(), kw: List<String> = emptyList(), min: Long? = null, max: Long? = null, enabled: Boolean = true) =
        Rule(name = name, enabled = enabled, sourceUri = "src", destUri = "dst", extensions = ext, mimeTypes = mime, keywords = kw, minSizeBytes = min, maxSizeBytes = max)

    @Test
    fun extensionMatchIsCaseInsensitive() {
        assertTrue(RuleMatcher.matches(rule(ext = listOf("apk")), file("App.APK")))
        assertFalse(RuleMatcher.matches(rule(ext = listOf("apk")), file("app.zip")))
        assertFalse(RuleMatcher.matches(rule(ext = listOf("apk")), file("apk")))
    }

    @Test
    fun mimeWildcardAndExactMatch() {
        assertTrue(RuleMatcher.matches(rule(mime = listOf("image/*")), file("a", mime = "image/png")))
        assertTrue(RuleMatcher.matches(rule(mime = listOf("application/pdf")), file("a", mime = "application/pdf")))
        assertFalse(RuleMatcher.matches(rule(mime = listOf("image/*")), file("a", mime = "audio/mp3")))
        assertFalse(RuleMatcher.matches(rule(mime = listOf("image/*")), file("a", mime = null)))
    }

    @Test
    fun keywordsAndSizeLimitsApply() {
        val r = rule(kw = listOf("screenshot"), min = 10, max = 1000)
        assertTrue(RuleMatcher.matches(r, file("My Screenshot 1.png", size = 500)))
        assertFalse(RuleMatcher.matches(r, file("photo.png", size = 500)))
        assertFalse(RuleMatcher.matches(r, file("screenshot.png", size = 5)))
        assertFalse(RuleMatcher.matches(r, file("screenshot.png", size = 5000)))
        assertFalse(RuleMatcher.matches(r, file("screenshot.png", size = -1)))
    }

    @Test
    fun directoriesNeverMatch() {
        assertFalse(RuleMatcher.matches(rule(kw = listOf("a")), file("a", dir = true)))
    }

    @Test
    fun firstEnabledMatchingRuleWins() {
        val first = rule(name = "first", ext = listOf("zip"), enabled = false)
        val second = rule(name = "second", ext = listOf("zip"))
        val third = rule(name = "third", ext = listOf("zip"))
        assertEquals("second", RuleMatcher.firstMatch(listOf(first, second, third), file("a.zip"))?.name)
        assertNull(RuleMatcher.firstMatch(listOf(first), file("a.zip")))
    }

    @Test
    fun parsesExtensionInput() {
        assertEquals(listOf("apk", "zip"), parseExtensions(".APK, zip ;"))
    }
}
