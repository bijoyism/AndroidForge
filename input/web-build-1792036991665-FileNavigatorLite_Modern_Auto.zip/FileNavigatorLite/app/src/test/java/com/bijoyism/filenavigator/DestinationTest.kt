package com.bijoyism.filenavigator

import com.bijoyism.filenavigator.navigation.Destination
import org.junit.Assert.assertEquals
import org.junit.Test

class DestinationTest {
    @Test
    fun mainNavigationHasFiveTabsInOrder() {
        assertEquals(
            listOf("Home", "Files", "Automation", "Activity", "Settings"),
            Destination.entries.map { it.label }
        )
    }
}
