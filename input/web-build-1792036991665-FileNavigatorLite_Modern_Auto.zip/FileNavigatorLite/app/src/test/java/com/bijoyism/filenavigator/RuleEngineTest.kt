package com.bijoyism.filenavigator

import com.bijoyism.filenavigator.automation.ItemStatus
import com.bijoyism.filenavigator.automation.PlannedMove
import com.bijoyism.filenavigator.automation.RuleEngine
import com.bijoyism.filenavigator.domain.ConflictPolicy
import com.bijoyism.filenavigator.domain.FileEntry
import com.bijoyism.filenavigator.domain.HistoryEntry
import com.bijoyism.filenavigator.domain.HistoryLog
import com.bijoyism.filenavigator.domain.Rule
import com.bijoyism.filenavigator.domain.StorageException
import com.bijoyism.filenavigator.domain.StorageGateway
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

private class FakeStorage : StorageGateway {
    val folders = mutableMapOf<String, MutableList<FileEntry>>()
    val noAccess = mutableSetOf<String>()
    val failOn = mutableSetOf<String>()

    fun add(folder: String, name: String, size: Long = 10) {
        folders.getOrPut(folder) { mutableListOf() }.add(FileEntry("$folder/$name", name, size, null, 0, false))
    }

    fun names(folder: String): List<String> = folders[folder].orEmpty().map { it.name }

    override fun hasAccess(folderUri: String) = folderUri !in noAccess

    override fun sameFolder(a: String, b: String) = a == b

    override fun list(folderUri: String): List<FileEntry> {
        if (folderUri in noAccess) throw StorageException("no access")
        return folders[folderUri].orEmpty().toList()
    }

    override fun copy(fileUri: String, destFolderUri: String, name: String): String {
        val source = folders.values.flatten().first { it.uri == fileUri }
        if (source.name in failOn) throw StorageException("boom")
        add(destFolderUri, name, source.size)
        return "$destFolderUri/$name"
    }

    override fun move(fileUri: String, srcFolderUri: String, destFolderUri: String, name: String): String {
        val uri = copy(fileUri, destFolderUri, name)
        folders[srcFolderUri]?.removeAll { it.uri == fileUri }
        return uri
    }

    override fun delete(uri: String) {
        folders.values.forEach { list -> list.removeAll { it.uri == uri } }
    }

    override fun rename(uri: String, newName: String): String {
        for ((folder, list) in folders) {
            val i = list.indexOfFirst { it.uri == uri }
            if (i >= 0) {
                list[i] = list[i].copy(uri = "$folder/$newName", name = newName)
                return "$folder/$newName"
            }
        }
        throw StorageException("missing")
    }

    override fun createFolder(parentUri: String, name: String) = "$parentUri/$name"

    override fun label(folderUri: String) = folderUri
}

private class FakeLog : HistoryLog {
    val entries = mutableListOf<HistoryEntry>()

    override suspend fun add(entry: HistoryEntry) {
        entries.add(entry)
    }
}

class RuleEngineTest {
    private val storage = FakeStorage()
    private val log = FakeLog()
    private val engine = RuleEngine(storage, log)

    private fun apkRule(conflict: ConflictPolicy = ConflictPolicy.RENAME, enabled: Boolean = true) =
        Rule(name = "apks", enabled = enabled, sourceUri = "src", destUri = "dst", extensions = listOf("apk"), conflict = conflict)

    private fun plan(rule: Rule) = runBlocking { engine.preview(listOf(rule)) }.moves

    @Test
    fun previewIsADryRunAndListsOnlyMatches() {
        storage.add("src", "a.apk")
        storage.add("src", "b.txt")
        val moves = plan(apkRule())
        assertEquals(listOf("a.apk"), moves.map { it.file.name })
        assertEquals(listOf("a.apk", "b.txt"), storage.names("src"))
        assertTrue(storage.names("dst").isEmpty())
    }

    @Test
    fun executeMovesFilesAndLogsHistory() {
        storage.add("src", "a.apk")
        val results = runBlocking { engine.execute(plan(apkRule())) }
        assertEquals(ItemStatus.DONE, results.single().status)
        assertEquals(listOf("a.apk"), storage.names("dst"))
        assertTrue(storage.names("src").isEmpty())
        assertTrue(log.entries.single().success)
    }

    @Test
    fun duplicateNamesGetUniqueNamesAndNothingIsOverwritten() {
        storage.add("src", "a.apk", size = 1)
        storage.add("dst", "a.apk", size = 99)
        runBlocking { engine.execute(plan(apkRule())) }
        assertEquals(listOf("a.apk", "a (1).apk"), storage.names("dst"))
        assertEquals(99L, storage.folders["dst"]!!.first { it.name == "a.apk" }.size)
    }

    @Test
    fun skipPolicyLeavesBothFilesAlone() {
        storage.add("src", "a.apk")
        storage.add("dst", "a.apk")
        val results = runBlocking { engine.execute(plan(apkRule(ConflictPolicy.SKIP))) }
        assertEquals(ItemStatus.SKIPPED, results.single().status)
        assertEquals(listOf("a.apk"), storage.names("src"))
        assertTrue(log.entries.isEmpty())
    }

    @Test
    fun replacePolicyEndsWithOneFileUnderTheOriginalName() {
        storage.add("src", "a.apk", size = 1)
        storage.add("dst", "a.apk", size = 99)
        runBlocking { engine.execute(plan(apkRule(ConflictPolicy.REPLACE))) }
        assertEquals(listOf("a.apk"), storage.names("dst"))
        assertEquals(1L, storage.folders["dst"]!!.single().size)
        assertEquals(null, log.entries.single().srcFolderUri)
    }

    @Test
    fun batchWithPartialFailureReportsEachFile() {
        storage.add("src", "ok.apk")
        storage.add("src", "bad.apk")
        storage.failOn.add("bad.apk")
        val results = runBlocking { engine.execute(plan(apkRule())) }
        assertEquals(ItemStatus.DONE, results.first { it.name == "ok.apk" }.status)
        val bad = results.first { it.name == "bad.apk" }
        assertEquals(ItemStatus.FAILED, bad.status)
        assertEquals("boom", bad.message)
        assertEquals(listOf("bad.apk"), storage.names("src"))
        assertEquals(2, log.entries.size)
        assertEquals(1, log.entries.count { !it.success })
    }

    @Test
    fun revokedDestinationPermissionBlocksTheRuleWithAnError() {
        storage.add("src", "a.apk")
        storage.noAccess.add("dst")
        val preview = runBlocking { engine.preview(listOf(apkRule())) }
        assertTrue(preview.moves.isEmpty())
        assertEquals(1, preview.problems.size)
        assertEquals(listOf("a.apk"), storage.names("src"))
    }

    @Test
    fun sameSourceAndDestinationIsRejected() {
        val rule = apkRule().copy(destUri = "src")
        val preview = runBlocking { engine.preview(listOf(rule)) }
        assertTrue(preview.moves.isEmpty())
        assertEquals("Source and destination are the same folder", preview.problems.single().message)
    }

    @Test
    fun disabledRulesAreIgnored() {
        storage.add("src", "a.apk")
        assertTrue(plan(apkRule(enabled = false)).isEmpty())
    }

    @Test
    fun undoMovesFileBack() {
        storage.add("src", "a.apk")
        runBlocking { engine.execute(plan(apkRule())) }
        val entry = log.entries.single()
        val result = runBlocking { engine.undo(entry) }
        assertTrue(result.ok)
        assertEquals(listOf("a.apk"), storage.names("src"))
        assertTrue(storage.names("dst").isEmpty())
    }

    @Test
    fun undoIsRefusedWithoutEnoughInformation() {
        val entry = HistoryEntry(type = "MOVE", name = "x", from = "a", to = "b", success = true)
        assertFalse(runBlocking { engine.undo(entry) }.ok)
    }

    @Test
    fun manualCopyKeepsTheOriginal() {
        storage.add("src", "a.txt")
        val file = storage.folders["src"]!!.single()
        val results = runBlocking { engine.execute(listOf(PlannedMove("", "Manual", file, "src", "dst", ConflictPolicy.RENAME, copy = true))) }
        assertEquals(ItemStatus.DONE, results.single().status)
        assertEquals(listOf("a.txt"), storage.names("src"))
        assertEquals(listOf("a.txt"), storage.names("dst"))
    }
}
