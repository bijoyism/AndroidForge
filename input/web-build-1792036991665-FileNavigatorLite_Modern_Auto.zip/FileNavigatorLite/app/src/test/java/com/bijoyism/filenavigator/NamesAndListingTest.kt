package com.bijoyism.filenavigator

import com.bijoyism.filenavigator.domain.FileEntry
import com.bijoyism.filenavigator.domain.Names
import com.bijoyism.filenavigator.domain.NewFileDetector
import com.bijoyism.filenavigator.domain.SortKey
import com.bijoyism.filenavigator.domain.filterAndSort
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NamesAndListingTest {
    @Test
    fun uniqueNameKeepsFreeNames() {
        assertEquals("a.txt", Names.unique("a.txt") { false })
    }

    @Test
    fun uniqueNameNumbersBeforeExtension() {
        val taken = setOf("a.txt", "a (1).txt")
        assertEquals("a (2).txt", Names.unique("a.txt") { it in taken })
        assertEquals("noext (1)", Names.unique("noext") { it == "noext" })
        assertEquals(".hidden (1)", Names.unique(".hidden") { it == ".hidden" })
    }

    @Test
    fun repeatedScansDoNotReportSameFilesTwice() {
        val files = setOf("u1", "u2")
        assertTrue(NewFileDetector.newFiles(files, null).isEmpty())
        assertEquals(setOf("u3"), NewFileDetector.newFiles(files + "u3", files))
        assertTrue(NewFileDetector.newFiles(files + "u3", files + "u3").isEmpty())
    }

    @Test
    fun sortsFoldersFirstThenByKey() {
        val list = listOf(
            FileEntry("1", "b.txt", 5, null, 10, false),
            FileEntry("2", "a.txt", 50, null, 20, false),
            FileEntry("3", "zdir", -1, null, 0, true)
        )
        assertEquals(listOf("zdir", "a.txt", "b.txt"), list.filterAndSort("", SortKey.NAME).map { it.name })
        assertEquals(listOf("zdir", "a.txt", "b.txt"), list.filterAndSort("", SortKey.SIZE).map { it.name })
        assertEquals(listOf("zdir", "a.txt", "b.txt"), list.filterAndSort("", SortKey.DATE).map { it.name })
        assertEquals(listOf("b.txt"), list.filterAndSort("B.T", SortKey.NAME).map { it.name })
    }
}
